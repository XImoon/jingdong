/*
Navicat MySQL Data Transfer

Source Server         : my34
Source Server Version : 50170
Source Host           : localhost:3306
Source Database       : jd

Target Server Type    : MYSQL
Target Server Version : 50170
File Encoding         : 65001

Date: 2015-01-12 09:20:08
*/

SET FOREIGN_KEY_CHECKS=0;

-- ----------------------------
-- Table structure for `pro_category`
-- ----------------------------
DROP TABLE IF EXISTS `pro_category`;
CREATE TABLE `pro_category` (
  `_id` int(100) NOT NULL AUTO_INCREMENT,
  `images` varchar(300) DEFAULT NULL,
  `pro_category` varchar(300) NOT NULL,
  `father_category` varchar(300) DEFAULT NULL,
  PRIMARY KEY (`_id`),
  KEY `pro_category` (`pro_category`)
) ENGINE=MyISAM AUTO_INCREMENT=67 DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of pro_category
-- ----------------------------
INSERT INTO `pro_category` VALUES ('1', 'lei_1.jpg', '手机外壳', '手机配件');
INSERT INTO `pro_category` VALUES ('2', 'lei_2.jpg', '内存卡', '手机配件');
INSERT INTO `pro_category` VALUES ('3', 'lei_3.jpg', '空调', '家用电器');
INSERT INTO `pro_category` VALUES ('4', 'lei_4.jpg', '台式电脑', '电脑办公');
INSERT INTO `pro_category` VALUES ('5', 'lei_5.jpg', '家庭影院', '家用电器');
INSERT INTO `pro_category` VALUES ('6', 'lei_6.jpg', '单反', '数码');
INSERT INTO `pro_category` VALUES ('7', 'lei_7.jpg', '耳机', '手机配件');
INSERT INTO `pro_category` VALUES ('8', 'lei_8.jpg', '数码相机', '数码');
INSERT INTO `pro_category` VALUES ('9', 'lei_9.jpg', '音响', '电脑办公');
INSERT INTO `pro_category` VALUES ('10', 'lei_10.jpg', '智能手表', '数码');
INSERT INTO `pro_category` VALUES ('11', 'lei_11.jpg', '笔记本', '电脑办公');
INSERT INTO `pro_category` VALUES ('12', 'lei_12.jpg', '个性音响', '电脑办公');
INSERT INTO `pro_category` VALUES ('13', 'lei_13.jpg', '对讲机', '数码');
INSERT INTO `pro_category` VALUES ('14', 'lei_14.jpg', '家用配件', '家用电器');
INSERT INTO `pro_category` VALUES ('15', 'lei_15.jpg', '酷炫耳机', '数码');
INSERT INTO `pro_category` VALUES ('16', 'lei_16.jpg', '手机', '手机');
INSERT INTO `pro_category` VALUES ('17', 'lei_17.jpg', '电视', '家用电器');
INSERT INTO `pro_category` VALUES ('19', 'cloth_1.jpg', '衬衫', '服饰');
INSERT INTO `pro_category` VALUES ('20', 'cloth_2.jpg', '风衣', '服饰');
INSERT INTO `pro_category` VALUES ('21', 'cloth_3.jpg', '牛仔裤', '服饰');
INSERT INTO `pro_category` VALUES ('22', 'cloth_4.jpg', '马甲', '服饰');
INSERT INTO `pro_category` VALUES ('23', 'cloth_5.jpg', '休闲裤', '服饰');
INSERT INTO `pro_category` VALUES ('24', 'cloth_6.jpg', '雪纺衫', '服饰');
INSERT INTO `pro_category` VALUES ('25', 'cloth_7.jpg', 'T桖', '服饰');
INSERT INTO `pro_category` VALUES ('26', 'cloth_8.jpg', '小脚裤', '服饰');
INSERT INTO `pro_category` VALUES ('27', 'cloth_9.jpg', '针织衫', '服饰');
INSERT INTO `pro_category` VALUES ('28', 'cloth_10.jpg', '打底裤', '服饰');
INSERT INTO `pro_category` VALUES ('29', 'cloth_11.jpg', '半身裙', '服饰');
INSERT INTO `pro_category` VALUES ('30', 'cloth_12.jpg', '短外套', '服饰');
INSERT INTO `pro_category` VALUES ('31', 'cloth_13.jpg', '羊毛衫', '服饰');
INSERT INTO `pro_category` VALUES ('32', 'cloth_14.jpg', '丝质', '服饰');
INSERT INTO `pro_category` VALUES ('33', 'cloth_15.jpg', '连衣裙', '服饰');
INSERT INTO `pro_category` VALUES ('34', 'cloth_16.jpg', '休闲套装', '服饰');
INSERT INTO `pro_category` VALUES ('35', 'cloth_17.jpg', '卫衣', '服饰');
INSERT INTO `pro_category` VALUES ('36', 'cloth_18.jpg', '休闲衣', '服饰');
INSERT INTO `pro_category` VALUES ('37', 'cloth_19.jpg', '正装裤', '服饰');
INSERT INTO `pro_category` VALUES ('38', 'xie_1.jpg', '拖鞋', '鞋靴');
INSERT INTO `pro_category` VALUES ('39', 'xie_2.jpg', '功能鞋', '鞋靴');
INSERT INTO `pro_category` VALUES ('40', 'xie_3.jpg', '男靴', '鞋靴');
INSERT INTO `pro_category` VALUES ('41', 'xie_4.jpg', '商务休闲鞋', '鞋靴');
INSERT INTO `pro_category` VALUES ('42', 'xie_5.jpg', '休闲鞋', '鞋靴');
INSERT INTO `pro_category` VALUES ('43', 'xie_6.jpg', '正装鞋', '鞋靴');
INSERT INTO `pro_category` VALUES ('44', 'xie_7.jpg', '帆布鞋', '鞋靴');
INSERT INTO `pro_category` VALUES ('45', 'xie_8.jpg', '传统布鞋', '鞋靴');
INSERT INTO `pro_category` VALUES ('46', 'xie_9.jpg', '鞋配件', '鞋靴');
INSERT INTO `pro_category` VALUES ('47', 'xie_10.jpg', '雨鞋雨靴', '鞋靴');
INSERT INTO `pro_category` VALUES ('48', 'xie_11.jpg', '定制鞋', '鞋靴');
INSERT INTO `pro_category` VALUES ('49', 'xie_12.jpg', '凉鞋沙滩鞋', '鞋靴');
INSERT INTO `pro_category` VALUES ('50', 'bao_1.jpg', '饰品配件', '珠宝首饰');
INSERT INTO `pro_category` VALUES ('51', 'bao_2.jpg', '时尚戒指', '珠宝首饰');
INSERT INTO `pro_category` VALUES ('52', 'bao_3.jpg', '婚庆饰品', '珠宝首饰');
INSERT INTO `pro_category` VALUES ('53', 'bao_4.jpg', '吊坠项链', '珠宝首饰');
INSERT INTO `pro_category` VALUES ('54', 'bao_5.jpg', '纯金手链脚链', '珠宝首饰');
INSERT INTO `pro_category` VALUES ('55', 'bao_6.jpg', '项链', '珠宝首饰');
INSERT INTO `pro_category` VALUES ('56', 'bao_7.jpg', '高价收藏', '珠宝首饰');
INSERT INTO `pro_category` VALUES ('57', 'bao_8.jpg', '裸钻', '珠宝首饰');
INSERT INTO `pro_category` VALUES ('58', 'bao_9.jpg', '头饰胸针', '珠宝首饰');
INSERT INTO `pro_category` VALUES ('59', 'bao_10.jpg', '手镯手链', '珠宝首饰');
INSERT INTO `pro_category` VALUES ('60', 'bao_11.jpg', '工艺银', '珠宝首饰');
INSERT INTO `pro_category` VALUES ('61', 'bao_12.jpg', '工艺金', '珠宝首饰');
INSERT INTO `pro_category` VALUES ('62', 'bao_13.jpg', '耳饰', '珠宝首饰');
INSERT INTO `pro_category` VALUES ('63', 'bao_14.jpg', '纯钻', '珠宝首饰');
INSERT INTO `pro_category` VALUES ('64', 'bao_15.jpg', '宝宝银饰', '珠宝首饰');
INSERT INTO `pro_category` VALUES ('65', 'bao_16.jpg', '纯k金戒指', '珠宝首饰');
INSERT INTO `pro_category` VALUES ('66', 'bao_17.jpg', '其他', '珠宝首饰');
