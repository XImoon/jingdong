/*
Navicat MySQL Data Transfer

Source Server         : my34
Source Server Version : 50170
Source Host           : localhost:3306
Source Database       : jd

Target Server Type    : MYSQL
Target Server Version : 50170
File Encoding         : 65001

Date: 2015-01-12 09:20:02
*/

SET FOREIGN_KEY_CHECKS=0;

-- ----------------------------
-- Table structure for `orderinfo`
-- ----------------------------
DROP TABLE IF EXISTS `orderinfo`;
CREATE TABLE `orderinfo` (
  `_id` int(30) NOT NULL AUTO_INCREMENT,
  `name` varchar(300) NOT NULL,
  `address` varchar(300) NOT NULL,
  `tel` varchar(100) NOT NULL,
  `status` varchar(100) NOT NULL,
  `count` varchar(50) NOT NULL,
  `date` varchar(50) NOT NULL,
  PRIMARY KEY (`_id`)
) ENGINE=MyISAM AUTO_INCREMENT=5 DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of orderinfo
-- ----------------------------
INSERT INTO `orderinfo` VALUES ('1', 'admin', 'aaa', '123', '已发货', '23', '2014');
INSERT INTO `orderinfo` VALUES ('2', 'admin', '12', '123', '待处理', '100', '2015-01-11 23:00:29');
INSERT INTO `orderinfo` VALUES ('3', 'zc', 'jikeyi', '12345', '待处理', '4283', '2015-01-11 23:29:19');
INSERT INTO `orderinfo` VALUES ('4', 'llb', 'jikeyi', '1234', '待处理', '4283', '2015-01-11 23:32:15');
