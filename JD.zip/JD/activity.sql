/*
Navicat MySQL Data Transfer

Source Server         : my34
Source Server Version : 50170
Source Host           : localhost:3306
Source Database       : jd

Target Server Type    : MYSQL
Target Server Version : 50170
File Encoding         : 65001

Date: 2015-01-12 09:19:56
*/

SET FOREIGN_KEY_CHECKS=0;

-- ----------------------------
-- Table structure for `activity`
-- ----------------------------
DROP TABLE IF EXISTS `activity`;
CREATE TABLE `activity` (
  `_id` int(100) NOT NULL AUTO_INCREMENT,
  `activity_images` varchar(300) NOT NULL,
  `activity_title` varchar(300) NOT NULL,
  `activity_content` varchar(500) NOT NULL,
  `activity_count` int(200) NOT NULL,
  `activity_type` varchar(100) NOT NULL,
  PRIMARY KEY (`_id`)
) ENGINE=MyISAM AUTO_INCREMENT=14 DEFAULT CHARSET=utf8 ROW_FORMAT=DYNAMIC;

-- ----------------------------
-- Records of activity
-- ----------------------------
INSERT INTO `activity` VALUES ('1', 'activity_3.png', '安踏明星装备', '生命在于运动，运动在于锻炼，锻炼贵在坚持，坚持就是胜利', '4', '热门');
INSERT INTO `activity` VALUES ('2', 'activity_4.png', '婚礼.鞋子', '婚姻就像鞋子，合脚了才能天长地久', '9', '热门');
INSERT INTO `activity` VALUES ('3', 'activity_5.png', 'Dior迪奥美妆专场', '我偶然遇到了你，却不敢走近，只因你独特的魅力阻挡我前行，你的侧脸吸引我的眼神，不再...', '9', '热门');
INSERT INTO `activity` VALUES ('4', 'activity_2.png', '国际女鞋低至5折', '有人说可以从鞋子上看出一个人的性格，鞋子类型色调的变化，也昭示出这个人在慢慢的改变....', '0', '热门');
INSERT INTO `activity` VALUES ('5', 'activity_1.png', '复古帆布包', '帆布包经典不败的时尚潮流理念，搭配以随性设计，加上最有话题的外表点缀与内在品质，散.....', '16', '热门');
INSERT INTO `activity` VALUES ('6', 'activity_6.png', '微信电商工具书', '系统总结微信电商引流的8类主要方法和26个要点，深度解读15大行业的微信电商实操方法和....', '0', '热门');
INSERT INTO `activity` VALUES ('8', 'zj_1.png', '新款香皂花花束', '当阳光还没爬上布满蔓藤的；篱笆，我的迫不及待的玫瑰早已缀满了你的窗台', '4', '最近');
INSERT INTO `activity` VALUES ('9', 'zj_2.png', '幸福时光 冬季新款', '佛靠金装，人靠衣装，打扮也是要紧的。--沈自晋《望湖亭记》', '2', '最近');
INSERT INTO `activity` VALUES ('10', 'zj_3.png', '布音毛呢外套', '毛呢外套，寒冷的冬日的温暖格调', '5', '最近');
INSERT INTO `activity` VALUES ('11', 'zj_4.png', '坚果', '美味小坚果，牵住我们的心，勾引着我们的胃', '4', '最近');
INSERT INTO `activity` VALUES ('12', 'zj_5.png', '运动器材专场', '早炼晚炼，早晚都炼，早买晚买，早晚要买', '0', '最近');
INSERT INTO `activity` VALUES ('13', 'zj_6.png', '全美优选有机杂粮', '新年新气象，新的一年的食粮不一样', '0', '最近');
