package com.example.jky_34_jingdong;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import com.example.jky_34_jingdong.adapter.OrderAdapter;
import com.example.jky_34_jingdong.entity.OrderInfo;
import com.example.jky_34_jingdong.service.OrderService;
import com.example.jky_34_jingdong.util.ConstantUtil;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.os.Handler;
import android.os.Message;
import android.widget.ListView;
public class MyOrderActivity extends Activity {
	private ListView lv_order;
	private OrderAdapter adapter;
	private Map<String, String> map=new HashMap<String, String>();
	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.activity_my_order);
		init();
		Intent intent=getIntent();
		String name=intent.getStringExtra("username");
		map.put("name", name);
		adapter=new OrderAdapter(this);
		final OrderService service=new OrderService();
		new Thread(){
			public void run() {
				try {
					List<OrderInfo> lists=service.getMyOrder(ConstantUtil.MY_ORDER_PATH, map);
					if(lists!=null){
						Message msg=mHandler.obtainMessage();
						msg.what=ConstantUtil.NET_SUCCESS;
						msg.obj=lists;
						mHandler.sendMessage(msg);
					}else{
						mHandler.sendEmptyMessage(ConstantUtil.NET_NOT_DATA);
					}
				} catch (Exception e) {
					mHandler.sendEmptyMessage(ConstantUtil.NET_FAIL);
					e.printStackTrace();
				}
			};
		}.start();
		lv_order.setAdapter(adapter);
		
	}
	private Handler mHandler=new Handler(){
		public void handleMessage(Message msg) {
			switch (msg.what) {
			case ConstantUtil.NET_SUCCESS:
				List<OrderInfo> lists=(List<OrderInfo>) msg.obj;
				adapter.setLists(lists);
				adapter.notifyDataSetChanged();
				break;
			case ConstantUtil.NET_NOT_DATA:
				
				break;
			case ConstantUtil.NET_FAIL:
				
				break;
			default:
				break;
			}
		};
	};
	private void init() {
		lv_order=(ListView) findViewById(R.id.lv_order);
	}
}
