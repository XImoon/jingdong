package com.example.jky_34_jingdong.util;
import android.content.Context;
import android.graphics.Bitmap;
import android.graphics.Matrix;
import android.widget.Toast;
public class ConstantUtil {
	//吐司
	public static void MyToast(String msg,Context context){
		Toast.makeText(context, msg,Toast.LENGTH_LONG).show();
	}
	//服务器访问路径
	public static final String WEB_PATH="http://192.168.191.1:8080/jd/images/";
	//主页掌上秒杀访问路径
	public static final String IDNEX_MIAO_PATH="http://192.168.191.1:8080/jd/IndexServlet";
	//掌上秒杀路径
	public static final String MIAO_PATH="http://192.168.191.1:8080/jd/MiaoServlet";
	public static final String XIAO_PATH="http://192.168.191.1:8080/jd/XiaoServlet";
	public static final String CATEGORY_PATH="http://192.168.191.1:8080/jd/CategoryServlet";
	public static final String CATEGORY_PATH_2= "http://192.168.191.1:8080/jd/CategoryForListServlet";
	public static final String PRODUCT_PATH="http://192.168.191.1:8080/jd/ProductInfoServlet";
	public static final String ACTIVITY_PATH="http://192.168.191.1:8080/jd/ActivityServlet";
	public static final String ACTIVITY_PATH_2="http://192.168.191.1:8080/jd/ActivityByCountServlet";
	public static final String MY_PURSE_PATH="http://192.168.191.1:8080/jd/MyPurseServlet";
	public static final String GAME_COUNT_PATH="http://192.168.191.1:8080/jd/CountServlet";
	public static final String VERSION_PATH="http://192.168.191.1:8080/jd/version.xml";
	public static final String STORY_PATH="http://192.168.191.1:8080/jd/ParseToGsonServlet";
	public static final String ORDER_PATH="http://192.168.191.1:8080/jd/OrderServlet";
	public static final String MY_ORDER_PATH="http://192.168.191.1:8080/jd/MyOrderServlet";
	public static final int NET_SUCCESS=0;
	public static final int NET_FAIL=1;
	public static final int NET_NOT_DATA=2;
	//图片压缩
	public static Bitmap manageImg(Bitmap bitmap){
		int oldWidth=bitmap.getWidth();
		int oldHeight=bitmap.getHeight();
		int newWidth=100;
		int newHeight=100;
		//得到比例因子
		float sx=newWidth/(float)oldWidth;
		float sy=newHeight/(float)oldHeight;
		//得到矩阵  缩放不失真
		Matrix matrix=new Matrix();
		matrix.setScale(sx, sy);
		bitmap=bitmap.createBitmap(
				bitmap,
				0,
				0,
				oldWidth,
				oldHeight,
				matrix,
				true);
		return bitmap;
	}
	/** 缩放Bitmap图片 **/

	public static Bitmap zoomBitmap(Bitmap bitmap, int width, int height) {

		int w = bitmap.getWidth();

		int h = bitmap.getHeight();

		Matrix matrix = new Matrix();

		float scaleWidth = ((float) width / w);

		float scaleHeight = ((float) height / h);

		matrix.postScale(scaleWidth, scaleHeight);// 利用矩阵进行缩放不会造成内存溢出

		Bitmap newbmp = Bitmap.createBitmap(bitmap, 0, 0, w, h, matrix, true);

		return newbmp;

	}
	//注册账户免费送钱
	public static final String send_money="1000";
}
