package com.example.jky_34_jingdong;
import java.util.List;

import com.example.jky_34_jingdong.adapter.IndexAdapter;
import com.example.jky_34_jingdong.adapter.ProductAdapter;
import com.example.jky_34_jingdong.entity.ProductInfo;
import com.example.jky_34_jingdong.entity.UserInfo;
import com.example.jky_34_jingdong.service.LoginService;
import com.example.jky_34_jingdong.service.ProductService;
import com.example.jky_34_jingdong.util.ConstantUtil;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.os.Handler;
import android.os.Message;
import android.os.SystemClock;
import android.view.View;
import android.widget.AdapterView;
import android.widget.AdapterView.OnItemClickListener;
import android.widget.ArrayAdapter;
import android.widget.GridView;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;
public class IndexActivity extends Activity {
	private ImageView iv_index_images;
	private int count=0;
	private int[] ResId={R.drawable.android_index_1,
			R.drawable.android_index_2,
			R.drawable.android_index_3,
			R.drawable.android_index_4,
			R.drawable.android_index_5,
			R.drawable.android_index_6,
			R.drawable.android_index_7,
			R.drawable.android_index_8
			};
	private int[] SmallId={R.drawable.logistics_point_red_03,
			R.drawable.logistics_point_red_03,
			R.drawable.logistics_point_red_03,
			R.drawable.logistics_point_red_03,
			R.drawable.logistics_point_red_03,
			R.drawable.logistics_point_red_03,
			R.drawable.logistics_point_red_03,
			R.drawable.logistics_point_red_03
			};
	private IndexAdapter indexAdapter;
	private GridView gv_index_images;
	private int hour=24;
	private int minute=59;
	private int seconds=60;
	private TextView index_tv_hour;
	private TextView index_tv_minute;
	private TextView index_tv_seconds;
	//掌上秒杀控件
	private GridView index_gv_miaosha;
	private ProductAdapter productAdapter;
	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.activity_index);
		init();
		indexAdapter=new IndexAdapter(this, SmallId);
		gv_index_images.setAdapter(indexAdapter);
		//启动时间线程
		new TimeThread().start();
		productAdapter=new ProductAdapter(this);
		index_gv_miaosha.setAdapter(productAdapter);
		new ProThread().start();
		index_gv_miaosha.setOnItemClickListener(new MiaoListener());
	}
	public class MiaoListener implements OnItemClickListener{
		@Override
		public void onItemClick(AdapterView<?> parent, View view, int position,
				long id) {
			Intent intent=new Intent(IndexActivity.this,MiaoActivity.class);
			intent.putExtra("status","掌上秒杀");
			startActivity(intent);
		}
	}
	public class ProThread extends Thread{
		final ProductService service=new ProductService();
		@Override
		public void run() {
			try {
				List<ProductInfo> lists=service.getProductsFromGson(ConstantUtil.IDNEX_MIAO_PATH);
				if(lists!=null){
					Message msg=miaoHandler.obtainMessage();
					msg.what=0;
					msg.obj=lists;
					miaoHandler.sendMessage(msg);
				}else{
					miaoHandler.sendEmptyMessage(1);
				}
			} catch (Exception e) {
				miaoHandler.sendEmptyMessage(2);
				e.printStackTrace();
			}
		}
	}
	public class TimeThread extends Thread{
		@Override
		public void run() {
			while(true){
				count++;
				if(count>=8){
					count=0;
				}
				seconds--;
				if(seconds<=0){
					minute-=1;
					seconds=60;
				}
				if(minute<=0){
					hour-=1;
					minute=60;
					seconds=60;
				}
				Message msg=mHandler.obtainMessage();
				mHandler.sendMessage(msg);
				try {
					Thread.sleep(1000);
				} catch (InterruptedException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
			}
		}
	}
	private Handler mHandler=new Handler(){
		public void handleMessage(android.os.Message msg) {
			iv_index_images.setImageResource(ResId[count]);
			for(int i=0;i<SmallId.length;i++){
				if(i==count){
					SmallId[i]=R.drawable.logistics_point_green_03;
				}else{
					SmallId[i]=R.drawable.logistics_point_red_03;
				}
				indexAdapter.notifyDataSetChanged();
			}
			index_tv_hour.setText(hour+"");
			index_tv_minute.setText(minute+"");
			index_tv_seconds.setText(seconds+"");
		};
	};
	private Handler miaoHandler=new Handler(){
		public void handleMessage(Message msg) {
			switch (msg.what) {
			case 0:
				List<ProductInfo> lists=(List<ProductInfo>) msg.obj;
				productAdapter.setLists(lists);
				productAdapter.notifyDataSetChanged();
				break;
			case 1:
				Toast.makeText(IndexActivity.this,"1111",Toast.LENGTH_LONG).show();
				break;
			case 2:
				Toast.makeText(IndexActivity.this,"2222",Toast.LENGTH_LONG).show();
				break;
			default:
				break;
			}
		};
	};
	private void init() {
		iv_index_images=(ImageView) findViewById(R.id.iv_index_images);
		gv_index_images=(GridView) findViewById(R.id.gv_index_images);
		index_tv_hour=(TextView) findViewById(R.id.index_tv_hour);
		index_tv_minute=(TextView) findViewById(R.id.index_tv_minute);
		index_tv_seconds=(TextView) findViewById(R.id.index_tv_seconds);
		index_gv_miaosha=(GridView) findViewById(R.id.index_gv_miaosha);
	}
	public void jump_scan(View view){
		Intent intent=new Intent(this,ScanActivity.class);
		startActivity(intent);
	}
	public void jump_attention(View view){
		Intent intent=new Intent(this,AttentionActivity.class);
		startActivity(intent);
	}
	public void game(View view){
		LoginService service=new LoginService(this);
		UserInfo info = service.query();
		if(info!=null){
			Intent intent=new Intent(this, CountActivity.class);
			intent.putExtra("username", info.username);
			startActivity(intent);
		}else{
			Intent intent=new Intent(this, LoginActivity.class);
			startActivity(intent);
		}
	}
	public void search(View view){
		Intent intent=new Intent(this,SearchActivity.class);
		startActivity(intent);
	}
	public void xiao(View view){
		Intent intent=new Intent(this,MiaoActivity.class);
		intent.putExtra("status","促销卖场");
		startActivity(intent);
	}
	public void gou_1(View view){
		Intent intent=new Intent(IndexActivity.this, CategoryListActivity.class);
		intent.putExtra("category","手机");
		startActivity(intent);
	}
	public void gou_2(View view){
		Intent intent=new Intent(IndexActivity.this, CategoryListActivity.class);
		intent.putExtra("category","雪纺衫");
		startActivity(intent);
	}
	public void gou_3(View view){
		Intent intent=new Intent(IndexActivity.this, CategoryListActivity.class);
		intent.putExtra("category","电视");
		startActivity(intent);
	}
	public void caipiao(View view){
		LoginService service=new LoginService(this);
		UserInfo info = service.query();
		if(info!=null){
			Intent intent=new Intent(this, AwardActivity.class);
			intent.putExtra("username", info.username);
			startActivity(intent);
		}else{
			Intent intent=new Intent(this, LoginActivity.class);
			startActivity(intent);
		}
	}
	public void order(View view){
		LoginService service=new LoginService(this);
		UserInfo info = service.query();
		if(info!=null){
			Intent intent=new Intent(this, MyOrderActivity.class);
			intent.putExtra("username", info.username);
			startActivity(intent);
		}else{
			Intent intent=new Intent(this, LoginActivity.class);
			startActivity(intent);
		}
	}
}
