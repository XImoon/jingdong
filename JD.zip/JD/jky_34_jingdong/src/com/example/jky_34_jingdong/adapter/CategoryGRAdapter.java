package com.example.jky_34_jingdong.adapter;
import java.util.ArrayList;
import java.util.List;

import com.example.jky_34_jingdong.R;
import com.example.jky_34_jingdong.entity.CategoryInfo;
import com.example.jky_34_jingdong.service.ProductService;
import com.example.jky_34_jingdong.util.ConstantUtil;

import android.content.Context;
import android.graphics.Bitmap;
import android.os.AsyncTask;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.ImageView;
import android.widget.TextView;
public class CategoryGRAdapter extends BaseAdapter {
	private LayoutInflater mInflater;
	List<CategoryInfo> lists=new ArrayList<CategoryInfo>();
	public CategoryGRAdapter(Context context) {
		mInflater=LayoutInflater.from(context);
	}
	public void setLists(List<CategoryInfo> lists) {
		this.lists = lists;
	}
	@Override
	public int getCount() {
		// TODO Auto-generated method stub
		return lists.size();
	}

	@Override
	public Object getItem(int position) {
		// TODO Auto-generated method stub
		return lists.get(position);
	}

	@Override
	public long getItemId(int position) {
		// TODO Auto-generated method stub
		return position;
	}

	@Override
	public View getView(int position, View convertView, ViewGroup parent) {
		View view = mInflater.inflate(R.layout.gv_category_item, null);
		ImageView ib_category_img=(ImageView) view.findViewById(R.id.ib_category_img);
		TextView tv_category_name=(TextView) view.findViewById(R.id.tv_category_name);
		CategoryInfo info=lists.get(position);
		tv_category_name.setText(info.pro_category);
		//异步
		AsyncTaskLeaderImage aLeaderImage=new AsyncTaskLeaderImage();
		String path=info.images;
		aLeaderImage.execute(ib_category_img, path);
		return view;
	}
	class AsyncTaskLeaderImage extends AsyncTask<Object, Object, Object>{
		@Override
		protected Object doInBackground(Object... params) {
			//拿参数
			ImageView iv_head=(ImageView) params[0];
			String path=ConstantUtil.WEB_PATH+(String) params[1];
			try {
				Bitmap bitmap=ProductService.getBitmapFromPath(path);
				publishProgress(new Object[]{iv_head,bitmap});
			} catch (Exception e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			return null;
		}
		@Override
		protected void onProgressUpdate(Object... values) {
			ImageView iv_head=(ImageView) values[0];
			Bitmap bitmap=(Bitmap) values[1];
			iv_head.setImageBitmap(bitmap);
			super.onProgressUpdate(values);
		}
		
	}

}
