package com.example.jky_34_jingdong.adapter;
import com.example.jky_34_jingdong.R;

import android.content.Context;
import android.database.Cursor;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.CursorAdapter;
import android.widget.TextView;
public class SearchCursorAdapter extends CursorAdapter {
	public SearchCursorAdapter(Context context, Cursor c){
		super(context, c);
	}
	@Override
	public View newView(Context context, Cursor cursor, ViewGroup parent) {
		LayoutInflater mInflater = LayoutInflater.from(context);
		View view = mInflater.inflate(R.layout.lv_search_item, null);
		return view;
	}

	@Override
	public void bindView(View view, Context context, Cursor cs) {
		TextView tv_search_item = (TextView) view.findViewById(R.id.tv_search_item);
		String content=cs.getString(cs.getColumnIndex("search_xontent"));
		tv_search_item.setText(content);
	}
	

}
