package com.example.jky_34_jingdong.adapter;
import com.example.jky_34_jingdong.R;

import android.content.Context;
import android.provider.ContactsContract.CommonDataKinds.Im;
import android.renderscript.Int2;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.ImageView;

public class IndexAdapter extends BaseAdapter {
	private int[] ids=new int[]{};
	private LayoutInflater mInflater;
	private Context context;
	public IndexAdapter(Context context,int[] ids){
		this.context=context;
		this.ids=ids;
		mInflater=LayoutInflater.from(context);
	}
	@Override
	public int getCount() {
		// TODO Auto-generated method stub
		return ids.length;
	}

	@Override
	public Object getItem(int position) {
		// TODO Auto-generated method stub
		return ids[position];
	}

	@Override
	public long getItemId(int position) {
		// TODO Auto-generated method stub
		return position;
	}

	@Override
	public View getView(int position, View convertView, ViewGroup parent) {
		View view=mInflater.inflate(R.layout.gv_index_images,null);
		ImageView iv_index_adapter_images=(ImageView) view.findViewById(R.id.iv_index_adapter_images);
		int id=ids[position];
		iv_index_adapter_images.setImageDrawable(context.getResources().getDrawable(id));
		return view;
	}

}
