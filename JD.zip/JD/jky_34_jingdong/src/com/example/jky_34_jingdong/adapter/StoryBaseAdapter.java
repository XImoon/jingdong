package com.example.jky_34_jingdong.adapter;

import java.util.ArrayList;
import java.util.List;

import com.example.jky_34_jingdong.R;
import com.example.jky_34_jingdong.entity.StoryInfo;
import com.example.jky_34_jingdong.service.ProductService;
import com.example.jky_34_jingdong.util.ConstantUtil;

import android.content.Context;
import android.graphics.Bitmap;
import android.os.AsyncTask;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.ImageView;
import android.widget.TextView;
public class StoryBaseAdapter extends BaseAdapter {
	private LayoutInflater mInflater;
	private List<StoryInfo> list = new ArrayList<StoryInfo>();
	public StoryBaseAdapter(Context context) {
		// TODO Auto-generated constructor stub
		mInflater = LayoutInflater.from(context);
	}
	//设值
	public void setList(List<StoryInfo> list) {
		this.list = list;
	}
	@Override
	public int getCount() {
		// TODO Auto-generated method stub
		return list.size();
	}

	@Override
	public Object getItem(int position) {
		// TODO Auto-generated method stub
		return list.get(position);
	}

	@Override
	public long getItemId(int position) {
		// TODO Auto-generated method stub
		return position;
	}

	@Override
	public View getView(int position, View convertView, ViewGroup parent) {
		View view = mInflater.inflate(R.layout.lv_item_story, null);
		TextView tv_name = (TextView) view.findViewById(R.id.tv_story_name);
		TextView tv_story = (TextView) view.findViewById(R.id.tv_story);
		ImageView iv_head = (ImageView) view.findViewById(R.id.iv_story_head);
		ImageView iv_image = (ImageView) view.findViewById(R.id.iv_story_image);
		//数据
		StoryInfo info = list.get(position);
		tv_name.setText(info.name);
		tv_story.setText(info.story);
		AsyncTaskLoadImage aTaskLoadImage = new AsyncTaskLoadImage();
		String path=info.image;
		String path2=info.image2;
		aTaskLoadImage.execute(iv_head, path,iv_image,path2);
		return view;
	}
	class AsyncTaskLoadImage extends AsyncTask<Object, Object, Object>{
		@Override
		protected Object doInBackground(Object... params) {
			ImageView iv_head = (ImageView) params[0];
			ImageView iv_image = (ImageView) params[2];
			String path2 = ConstantUtil.WEB_PATH+(String) params[3];
			String path =ConstantUtil.WEB_PATH+(String) params[1];
			try {
				Bitmap bitmap=ProductService.getBitmapFromPath(path);
				Bitmap bitmap2=ProductService.getBitmapFromPath(path2);
				publishProgress(new Object[]{iv_head,bitmap,iv_image,bitmap2});//送给前台onProgressUpdat
			} catch (Exception e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			return null;
			
		}
		@Override
		protected void onProgressUpdate(Object... values) {
			ImageView iv_head = (ImageView) values[0];
			ImageView iv_image = (ImageView) values[2];
			Bitmap bitmap2 = (Bitmap) values[3];
			Bitmap bitmap = (Bitmap) values[1];
			iv_head.setImageBitmap(bitmap);
			iv_image.setImageBitmap(bitmap2);
			super.onProgressUpdate(values);
		}
	}
}
