package com.example.jky_34_jingdong.adapter;
import java.util.ArrayList;
import java.util.List;

import com.example.jky_34_jingdong.R;
import com.example.jky_34_jingdong.entity.ProductInfo;
import com.example.jky_34_jingdong.service.ProductService;
import com.example.jky_34_jingdong.util.ConstantUtil;

import android.content.Context;
import android.graphics.Bitmap;
import android.os.AsyncTask;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.ImageView;
import android.widget.TextView;

public class MiaoAdapter extends BaseAdapter {
	private List<ProductInfo> lists=new ArrayList<ProductInfo>();
	private LayoutInflater minInflater;
	public MiaoAdapter(Context context){
		minInflater=LayoutInflater.from(context);
	}
	public void setLists(List<ProductInfo> lists) {
		this.lists = lists;
	}
	@Override
	public int getCount() {
		// TODO Auto-generated method stub
		return lists.size();
	}

	@Override
	public Object getItem(int position) {
		// TODO Auto-generated method stub
		return lists.get(position);
	}

	@Override
	public long getItemId(int position) {
		// TODO Auto-generated method stub
		return position;
	}

	@Override
	public View getView(int position, View convertView, ViewGroup parent) {
		View view=minInflater.inflate(R.layout.lv_item_miao_product,null);
		
		ImageView miao_iv_products=(ImageView) view.findViewById(R.id.miao_iv_products);
		TextView miao_tv_description=(TextView) view.findViewById(R.id.miao_tv_description);
		TextView miao_tv_price=(TextView) view.findViewById(R.id.miao_tv_price);
		
		ProductInfo info=lists.get(position);
		miao_tv_description.setText(info.pro_description);
		miao_tv_price.setText("￥"+info.pro_price);
		
		LoadImageAsyncTask task=new LoadImageAsyncTask();
		Object[] params=new Object[]{info.pro_images,miao_iv_products};
		task.execute(params);
		return view;
	}
	private class LoadImageAsyncTask extends AsyncTask<Object, Object, Object>{

		@Override
		protected Object doInBackground(Object... params) {
			String path=ConstantUtil.WEB_PATH+(String) params[0];
			ImageView miao_iv_products=(ImageView) params[1];
			try {
				Bitmap bitmap=ProductService.getBitmapFromPath(path);
				bitmap=ConstantUtil.zoomBitmap(bitmap,100,100);
				publishProgress(new Object[]{bitmap,miao_iv_products});
			} catch (Exception e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			return null;
		}
		@Override
		protected void onProgressUpdate(Object... values) {
			Bitmap bitmap=(Bitmap) values[0];
			ImageView miao_iv_products=(ImageView) values[1];
			miao_iv_products.setImageBitmap(bitmap);
			super.onProgressUpdate(values);
		}
	}
}
