package com.example.jky_34_jingdong.adapter;
import java.util.ArrayList;
import java.util.List;

import com.example.jky_34_jingdong.R;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.TextView;
public class CategoryListAdapter extends BaseAdapter {
	private LayoutInflater mInflater;
	List<String> list=new ArrayList<String>();
	public void setList(List<String> list) {
		this.list = list;
	}
	public CategoryListAdapter(Context context) {
		mInflater=LayoutInflater.from(context);
	}
	@Override
	public int getCount() {
		// TODO Auto-generated method stub
		return list.size();
	}

	@Override
	public Object getItem(int position) {
		// TODO Auto-generated method stub
		return list.get(position);
	}

	@Override
	public long getItemId(int position) {
		// TODO Auto-generated method stub
		return position;
	}

	@Override
	public View getView(int position, View convertView, ViewGroup parent) {
		View view = mInflater.inflate(R.layout.lv_category_item, null);
		TextView tv_category_title= (TextView) view.findViewById(R.id.tv_category_title);
		String str=list.get(position);
		tv_category_title.setText(str);
		return view;
	}

}
