package com.example.jky_34_jingdong.adapter;
import java.util.ArrayList;
import java.util.List;

import com.example.jky_34_jingdong.R;
import com.example.jky_34_jingdong.entity.OrderInfo;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.TextView;
public class OrderAdapter extends BaseAdapter {
	private List<OrderInfo> lists=new ArrayList<OrderInfo>();
	private LayoutInflater mInflater;
	public OrderAdapter(Context context){
		mInflater=LayoutInflater.from(context);
	}
	
	public void setLists(List<OrderInfo> lists) {
		this.lists = lists;
	}
	@Override
	public int getCount() {
		// TODO Auto-generated method stub
		return lists.size();
	}
	@Override
	public Object getItem(int position) {
		// TODO Auto-generated method stub
		return lists.get(position);
	}

	@Override
	public long getItemId(int position) {
		// TODO Auto-generated method stub
		return position;
	}

	@Override
	public View getView(int position, View convertView, ViewGroup parent) {
		View view=mInflater.inflate(R.layout.lv_item_order,null);
		TextView tv_order_name=(TextView) view.findViewById(R.id.tv_order_name);
		TextView tv_order_address=(TextView) view.findViewById(R.id.tv_order_address);
		TextView tv_order_tel=(TextView) view.findViewById(R.id.tv_order_tel);
		TextView tv_order_count=(TextView) view.findViewById(R.id.tv_order_count);
		TextView tv_order_status=(TextView) view.findViewById(R.id.tv_order_status);
		TextView tv_order_date=(TextView) view.findViewById(R.id.tv_order_date);
		OrderInfo info=lists.get(position);
		tv_order_name.setText(info.name);
		tv_order_address.setText(info.address);
		tv_order_tel.setText(info.tel);
		tv_order_count.setText(info.count);
		tv_order_status.setText(info.status);
		tv_order_date.setText(info.date);
		return view;
	}

}
