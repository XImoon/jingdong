package com.example.jky_34_jingdong.adapter;
import java.util.ArrayList;
import java.util.List;

import com.example.jky_34_jingdong.R;
import com.example.jky_34_jingdong.entity.ProductInfo;
import com.example.jky_34_jingdong.service.ProductService;
import com.example.jky_34_jingdong.util.ConstantUtil;

import android.content.Context;
import android.graphics.Bitmap;
import android.os.AsyncTask;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.ImageView;
import android.widget.TextView;
public class ProductAdapter extends BaseAdapter {
	private List<ProductInfo> lists=new ArrayList<ProductInfo>();
	private LayoutInflater mInflater;
	public ProductAdapter(Context context){
		mInflater=LayoutInflater.from(context);
	}
	
	public void setLists(List<ProductInfo> lists) {
		this.lists = lists;
	}
	@Override
	public int getCount() {
		// TODO Auto-generated method stub
		return lists.size();
	}

	@Override
	public Object getItem(int position) {
		// TODO Auto-generated method stub
		return lists.get(position);
	}

	@Override
	public long getItemId(int position) {
		// TODO Auto-generated method stub
		return position;
	}

	@Override
	public View getView(int position, View convertView, ViewGroup parent) {
		View view=mInflater.inflate(R.layout.gv_item_miao_product,null);
		ImageView iv_miao_img=(ImageView) view.findViewById(R.id.iv_miao_img);
		TextView tv_miao_price=(TextView) view.findViewById(R.id.tv_miao_price);
		ProductInfo info=lists.get(position);
		//显示商品的价格
		tv_miao_price.setText("￥"+info.pro_price);
		//异步任务
		LoadImageAsyncTask task=new LoadImageAsyncTask();
		Object[] params=new Object[]{info.pro_images,iv_miao_img};
		task.execute(params);
		return view;
	}
	private class LoadImageAsyncTask extends AsyncTask<Object,Object,Object>{
		@Override
		protected Object doInBackground(Object... params) {
			String path=ConstantUtil.WEB_PATH+(String) params[0];
			ImageView iv_miao_img=(ImageView) params[1];
			try {
				Bitmap bitmap=ProductService.getBitmapFromPath(path);
				bitmap=ConstantUtil.zoomBitmap(bitmap,100,100);
				publishProgress(new Object[]{bitmap,iv_miao_img});
			} catch (Exception e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			return null;
		}
		@Override
		protected void onProgressUpdate(Object... values) {
			Bitmap bitmap=(Bitmap) values[0];
			ImageView iv_miao_img=(ImageView) values[1];
			iv_miao_img.setImageBitmap(bitmap);
			super.onProgressUpdate(values);
		}
	}

}
