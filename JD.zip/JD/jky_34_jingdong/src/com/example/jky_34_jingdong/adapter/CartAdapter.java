package com.example.jky_34_jingdong.adapter;

import java.util.ArrayList;
import java.util.List;

import com.example.jky_34_jingdong.R;
import com.example.jky_34_jingdong.entity.CartInfo;
import com.example.jky_34_jingdong.service.ProductService;
import com.example.jky_34_jingdong.util.ConstantUtil;

import android.content.Context;
import android.graphics.Bitmap;
import android.os.AsyncTask;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.ImageView;
import android.widget.TextView;

public class CartAdapter extends BaseAdapter {
	private List<CartInfo> lists=new ArrayList<CartInfo>();
	private LayoutInflater mInflater;
	public CartAdapter(Context context){
		mInflater=LayoutInflater.from(context);
	}
	
	public void setLists(List<CartInfo> lists) {
		this.lists = lists;
	}
	@Override
	public int getCount() {
		// TODO Auto-generated method stub
		return lists.size();
	}
	@Override
	public Object getItem(int position) {
		// TODO Auto-generated method stub
		return lists.get(position);
	}
	@Override
	public long getItemId(int position) {
		// TODO Auto-generated method stub
		return position;
	}
	@Override
	public View getView(int position, View convertView, ViewGroup parent) {
		// TODO Auto-generated method stub
		View view=mInflater.inflate(R.layout.lv_item_product_cart,null);
		ImageView iv_cart_img=(ImageView) view.findViewById(R.id.iv_cart_img);
		TextView tv_cart_description=(TextView) view.findViewById(R.id.tv_cart_description);
		TextView tv_cart_count=(TextView) view.findViewById(R.id.tv_cart_count);
		TextView tv_cart_price=(TextView) view.findViewById(R.id.tv_cart_price);
		CartInfo info=lists.get(position);
		tv_cart_description.setText(info.pro_description);
		tv_cart_count.setText("数量:"+info.pro_count);
		tv_cart_price.setText("￥"+info.pro_price);
		LoadImageAsyncTask task=new LoadImageAsyncTask();
		Object[] params=new Object[]{iv_cart_img,info.pro_images};
		task.execute(params);
		return view;
	}
	private class LoadImageAsyncTask extends AsyncTask<Object, Object, Object>{
		@Override
		protected Object doInBackground(Object... params) {
			ImageView iv_cart_img=(ImageView) params[0];
			String path=ConstantUtil.WEB_PATH+params[1];
			try {
				Bitmap bitmap=ProductService.getBitmapFromPath(path);
				//bitmap=ConstantUtil.manageImg(bitmap);
				bitmap=ConstantUtil.zoomBitmap(bitmap,100,100);
				publishProgress(new Object[]{bitmap,iv_cart_img});
			} catch (Exception e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			return null;
		}
		@Override
		protected void onProgressUpdate(Object... values) {
			Bitmap bitmap=(Bitmap) values[0];
			ImageView iv_cart_img=(ImageView) values[1];
			iv_cart_img.setImageBitmap(bitmap);
			super.onProgressUpdate(values);
		}
	}
}
