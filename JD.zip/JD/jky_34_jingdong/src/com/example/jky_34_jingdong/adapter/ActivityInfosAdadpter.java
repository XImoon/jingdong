package com.example.jky_34_jingdong.adapter;
import java.util.ArrayList;
import java.util.List;

import com.example.jky_34_jingdong.R;
import com.example.jky_34_jingdong.entity.ActivityInfos;
import com.example.jky_34_jingdong.service.ProductService;
import com.example.jky_34_jingdong.util.ConstantUtil;

import android.content.Context;
import android.graphics.Bitmap;
import android.os.AsyncTask;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.ImageView;
import android.widget.TextView;
public class ActivityInfosAdadpter extends BaseAdapter {
	private LayoutInflater mInflater;
	private List<ActivityInfos> list=new ArrayList<ActivityInfos>();
	public ActivityInfosAdadpter(Context context) {
		mInflater=LayoutInflater.from(context);
	}
	public void setList(List<ActivityInfos> list) {
		this.list = list;
	}
	@Override
	public int getCount() {
		// TODO Auto-generated method stub
		return list.size();
	}

	@Override
	public Object getItem(int position) {
		// TODO Auto-generated method stub
		return list.get(position);
	}

	@Override
	public long getItemId(int position) {
		// TODO Auto-generated method stub
		return position;
	}

	@Override
	public View getView(int position, View convertView, ViewGroup parent) {
		View view = mInflater.inflate(R.layout.lv_activity_item, null);
		ImageView tv_activity_img=(ImageView) view.findViewById(R.id.tv_activity_img);
		TextView tv_activity_title=(TextView) view.findViewById(R.id.tv_activity_title);
		TextView tv_activity_content=(TextView) view.findViewById(R.id.tv_activity_content);
		TextView iv_activity_count=(TextView) view.findViewById(R.id.iv_activity_count);
		ActivityInfos infos = list.get(position);
		tv_activity_content.setText(infos.activity_content);
		tv_activity_title.setText(infos.activity_title);
		iv_activity_count.setText(infos.activity_count+"");
		//异步
		AsyncTaskLeaderImg aLeaderImage=new AsyncTaskLeaderImg();
		//送一个ImageView 和BitMap
		String path=infos.activity_image;
		//前面放UI 后面放路径
		aLeaderImage.execute(tv_activity_img,path);
		return view;
	}
	class AsyncTaskLeaderImg extends AsyncTask<Object, Object, Object>{
		@Override
		protected Object doInBackground(Object... params) {
			// 拿参数
			ImageView iv_head=(ImageView) params[0];
			String path=ConstantUtil.WEB_PATH+(String) params[1];
			try {
				Bitmap bitmap=ProductService.getBitmapFromPath(path);
				//加载
				publishProgress(new Object[]{iv_head,bitmap});
			} catch (Exception e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			return null;
		}
		@Override
		protected void onProgressUpdate(Object... values) {
			ImageView iv_head=(ImageView) values[0];
			Bitmap bitmap=(Bitmap) values[1];
			iv_head.setImageBitmap(bitmap);
			super.onProgressUpdate(values);
		}
	}
}
