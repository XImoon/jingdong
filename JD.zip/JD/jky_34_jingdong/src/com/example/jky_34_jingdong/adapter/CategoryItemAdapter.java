package com.example.jky_34_jingdong.adapter;
import java.util.ArrayList;
import java.util.List;

import com.example.jky_34_jingdong.R;
import com.example.jky_34_jingdong.entity.ProductInfo;
import com.example.jky_34_jingdong.service.ProductService;
import com.example.jky_34_jingdong.util.ConstantUtil;

import android.content.Context;
import android.graphics.Bitmap;
import android.os.AsyncTask;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.ImageView;
import android.widget.TextView;
public class CategoryItemAdapter extends BaseAdapter {
	private LayoutInflater mInflater;
	private List<ProductInfo> lists=new ArrayList<ProductInfo>();
	public CategoryItemAdapter(Context context) {
		mInflater=LayoutInflater.from(context);
	}
	public void setLists(List<ProductInfo> lists) {
		this.lists = lists;
	}
	@Override
	public int getCount() {
		// TODO Auto-generated method stub
		return lists.size();
	}

	@Override
	public Object getItem(int position) {
		// TODO Auto-generated method stub
		return lists.get(position);
	}

	@Override
	public long getItemId(int position) {
		// TODO Auto-generated method stub
		return position;
	}
	@Override
	public View getView(int position, View convertView, ViewGroup parent) {
		View view = mInflater.inflate(R.layout.lv_category_list, null);
		ImageView iv_cg_list=(ImageView) view.findViewById(R.id.iv_cg_list);
		TextView tv_cg_name=(TextView) view.findViewById(R.id.tv_cg_name);
		TextView tv_cg_price=(TextView) view.findViewById(R.id.tv_cg_price);
		ProductInfo info=lists.get(position);
		tv_cg_name.setText(info.pro_description);
		tv_cg_price.setText("￥"+info.pro_price);
		//异步
		AsyncTaskLeaderImage aLeaderImage=new AsyncTaskLeaderImage();
		String path=info.pro_images;
		aLeaderImage.execute(iv_cg_list,path);
		return view;
	}
	class AsyncTaskLeaderImage extends AsyncTask<Object, Object, Object>{
		@Override
		protected Object doInBackground(Object... params) {
			ImageView iv_head=(ImageView) params[0];
			String path=ConstantUtil.WEB_PATH+(String) params[1];
			try {
				Bitmap bitmap=ProductService.getBitmapFromPath(path);
				bitmap=ConstantUtil.zoomBitmap(bitmap,100, 100);
				publishProgress(new Object[]{iv_head,bitmap});
			} catch (Exception e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			return null;
		}
		@Override
		protected void onProgressUpdate(Object... values) {
			ImageView iv_head=(ImageView) values[0];
			Bitmap bitmap=(Bitmap) values[1];
			iv_head.setImageBitmap(bitmap);
			super.onProgressUpdate(values);
		}
	}
}
