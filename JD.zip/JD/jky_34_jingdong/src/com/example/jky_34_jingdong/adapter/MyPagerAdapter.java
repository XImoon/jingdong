package com.example.jky_34_jingdong.adapter;
import java.util.ArrayList;

import android.support.v4.view.PagerAdapter;
import android.support.v4.view.ViewPager;
import android.view.View;
public class MyPagerAdapter extends PagerAdapter {
	private ArrayList<View> views;
	private ArrayList<String> titles;
	public MyPagerAdapter(ArrayList<View> views,ArrayList<String> titles){
		this.views = views;
		this.titles = titles;
	}
	@Override
	public int getCount() {
		// TODO Auto-generated method stub
		return this.views.size();
	}

	@Override
	public boolean isViewFromObject(View arg0, Object arg1) {
		// TODO Auto-generated method stub
		return arg0 == arg1;
	}
	@Override
	public void destroyItem(View container, int position, Object object) {
		((ViewPager) container).removeView(views.get(position));
	}
	@Override
	public CharSequence getPageTitle(int position) {
		return titles.get(position);
	}
	// 页面view
	public Object instantiateItem(View container, int position) {
		((ViewPager) container).addView(views.get(position));
		return views.get(position);
	}
}
