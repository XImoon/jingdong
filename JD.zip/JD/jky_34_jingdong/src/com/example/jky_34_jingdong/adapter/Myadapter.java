package com.example.jky_34_jingdong.adapter;
import com.example.jky_34_jingdong.R;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.TextView;
public class Myadapter extends BaseAdapter {
	private int[] a=new int[]{};
	private LayoutInflater minInflater;
	public Myadapter(Context context ,int[] a){
		this.a=a;
		minInflater=LayoutInflater.from(context);	
	}
	@Override
	public int getCount() {
		// TODO Auto-generated method stub
		return a.length;
	}

	@Override
	public Object getItem(int position) {
		// TODO Auto-generated method stub
		return a[position];
	}

	@Override
	public long getItemId(int position) {
		// TODO Auto-generated method stub
		return position;
	}

	@Override
	public View getView(int position, View convertView, ViewGroup parent) {
		//首先加载XML文件
		View view=minInflater.inflate(R.layout.award_item, null);
		//找到xml文件里面的控件
		TextView tv_award=(TextView) view.findViewById(R.id.tv_award);	
		//找到数据
		int i=a[position];	
		//绑定数据到控件上面
		tv_award.setText(i+"");	
		return view;
	}

}
