package com.example.jky_34_jingdong;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import com.example.jky_34_jingdong.adapter.CategoryItemAdapter;
import com.example.jky_34_jingdong.entity.ProductInfo;
import com.example.jky_34_jingdong.service.CategoryToService;
import com.example.jky_34_jingdong.util.ConstantUtil;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.os.Handler;
import android.os.Message;
import android.view.View;
import android.widget.AdapterView;
import android.widget.AdapterView.OnItemClickListener;
import android.widget.ListView;
import android.widget.TextView;
public class CategoryListActivity extends Activity {
	private TextView tv_category_item;
	private ListView lv_single_item;
	private CategoryItemAdapter adapter;
	Map<String,String> map=new HashMap<String, String>();
	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.activity_category_list);
		init();
		Intent intent=getIntent();
		String pro_category=intent.getStringExtra("category");
		tv_category_item.setText(pro_category);
		//ConstantUtil.MyToast(pro_category, this);
		final CategoryToService service=new CategoryToService();
		map.put("pro_category",pro_category);
		adapter=new CategoryItemAdapter(this);
		new Thread(){
			public void run() {
				try {
					List<ProductInfo> list = service.getItemGetCategory(ConstantUtil.PRODUCT_PATH, map);
					if(list!=null){
						Message message = mHandler.obtainMessage();
						message.what=ConstantUtil.NET_SUCCESS;
						message.obj=list;
						mHandler.sendMessage(message);
					}else{
						mHandler.sendEmptyMessage(ConstantUtil.NET_NOT_DATA);
					}
				} catch (Exception e) {
					mHandler.sendEmptyMessage(ConstantUtil.NET_FAIL);
					e.printStackTrace();
				}
			}
		}.start();
		lv_single_item.setAdapter(adapter);
		lv_single_item.setOnItemClickListener(new MyListener());
	}
	private class MyListener implements OnItemClickListener{
		@Override
		public void onItemClick(AdapterView<?> parent, View view, int position,
				long id) {
			ProductInfo info=(ProductInfo) adapter.getItem(position);
			Intent intent=new Intent(CategoryListActivity.this,ProductDetailActivity.class);
			intent.putExtra("product",info);
			startActivity(intent);
		}
	}
	private Handler mHandler=new Handler(){
		public void handleMessage(Message msg) {
			switch (msg.what) {
			case ConstantUtil.NET_SUCCESS:
				List<ProductInfo> lists=(List<ProductInfo>) msg.obj;
				//Toast.makeText(CategoryListActivity.this, lists+"", Toast.LENGTH_LONG).show();
				adapter.setLists(lists);
				//刷新
				adapter.notifyDataSetChanged();
				if(lists==null||lists.size()==0){
					tv_category_item.setText("该类商品暂时缺货！");
				}
				break;
			default:
				break;
			}
		};
	};
	private void init() {
		tv_category_item=(TextView) findViewById(R.id.tv_category_item);
		lv_single_item=(ListView) findViewById(R.id.lv_single_item);
	}
}
