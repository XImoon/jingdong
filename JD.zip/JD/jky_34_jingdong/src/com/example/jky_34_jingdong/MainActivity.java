package com.example.jky_34_jingdong;
import android.app.TabActivity;
import android.content.Intent;
import android.os.Bundle;
import android.widget.RadioGroup;
import android.widget.RadioGroup.OnCheckedChangeListener;
import android.widget.TabHost;
public class MainActivity extends TabActivity implements OnCheckedChangeListener {
	private RadioGroup mTabButtonGroup;
	private TabHost mTabHost;
	public static final String TAB_MAIN="HOME_ACTIVITY";
	public static final String TAB_CATEGORY="CATEGORY_ACTIVITY";
	public static final String TAB_FIND="FIND_ACTIVITY";
	public static final String TAB_CART="CART_ACTIVITY";
	public static final String TAB_PERSONAL="PERSONAL_ACTIVITY";
	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.activity_main);
		init();
	}
	private void init() {
		mTabHost=getTabHost();
		mTabButtonGroup=(RadioGroup) findViewById(R.id.home_radio_button_group);
		mTabHost.addTab(mTabHost.newTabSpec(TAB_MAIN).setIndicator(TAB_MAIN)
				.setContent(new Intent(this, IndexActivity.class)));
		mTabHost.addTab(mTabHost.newTabSpec(TAB_CATEGORY)
				.setIndicator(TAB_CATEGORY).setContent(new Intent(this, CategoryActivity.class)));
		mTabHost.addTab(mTabHost.newTabSpec(TAB_FIND)
				.setIndicator(TAB_FIND).setContent(new Intent(this, FindActivity.class)));
		mTabHost.addTab(mTabHost.newTabSpec(TAB_CART).setIndicator(TAB_CART)
				.setContent(new Intent(this, CartActivity.class)));
		mTabHost.addTab(mTabHost.newTabSpec(TAB_PERSONAL)
				.setIndicator(TAB_PERSONAL).setContent(new Intent(this, PersonalActivity.class)));
		mTabHost.setCurrentTabByTag(TAB_MAIN);
		mTabButtonGroup=(RadioGroup) findViewById(R.id.home_radio_button_group);
		mTabButtonGroup.setOnCheckedChangeListener(this);
	}

	@Override
	public void onCheckedChanged(RadioGroup group, int checkedId) {
		switch (checkedId) {
		case R.id.home_tab_main:
			mTabHost.setCurrentTabByTag(TAB_MAIN);
			break;

		case R.id.home_tab_search:
			mTabHost.setCurrentTabByTag(TAB_FIND);
			break;
		case R.id.home_tab_category:
			mTabHost.setCurrentTabByTag(TAB_CATEGORY);
			break;

		case R.id.home_tab_cart:
			mTabHost.setCurrentTabByTag(TAB_CART);
			break;

		case R.id.home_tab_personal:
			mTabHost.setCurrentTabByTag(TAB_PERSONAL);
			break;

		default:
			break;
		}
	}
}
