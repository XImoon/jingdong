package com.example.jky_34_jingdong.db;
import android.content.Context;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteDatabase.CursorFactory;
import android.database.sqlite.SQLiteOpenHelper;
public class DBHelper extends SQLiteOpenHelper {
	static String DATEBASE_NAME="jd.db";
	static int VERSION=4;
	private DBHelper(Context context, String name, CursorFactory factory,
			int version) {
		super(context, name, factory, version);
		// TODO Auto-generated constructor stub
	}
	private static DBHelper dbHelper;
	public static DBHelper getDBHelperInstance(Context context){
		if(dbHelper==null){
			dbHelper=new DBHelper(context, DATEBASE_NAME, null, VERSION);
		}
		return dbHelper;
	}
	@Override
	public void onCreate(SQLiteDatabase db) {
		// TODO Auto-generated method stub
		String sql1="create table cart(_id Integer primary key autoincrement,pro_id Integer,pro_description text,pro_price real,pro_count Integer check(pro_count>0),pro_images text)";
		String sql2="create table scan(_id Integer primary key autoincrement,pro_id Integer,pro_description text,pro_price real,pro_images text,status text)";
		String sql3="create table users(_id Integer,username text,userpass text, balance text,user_pic text)";
		String sql4="create table searchinfo (_id Integer primary key autoincrement,search_xontent text,count Integer)";		
		db.execSQL(sql1);
		db.execSQL(sql2);
		db.execSQL(sql3);
		db.execSQL(sql4);
	}
	@Override
	public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {
		
	}
}
