package com.example.jky_34_jingdong;
import java.util.List;

import com.example.jky_34_jingdong.adapter.CartAdapter;
import com.example.jky_34_jingdong.entity.CartInfo;
import com.example.jky_34_jingdong.entity.UserInfo;
import com.example.jky_34_jingdong.service.CartService;
import com.example.jky_34_jingdong.service.LoginService;
import com.example.jky_34_jingdong.util.ConstantUtil;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.AdapterView.OnItemClickListener;
import android.widget.ListView;
import android.widget.TextView;
public class CartActivity extends Activity{
	private ListView lv_cart_product;
	private CartAdapter cartAdapter;
	private TextView tv_cart_count;
	private int count=0;
	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.activity_cart);
		init();
		cartAdapter=new CartAdapter(this);
		CartService service=new CartService(this);
		List<CartInfo> lists=service.showCart();
		cartAdapter.setLists(lists);
		for (CartInfo info : lists) {
			count+=info.pro_price;
		}
		tv_cart_count.setText("总计:"+count);
		lv_cart_product.setAdapter(cartAdapter);
		cartAdapter.notifyDataSetChanged();
		lv_cart_product.setOnItemClickListener(new MyListener());
	}
	private class MyListener implements OnItemClickListener{
		@Override
		public void onItemClick(AdapterView<?> parent, View view, int position,
				long id) {
			CartInfo info=(CartInfo)cartAdapter.getItem(position);
			//ConstantUtil.MyToast(info.pro_description,CartActivity.this);
			Intent intent=new Intent(CartActivity.this,UpdateCartActivity.class);
			intent.putExtra("cartinfo",info);
			startActivity(intent);
		}
	} 
	private void init() {
		lv_cart_product=(ListView) findViewById(R.id.lv_cart_product);
		tv_cart_count=(TextView) findViewById(R.id.tv_cart_count);
	}
	public void submit_order(View view){
		LoginService service=new LoginService(this);
		UserInfo info = service.query();
		if(info!=null){
			Intent intent=new Intent(this, OrderActivity.class);
			intent.putExtra("count",count+"");
			intent.putExtra("username",info.username);
			startActivity(intent);
		}else{
			Intent intent=new Intent(this, LoginActivity.class);
			startActivity(intent);
		}
	}
}
