package com.example.jky_34_jingdong.test;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import android.R.bool;
import android.database.Cursor;
import android.test.AndroidTestCase;

import com.example.jky_34_jingdong.db.DBHelper;
import com.example.jky_34_jingdong.entity.CartInfo;
import com.example.jky_34_jingdong.entity.OrderInfo;
import com.example.jky_34_jingdong.entity.ProductInfo;
import com.example.jky_34_jingdong.entity.ScanInfo;
import com.example.jky_34_jingdong.entity.StoryInfo;
import com.example.jky_34_jingdong.entity.UserInfo;
import com.example.jky_34_jingdong.entity.VersionInfo;
import com.example.jky_34_jingdong.service.CartService;
import com.example.jky_34_jingdong.service.LoginService;
import com.example.jky_34_jingdong.service.OrderService;
import com.example.jky_34_jingdong.service.ProductService;
import com.example.jky_34_jingdong.service.ScanService;
import com.example.jky_34_jingdong.service.SerchDao;
import com.example.jky_34_jingdong.service.StorySevice;
import com.example.jky_34_jingdong.service.VersionService;
import com.example.jky_34_jingdong.util.ConstantUtil;
public class MyTest extends AndroidTestCase {
	//测试从服务器拿数据
	public void testGetProductsFromGson()throws Exception{
		String path="http://192.168.191.1:8080/jd/IndexServlet";
		ProductService service=new ProductService();
		List<ProductInfo> lists=service.getProductsFromGson(path);
		for (ProductInfo info : lists) {
			System.out.println(info+"==========");
		}
	}
	//创建数据库
	public void testCreateDataBase(){
		DBHelper dbHelper=DBHelper.getDBHelperInstance(getContext());
		dbHelper.getReadableDatabase();
	}
	//测试添加商品到购物车
	public void testadd(){
		CartService service=new CartService(getContext());
		boolean flag=service.addProduct(new CartInfo(1,"我们的",10,3,"123"));
	}
	//查询
	public void testquery(){
		CartService service=new CartService(getContext());
		List<CartInfo> lists=service.showCart();
		for (CartInfo info : lists) {
			System.out.println(info+"=========");
		}
//		CartInfo info=service.findById(1);
//		System.out.println(info+"========");
	}
	//修改
	public void testUpdate(){
		CartService service=new CartService(getContext());
		boolean flag=service.updateCart(new CartInfo(5,1,"2222",12,3,"345"));
	}
	//清空购物车
	public void testDelete(){
		CartService service=new CartService(getContext());
		boolean flag=service.deleteCart();
	}
	public void testAddScan(){
		ScanService service=new ScanService(getContext());
		ScanInfo info=new ScanInfo();
		info.pro_id=2;
		info.pro_description="2222222222";
		info.pro_price=200;
		info.pro_images="1234";
		info.status="000";		
		service.addScan(info);
	}
	public void testQuery(){
		ScanService service=new ScanService(getContext());
		//boolean flag=service.query(1,);
		//System.out.println(flag+"=================");
	}
	public void testQueryAll(){
		ScanService service=new ScanService(getContext());
		List<ScanInfo> lists=service.queryAll("最近浏览");
		for (ScanInfo info : lists) {
			System.out.println(info+"=============");
		}
	}
	public void testDeleteScan(){
		ScanService service=new ScanService(getContext());
		boolean flag=service.deleteScan(2);
		System.out.println(flag+"==========");
	}
	public void testAddUser(){
		LoginService service=new LoginService(getContext());
		UserInfo info=new UserInfo();
		info._id=1;
		info.username="admin";
		info.userpass="123";
		info.user_pic="1111";
		info.balance="100";
		boolean flag=service.addUser(info);
		System.out.println(flag+"=========");
	}
	public void testQueryUser(){
		LoginService service=new LoginService(getContext());
		UserInfo info=service.query();
		System.out.println(info+"=========");
	}
	public void testUpdateUser(){
		LoginService service=new LoginService(getContext());
		UserInfo info=new UserInfo();
		info._id=2;
		info.username="admin2";
		info.userpass="1232";
		info.user_pic="11112";
		info.balance="1002";
		boolean flag=service.update(info);
		System.out.println(flag+"=========");
	}
	public void testDeleteUser(){
		LoginService service=new LoginService(getContext());
		boolean flag=service.delete();
		System.out.println(flag+"========");
	}
	public void testSearch(){
		SerchDao dao=new SerchDao(getContext());
		Cursor cs=dao.findByCount();
		
	}
	public void getVersions()throws Exception{
		VersionService service=new VersionService();
		String path="http://192.168.191.1:8080/jd/version.xml";
		VersionInfo info=service.getVersionInfo(path,"utf-8");
		System.out.println(info+"======");
	}
	public void getStory()throws Exception{
		StorySevice sevice=new StorySevice();
		List<StoryInfo> lists= sevice.getPersonsFromGson(ConstantUtil.STORY_PATH);
		for (StoryInfo info : lists) {
			System.out.println(info+"============");
		}
	}
	public void testAddOrder()throws Exception{
		OrderService service=new OrderService();
		String path="http://192.168.191.1:8080/jd/MyOrderServlet";
		Map<String, String> map=new HashMap<String, String>();
		map.put("name","admin");
//		map.put("address","12");
//		map.put("tel","123");
//		map.put("count","100");
		//String msg=service.addOrder(path, map);
		List<OrderInfo> lists=service.getMyOrder(path, map);
		System.out.println(lists+"============");
	}
}
