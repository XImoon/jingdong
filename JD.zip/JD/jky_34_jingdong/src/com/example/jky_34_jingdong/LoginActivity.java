package com.example.jky_34_jingdong;
import java.util.HashMap;
import java.util.Map;

import android.app.Activity;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.SharedPreferences.Editor;
import android.os.Bundle;
import android.os.Handler;
import android.os.Message;
import android.text.TextUtils;
import android.view.View;
import android.widget.CheckBox;
import android.widget.EditText;
import android.widget.Toast;

import com.example.jky_34_jingdong.entity.UserInfo;
import com.example.jky_34_jingdong.service.LoginService;
import com.example.jky_34_jingdong.service.UserService;
import com.example.jky_34_jingdong.util.ConstantUtil;
public class LoginActivity extends Activity {
	private EditText et_name,et_pass;
	private CheckBox cb_pass;
	String path="http://192.168.191.1:8080/jd/LoginServlet";
	//共享首选项来保存数据
	private SharedPreferences sp;
	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.activity_login);
		init();
		//判断是否记住了密码
		sp=getSharedPreferences("config", Context.MODE_PRIVATE);
		boolean isChecked = sp.getBoolean("isChecked", false);
		if(isChecked==true){
			String name = sp.getString("name", null);
			String password=sp.getString("password", null);
			et_name.setText(name);
			et_pass.setText(password);
		}else{
			//什么都不做
		}
	}
	private void init() {
		cb_pass=(CheckBox) findViewById(R.id.cb_pass);
		et_name=(EditText) findViewById(R.id.et_name);
		et_pass=(EditText) findViewById(R.id.et_pass);	
	}
	public void login(View view){
		//得到编辑框中的值
		final String name = et_name.getText()+"";
		final String pass=et_pass.getText()+"";
		if(TextUtils.isEmpty(name)){
			ConstantUtil.MyToast("用户名不能为空",this);
			return;
		}else if(TextUtils.isEmpty(pass)){
			ConstantUtil.MyToast("密码不能为空",this);
			return;
		
		}
		//1,看有没有被勾选
		if(cb_pass.isChecked()){
			//2,如果被勾选就保存到共享首选项中去第一个参数就是xml文件名第二个参数是打开的模式
			sp = getSharedPreferences("config", Context.MODE_PRIVATE);
			Editor edit = sp.edit();
			edit.putBoolean("isChecked", true);
			edit.putString("name", name);
			edit.putString("password", pass);
			//3,一定要提交
			edit.commit();					
		}else{
			//清空所有数据
			Editor edit = sp.edit();
			edit.clear();
			edit.commit();
		}
		new Thread(){
			public void run() {	
				try {
					Map<String, String> map=new HashMap<String, String>();
					map.put("username", name);
					map.put("userpass", pass);
					UserInfo info=UserService.login(path, map);
					if(info.username!=null){
						Message message=mHandler.obtainMessage();
						message.what=1;
						message.obj=info;
						mHandler.sendMessage(message);
					}else {
						mHandler.sendEmptyMessage(2);
					}
				} catch (Exception e) {
						mHandler.sendEmptyMessage(3);
					e.printStackTrace();
				}
				
				
			};		
		}.start();
	}
	//开主线程
	private Handler mHandler=new Handler(){
		public void handleMessage(Message msg) {
			UserInfo info=(UserInfo) msg.obj;
			if(msg.what==1){
				ConstantUtil.MyToast("登陆成功!", LoginActivity.this);
				LoginService service=new LoginService(LoginActivity.this);
				UserInfo user=service.query();
				if(user!=null){
					service.update(info);
				}else{
					service.addUser(info);
				}
				Intent intent=new Intent(LoginActivity.this,MainActivity.class);
				startActivity(intent);
			}else if(msg.what==2){
				ConstantUtil.MyToast("用户名不正确", LoginActivity.this);
			}else if(msg.what==3){
				ConstantUtil.MyToast("联网失败", LoginActivity.this);
			}
			
		};
	};
	//按钮点击事件,跳转到注册页面
	public void jump(View view){
		startActivity(new Intent(this,RegisterActivty.class));
	}
}
