package com.example.jky_34_jingdong;
import android.app.Activity;
import android.app.AlertDialog;
import android.content.DialogInterface;
import android.content.DialogInterface.OnClickListener;
import android.content.Intent;
import android.graphics.Bitmap;
import android.os.Bundle;
import android.os.Handler;
import android.os.Message;
import android.view.View;
import android.widget.ImageView;
import android.widget.TextView;

import com.example.jky_34_jingdong.entity.CartInfo;
import com.example.jky_34_jingdong.service.CartService;
import com.example.jky_34_jingdong.service.ProductService;
import com.example.jky_34_jingdong.util.ConstantUtil;
public class UpdateCartActivity extends Activity {
	private ImageView update_cart_img;
	private TextView update_cart_pro_count;
	private CartInfo info;
	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.activity_update_cart);
		Intent intent=getIntent();
		info=(CartInfo) intent.getSerializableExtra("cartinfo");
		init();
		changeCount();
		new Thread(){
			public void run() {
				try {
					Bitmap bitmap=ProductService.getBitmapFromPath(ConstantUtil.WEB_PATH+info.pro_images);
					if(bitmap!=null){
						Message msg=mHandler.obtainMessage();
						msg.what=ConstantUtil.NET_SUCCESS;
						msg.obj=bitmap;
						mHandler.sendMessage(msg);
					}else{
						mHandler.sendEmptyMessage(ConstantUtil.NET_NOT_DATA);
					}
				} catch (Exception e) {
					mHandler.sendEmptyMessage(ConstantUtil.NET_FAIL);
					e.printStackTrace();
				}
			};
		}.start();
	}
	private Handler mHandler=new Handler(){
		public void handleMessage(android.os.Message msg) {
			switch (msg.what) {
			case ConstantUtil.NET_SUCCESS:
				Bitmap bitmap=(Bitmap) msg.obj;
				update_cart_img.setImageBitmap(bitmap);
				break;
			case ConstantUtil.NET_NOT_DATA:
				
				break;
			case ConstantUtil.NET_FAIL:
	
				break;
			default:
				break;
			}
		};
	};
	public void decrease_product(View view){
		info.pro_count-=1;
		if(info.pro_count<=0){
			AlertDialog.Builder builder=new AlertDialog.Builder(this);
			builder.setMessage("是否将此商品从购物车移除？");
			builder.setNegativeButton("取消", new OnClickListener() {
				@Override
				public void onClick(DialogInterface dialog, int which) {
					// TODO Auto-generated method stub
					info.pro_count+=1;
					dialog.dismiss();
				}
			});
			builder.setPositiveButton("确定", new OnClickListener() {
				@Override
				public void onClick(DialogInterface dialog, int which) {
					CartService service=new CartService(UpdateCartActivity.this);
					boolean flag=service.deleteById(info._id);
					if(flag){
						jump();
					}
				}
			});
			builder.show();
		}else{
			CartService service=new CartService(this);
			service.updateCart(info);
			changeCount();
		}
	}
	private void jump(){
		Intent intent=new Intent(UpdateCartActivity.this,MainActivity.class);
		startActivity(intent);
	}
	public void add_product(View view){
		info.pro_count+=1;
		CartService service=new CartService(this);
		service.updateCart(info);
		changeCount();
	}
	private void changeCount() {
		update_cart_pro_count.setText(info.pro_count+"");
	}
	private void init() {
		update_cart_img=(ImageView) findViewById(R.id.update_cart_img);
		update_cart_pro_count=(TextView) findViewById(R.id.update_cart_pro_count);
	}
	public void delete_product(View view){
		CartService service=new CartService(this);
		boolean flag=service.deleteById(info._id);
		if(flag){
			jump();
		}
	}
	public void save_update(View view){
		jump();
	}
}
