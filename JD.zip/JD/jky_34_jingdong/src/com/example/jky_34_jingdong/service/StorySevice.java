package com.example.jky_34_jingdong.service;

import java.io.BufferedReader;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.util.List;

import org.apache.http.HttpResponse;
import org.apache.http.client.HttpClient;
import org.apache.http.client.methods.HttpGet;
import org.apache.http.client.methods.HttpPost;
import org.apache.http.impl.client.DefaultHttpClient;
import org.apache.http.params.CoreConnectionPNames;

import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import com.example.jky_34_jingdong.entity.StoryInfo;
import com.google.gson.Gson;
import com.google.gson.reflect.TypeToken;

public class StorySevice {
	
	public static Bitmap getBitMapFromWebpath(String path)throws Exception{
		Bitmap bitmap=null;
		HttpClient client= new DefaultHttpClient();
		HttpGet request = new HttpGet(path);
		HttpResponse response = client.execute(request);
		if(response.getStatusLine().getStatusCode() ==200){
			InputStream is =response.getEntity().getContent();
			bitmap = BitmapFactory.decodeStream(is);
		}
		return bitmap;
	}
	
	public List<StoryInfo> getPersonsFromGson(String path)
		throws Exception{
			List<StoryInfo> list = null;
			HttpClient client = new DefaultHttpClient();
			HttpPost request = new HttpPost(path);
			request.getParams().setIntParameter(CoreConnectionPNames.CONNECTION_TIMEOUT, 5000);
			HttpResponse response = client.execute(request);
			if (response.getStatusLine().getStatusCode() == 200) {
				InputStream is =response.getEntity().getContent();
				String gson = parserISToGson(is);
				System.out.println(gson);
				list = parserStrToGson(gson);
			}
			return list;
	}
	private String parserISToGson(InputStream is) throws Exception{
		String line = null;
		InputStreamReader isr = new InputStreamReader(is);
		BufferedReader br = new BufferedReader(isr);
		StringBuffer sb = new StringBuffer();
		while ((line=br.readLine())!=null) {
			sb.append(line);
		}
		String gson = sb.toString();
		br.close();
		isr.close();
		return gson;
	}
	private List<StoryInfo> parserStrToGson(String msg){
		Gson gson = new Gson();
		TypeToken<List<StoryInfo>> token = new TypeToken<List<StoryInfo>>(){
			
		};
		return gson.fromJson(msg, token.getType());
		
	}
}
