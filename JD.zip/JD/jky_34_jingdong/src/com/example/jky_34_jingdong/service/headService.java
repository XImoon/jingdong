package com.example.jky_34_jingdong.service;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import com.example.jky_34_jingdong.R;
public class headService {
public  static int[] heads={R.drawable.daqiao,R.drawable.guojia,R.drawable.huanggai,R.drawable.huangyueying,R.drawable.machao,R.drawable.sunshangxiang,};
	
	public static List<Map<String, Object>> getimage(){		
		List<Map<String,Object>> lists=new ArrayList<Map<String,Object>>();			
			//循环添5条数据
			for (int i = 0; i < 6; i++) {
				Map<String, Object> map=new HashMap<String, Object>();
				map.put("head", heads[i]);
				lists.add(map);
			}
			return lists;		
	}
	
}
