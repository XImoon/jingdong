package com.example.jky_34_jingdong.service;

import java.io.BufferedReader;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.util.Map;
import java.util.Map.Entry;

import org.apache.http.HttpResponse;
import org.apache.http.client.HttpClient;
import org.apache.http.client.methods.HttpGet;
import org.apache.http.impl.client.DefaultHttpClient;
import org.apache.http.params.CoreConnectionPNames;

import com.example.jky_34_jingdong.entity.UserInfo;
import com.google.gson.Gson;
import com.google.gson.reflect.TypeToken;

public class UserService {
	//1、登录使用的方法	
	//http://192.168.191.1:8080/jingdong/LoginServlet
	//?username=aaa&userpass=123
	public static UserInfo login(String path,Map<String, String> map)throws Exception{
		UserInfo info=new UserInfo();
		StringBuffer sb=new StringBuffer();
		sb.append(path).append("?");
		//拼接路径
		for (Entry<String, String> temp :map.entrySet()) {
			sb.append(temp.getKey());
			sb.append("=");
			sb.append(temp.getValue());
			sb.append("&");	
		}
		sb.deleteCharAt(sb.length()-1);
		//联网
		HttpClient client=new DefaultHttpClient();
		//请求方式
		HttpGet request=new HttpGet(sb.toString());
		//设置超时
		request.getParams().setIntParameter(CoreConnectionPNames.CONNECTION_TIMEOUT, 5000);
		//敲回车
		HttpResponse response=client.execute(request);
		//判断
		if(response.getStatusLine().getStatusCode()==200){
			InputStream is = response.getEntity().getContent();
			String gson=parseIsToGson(is);
			info=parseStrToGson(gson);
		}
		return info;
	}
	private static UserInfo parseStrToGson(String msg) {
		Gson gson=new Gson();
		TypeToken<UserInfo> token=new TypeToken<UserInfo>(){
			
		};
		return gson.fromJson(msg, token.getType());
	}
	private static String parseIsToGson(InputStream is) throws Exception{
		String line=null;
		InputStreamReader isr=new InputStreamReader(is);
		BufferedReader br=new BufferedReader(isr);
		StringBuilder sb=new StringBuilder();
		while((line=br.readLine())!=null){
			sb.append(line);
		}
		String gson=sb.toString();
		br.close();
		isr.close();
		return gson;
	}
	private static String paresSting(InputStream is) throws Exception{
		BufferedReader br=new BufferedReader(new InputStreamReader(is));
		StringBuffer sb=new StringBuffer();
		String readLine = br.readLine();
		while(readLine!=null){
			sb.append(readLine);
			readLine=br.readLine();
		}
		String string =sb.toString().trim();
		return string;
	}
	//2、注册使用的方法
	//http://192.168.191.1:8080/jingdong/RegisterServlet?
	//username=aaa&password=123
	public static String register(String path,Map<String, String> map)throws Exception{
		//拼接路径
		StringBuffer sb=new StringBuffer();
		sb.append(path).append("?");
		for (Entry<String, String> temp : map.entrySet()) {
			sb.append(temp.getKey());
			sb.append("=");
			sb.append(temp.getValue());
			sb.append("&");
		}
		sb.deleteCharAt(sb.length()-1);	
		//联网
		HttpClient client=new DefaultHttpClient();
		//设置请求参数
		HttpGet request=new HttpGet(sb.toString());
		//设置超时
		request.getParams().setIntParameter(CoreConnectionPNames.CONNECTION_TIMEOUT, 5000);
		//敲回车
		HttpResponse response = client.execute(request);
		if(response.getStatusLine().getStatusCode()==200){
			InputStream is = response.getEntity().getContent();
			String msg=paresSting(is);
			return msg;
		}
		return null;
	}
}
