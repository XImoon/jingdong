package com.example.jky_34_jingdong.service;

import java.io.BufferedReader;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.util.List;
import java.util.Map;
import java.util.Map.Entry;

import org.apache.http.HttpResponse;
import org.apache.http.client.HttpClient;
import org.apache.http.client.methods.HttpGet;
import org.apache.http.impl.client.DefaultHttpClient;

import com.example.jky_34_jingdong.entity.CategoryInfo;
import com.example.jky_34_jingdong.entity.ProductInfo;
import com.google.gson.Gson;
import com.google.gson.reflect.TypeToken;

public class CategoryToService {
	// http get提交   单个商品
	public static List<ProductInfo> getItemGetCategory(String path,
		Map<String, String> map) throws Exception {
		List<ProductInfo> list = null;
		// 拼网址
		StringBuffer sb = new StringBuffer();
		sb.append(path).append("?");
		for (Entry<String, String> temp:map.entrySet()) {
			sb.append(temp.getKey());
			sb.append("=");
			sb.append(temp.getValue());
			sb.append("&");
		}
		// 删除最后一个&
		sb.deleteCharAt(sb.length() - 1);
		// 打开浏览器
		HttpClient client = new DefaultHttpClient();
		// 输入网址，请求方式
		HttpGet request = new HttpGet(sb.toString());
		// 敲回车
		HttpResponse response = client.execute(request);
		// 得到响应吗
		int statusCode = response.getStatusLine().getStatusCode();
		if (statusCode == 200) {
			// 连接成功得到流
			// 连接成功
			InputStream is = response.getEntity().getContent();
			// 解析
			String msg = parseInputStreamToString(is);
			// 将Json字符串解析成list<bean>
			list = parseStringItemToJson(msg);
		}
		return list;
	}
	private static List<ProductInfo> parseStringItemToJson(String msg) {
		Gson gson = new Gson();
		TypeToken<List<ProductInfo>> token = new TypeToken<List<ProductInfo>>() {
		};
		return gson.fromJson(msg, token.getType());
	}
	// http get提交ListView 里面的商品
		public static List<CategoryInfo> getListGetCategory(String path,
				Map<String, String> map) throws Exception {
			List<CategoryInfo> list = null;
			// 拼网址
			StringBuffer sb = new StringBuffer();
			sb.append(path).append("?");
			for (Entry<String, String> temp : map.entrySet()) {
				sb.append(temp.getKey());
				sb.append("=");
				sb.append(temp.getValue());
				sb.append("&");
			}
			// 删除最后一个&
			sb.deleteCharAt(sb.length()-1);
			// 打开浏览器
			HttpClient client = new DefaultHttpClient();
			// 输入网址，请求方式
			HttpGet request = new HttpGet(sb.toString());
			// 敲回车
			HttpResponse response = client.execute(request);
			// 得到响应吗
			int statusCode = response.getStatusLine().getStatusCode();
			if (statusCode == 200) {
				// 连接成功得到流
				// 连接成功
				InputStream is = response.getEntity().getContent();
				// 解析
				String msg = parseInputStreamToString(is);
				// 将Json字符串解析成list<bean>
				list = parseStringToJson(msg);
			}
			return list;
		}
		private static List<CategoryInfo> parseStringToJson(String msg) {
			Gson gson = new Gson();
			TypeToken<List<CategoryInfo>> token = new TypeToken<List<CategoryInfo>>() {
			};
			return gson.fromJson(msg, token.getType());
		}
		private static String parseInputStreamToString(InputStream is) {
			String len = null;
			InputStreamReader isr = new InputStreamReader(is);
			BufferedReader br = new BufferedReader(isr);
			String msg = "";
			StringBuilder sb = new StringBuilder();
			try {
				while ((len = br.readLine()) != null) {
					sb.append(len);
				}
				msg = sb.toString().trim();
				br.close();
				isr.close();
			} catch (Exception e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			return msg;
		}
}
