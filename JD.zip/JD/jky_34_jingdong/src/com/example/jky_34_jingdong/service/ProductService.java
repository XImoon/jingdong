package com.example.jky_34_jingdong.service;

import java.io.BufferedReader;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.util.List;

import org.apache.http.HttpResponse;
import org.apache.http.client.HttpClient;
import org.apache.http.client.methods.HttpGet;
import org.apache.http.client.methods.HttpPost;
import org.apache.http.impl.client.DefaultHttpClient;
import org.apache.http.params.CoreConnectionPNames;

import android.graphics.Bitmap;
import android.graphics.BitmapFactory;

import com.example.jky_34_jingdong.entity.ProductInfo;
import com.google.gson.Gson;
import com.google.gson.reflect.TypeToken;

public class ProductService {
	//从服务器拿数据
	public List<ProductInfo> getProductsFromGson(String path)throws Exception{
		List<ProductInfo> lists=null;
		HttpClient client=new DefaultHttpClient();
		HttpPost request=new HttpPost(path);
		request.getParams().setIntParameter(CoreConnectionPNames.CONNECTION_TIMEOUT,5000);
		HttpResponse response = client.execute(request);
		if(response.getStatusLine().getStatusCode()==HttpURLConnection.HTTP_OK){
			InputStream is=response.getEntity().getContent();
			String gson=parseIsToGson(is);
			lists=parseStrToGson(gson);
		}
		return lists;
	}

	private List<ProductInfo> parseStrToGson(String msg) {
		Gson gson=new Gson();
		TypeToken<List<ProductInfo>> token=new TypeToken<List<ProductInfo>>(){
			
		};
		return gson.fromJson(msg, token.getType());
	}
	//将字符流转化成gson
	private String parseIsToGson(InputStream is) throws Exception{
		String line=null;
		InputStreamReader isr=new InputStreamReader(is);
		BufferedReader br=new BufferedReader(isr);
		StringBuilder sb=new StringBuilder();
		while((line=br.readLine())!=null){
			sb.append(line);
		}
		String gson=sb.toString();
		br.close();
		isr.close();
		return gson;
	}
	//根据路径得到图片
	public static Bitmap getBitmapFromPath(String path)throws Exception{
		Bitmap bitmap=null;
		HttpClient client=new DefaultHttpClient();
		HttpGet request=new HttpGet(path);
		request.getParams().setIntParameter(CoreConnectionPNames.CONNECTION_TIMEOUT,5000);
		HttpResponse response = client.execute(request);
		if(response.getStatusLine().getStatusCode()==HttpURLConnection.HTTP_OK){
			InputStream is=response.getEntity().getContent();
			bitmap=BitmapFactory.decodeStream(is);
			is.close();
		}
		return bitmap;
	}
}
