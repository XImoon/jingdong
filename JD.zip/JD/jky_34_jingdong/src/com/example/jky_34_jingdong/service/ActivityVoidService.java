package com.example.jky_34_jingdong.service;

import java.io.BufferedReader;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.util.Map;
import java.util.Map.Entry;

import org.apache.http.HttpResponse;
import org.apache.http.client.HttpClient;
import org.apache.http.client.methods.HttpGet;
import org.apache.http.impl.client.DefaultHttpClient;
import org.apache.http.params.CoreConnectionPNames;

import com.google.gson.Gson;
import com.google.gson.reflect.TypeToken;

public class ActivityVoidService {
	public String sendStringToService(String path,Map<String, String> map)throws Exception{
		String str=null;
		//拼路径
		StringBuilder sb=new StringBuilder();
		sb.append(path).append("?");
		for (Entry<String, String> temp : map.entrySet()) {
			sb.append(temp.getKey());
			sb.append("=");
			sb.append(temp.getValue());
			sb.append("&");
		}
		sb.deleteCharAt(sb.length()-1);
		HttpClient client=new DefaultHttpClient();
		HttpGet request=new HttpGet(sb.toString());
		HttpResponse response = client.execute(request);
		request.getParams().setIntParameter(CoreConnectionPNames.CONNECTION_TIMEOUT, 5000);
		int statusCode = response.getStatusLine().getStatusCode();
		if(statusCode==200){
			//得到输入流
			InputStream is = response.getEntity().getContent();
			//将流解析成json字符串
			String json=parserISToJson(is);
			//将字符串转化成List<Bean>对象
			str=parserJsonToList(json);
		}
		return str;
	}
	private String parserJsonToList(String json) {
		Gson gson=new Gson();
		TypeToken<String> token=new TypeToken<String>(){
			
		};
		return gson.fromJson(json, token.getType());
	}

	private String parserISToJson(InputStream is) {
		String line=null;
		InputStreamReader isr=new InputStreamReader(is);
		BufferedReader br=new BufferedReader(isr);
		StringBuilder sb=new StringBuilder();
		String msg="";
		try {
			while((line=br.readLine())!=null){
				sb.append(line);
			}
			msg=sb.toString().trim();
			
			br.close();
			isr.close();
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return msg;
	}
}
