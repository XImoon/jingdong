package com.example.jky_34_jingdong.service;

import java.util.Random;

public class AwardService {
	//提供数据
	public static int[] getaward(){
		//定义为长度为6的数组
		int[] a=new int[18];
		Random rd=new Random();	
		for (int i = 0; i < 18; i++) {
			int shu=rd.nextInt(100)+(-50); //表示随机产生-100-199之间的一个整数
			a[i]=shu;
		}
		return a;	
	}
}
