package com.example.jky_34_jingdong.service;

import java.io.InputStream;

import org.apache.http.HttpResponse;
import org.apache.http.client.HttpClient;
import org.apache.http.client.methods.HttpGet;
import org.apache.http.impl.client.DefaultHttpClient;
import org.apache.http.params.CoreConnectionPNames;
import org.xmlpull.v1.XmlPullParser;

import android.util.Xml;

import com.example.jky_34_jingdong.entity.VersionInfo;

public class VersionService {
	public VersionInfo getVersionInfo(String path,String encoding)throws Exception{
		VersionInfo info=null;
		HttpClient client=new DefaultHttpClient();
		HttpGet request=new HttpGet(path);
		request.getParams().setIntParameter(CoreConnectionPNames.CONNECTION_TIMEOUT,5000);
		HttpResponse response=client.execute(request);
		if(response.getStatusLine().getStatusCode()==200){
			InputStream is=response.getEntity().getContent();
			info=parseIsToVersionInfo(is,encoding);
		}
		return info;
	}
	private VersionInfo parseIsToVersionInfo(InputStream is,String encoding)throws Exception {
		VersionInfo info=new VersionInfo();
		XmlPullParser parser=Xml.newPullParser();
		parser.setInput(is, encoding);
		int eventType=parser.getEventType();
		while(XmlPullParser.END_DOCUMENT!=eventType){
			switch (eventType) {
			case XmlPullParser.START_TAG:
				if("versionid".equals(parser.getName())){
					info.versionid=parser.nextText();
				}else if("versionmsg".equals(parser.getName())){
					info.versionmsg=parser.nextText();
				}else if("versionurl".equals(parser.getName())){
					info.versionurl=parser.nextText();
				}
				break;
			default:
				break;
			}
			eventType=parser.next();
		}
		return info;
	}
}
