package com.example.jky_34_jingdong.service;

import java.util.ArrayList;
import java.util.List;

import android.R.bool;
import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;

import com.example.jky_34_jingdong.db.DBHelper;
import com.example.jky_34_jingdong.entity.CartInfo;

public class CartService {
	private DBHelper dbHelper;
	private Context context;
	private final String TABLE_NAME="cart";
	private final String NULLCOLUMNHACK="_id";
	private final String CART_PRO_ID="pro_id";
	private final String CART_PRO_DESCRIPTION="pro_description";
	private final String CART_PRO_PRICE="pro_price";
	private final String CART_PRO_COUNT="pro_count";
	private final String CART_PRO_IMAGES="pro_images";
	public CartService(Context context){
		this.context=context;
		dbHelper=DBHelper.getDBHelperInstance(context);
		//dbHelper.getReadableDatabase();
	}
	//将商品加入购物车
	public boolean addProduct(CartInfo info){
		SQLiteDatabase sdb=dbHelper.getWritableDatabase();
		if(sdb.isOpen()){
			ContentValues values=new ContentValues();
			values.put(CART_PRO_ID,info.pro_id);
			values.put(CART_PRO_DESCRIPTION,info.pro_description);
			values.put(CART_PRO_PRICE,info.pro_price);
			values.put(CART_PRO_COUNT,info.pro_count);
			values.put(CART_PRO_IMAGES,info.pro_images);
			long id=sdb.insert(TABLE_NAME, NULLCOLUMNHACK, values);
			return id>0?true:false;
		}
		return false;
	}
	//修改购物车商品的数量
	public boolean updateCart(CartInfo info){
		SQLiteDatabase sdb=dbHelper.getWritableDatabase();
		if(sdb.isOpen()){
			ContentValues values=new ContentValues();
			values.put(CART_PRO_COUNT,info.pro_count);
			int id=sdb.update(TABLE_NAME,
					values,
					"_id=?",
					new String[]{info._id+""});
			return id>0?true:false;
		}
		return false;
	}
	//清空购物车
	public boolean deleteCart(){
		SQLiteDatabase sdb=dbHelper.getWritableDatabase();
		if(sdb.isOpen()){
			int id=sdb.delete(TABLE_NAME,null,null);
			return id>0?true:false;
		}
		return false;
	}
	//根据ID 来删除
	public boolean deleteById(int id){
		SQLiteDatabase sdb=dbHelper.getWritableDatabase();
		if(sdb.isOpen()){
			int i=sdb.delete(TABLE_NAME,"_id=?",new String[]{id+""});
			return i>0?true:false;
		}
		return false;
	}
	//展示购物车中的商品
	public List<CartInfo> showCart(){
		List<CartInfo> lists=new ArrayList<CartInfo>();
		SQLiteDatabase sdb=dbHelper.getReadableDatabase();
		if(sdb.isOpen()){
			Cursor cs=sdb.query(TABLE_NAME,
					null,
					null,
					null,
					null,
					null,
					null);
			if(cs!=null){
				while(cs.moveToNext()){
					CartInfo info=new CartInfo();
					info._id=cs.getInt(cs.getColumnIndex(NULLCOLUMNHACK));
					info.pro_id=cs.getInt(cs.getColumnIndex(CART_PRO_ID));
					info.pro_description=cs.getString(cs.getColumnIndex(CART_PRO_DESCRIPTION));
					info.pro_price=cs.getDouble(cs.getColumnIndex(CART_PRO_PRICE));
					info.pro_count=cs.getInt(cs.getColumnIndex(CART_PRO_COUNT));
					info.pro_images=cs.getString(cs.getColumnIndex(CART_PRO_IMAGES));
					lists.add(info);
				}
				cs.close();
			}
		}
		return lists;
	}
	//根据商品的ＩＤ来查询
	public CartInfo findById(int id){
		CartInfo info=null;
		SQLiteDatabase sdb=dbHelper.getReadableDatabase();
		if(sdb.isOpen()){
			Cursor cs=sdb.query(
					TABLE_NAME,
					null,
					"pro_id=?",
					new String[]{id+""},
					null,
					null,
					null);
			if(cs!=null){
				while(cs.moveToNext()){
					info=new CartInfo();
					info._id=cs.getInt(cs.getColumnIndex(NULLCOLUMNHACK));
					info.pro_id=cs.getInt(cs.getColumnIndex(CART_PRO_ID));
					info.pro_description=cs.getString(cs.getColumnIndex(CART_PRO_DESCRIPTION));
					info.pro_price=cs.getDouble(cs.getColumnIndex(CART_PRO_PRICE));
					info.pro_count=cs.getInt(cs.getColumnIndex(CART_PRO_COUNT));
					info.pro_images=cs.getString(cs.getColumnIndex(CART_PRO_IMAGES));
				}
				cs.close();
			}
		}
		return info;
	}
}
