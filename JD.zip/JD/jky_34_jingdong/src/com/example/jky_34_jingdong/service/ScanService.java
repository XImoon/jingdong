package com.example.jky_34_jingdong.service;

import java.util.ArrayList;
import java.util.List;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;

import com.example.jky_34_jingdong.db.DBHelper;
import com.example.jky_34_jingdong.entity.ScanInfo;

public class ScanService {
	private DBHelper dbHelper;
	private Context context;
	private final String TABLE_NAME="scan";
	private final String NULLCOLUMNHACK="_id";
	private final String SCAN_PRO_ID="pro_id";
	private final String SCAN_PRO_DESCRIPTION="pro_description";
	private final String SCAN_PRO_PRICE="pro_price";
	private final String SCAN_STATUS="status";
	private final String CART_PRO_IMAGES="pro_images";
	public ScanService(Context context){
		this.context=context;
		dbHelper=DBHelper.getDBHelperInstance(context);
		//dbHelper.getReadableDatabase();
	}
	//添加
	public boolean addScan(ScanInfo info){
		SQLiteDatabase sdb=dbHelper.getWritableDatabase();
		if(sdb.isOpen()){
			ContentValues values=new ContentValues();
			values.put(SCAN_PRO_ID,info.pro_id);
			values.put(SCAN_PRO_DESCRIPTION,info.pro_description);
			values.put(SCAN_PRO_PRICE,info.pro_price);
			values.put(SCAN_STATUS,info.status);
			values.put(CART_PRO_IMAGES,info.pro_images);
			long id=sdb.insert(
					TABLE_NAME, 
					NULLCOLUMNHACK,
					values);
			return id>0?true:false;
		}
		return false;
	}
	//删除
	public boolean deleteScan(int id){
		SQLiteDatabase sdb=dbHelper.getWritableDatabase();
		if(sdb.isOpen()){
			int i=sdb.delete(
					TABLE_NAME,
					"pro_id=?",
					new String[]{id+""});
			return i>0?true:false;
		}
		return false;
	}
	//查询
	public boolean query(int id,String status){
		SQLiteDatabase sdb=dbHelper.getReadableDatabase();
		if(sdb.isOpen()){
			Cursor cs=sdb.query(
					TABLE_NAME,
					null,
					"pro_id=? and status=?",
					new String[]{id+"",status},
					null,
					null,
					null);
			if(cs!=null){
				while(cs.moveToNext()){
					return true;
				}
			}
		}
		return false;
	}
	//根据状态查询
	public List<ScanInfo> queryAll(String status){
		List<ScanInfo> lists=new ArrayList<ScanInfo>();
		SQLiteDatabase sdb=dbHelper.getReadableDatabase();
		if(sdb.isOpen()){
			Cursor cs=sdb.query(
					TABLE_NAME,
					null,
					"status=?",
					new String[]{status},
					null,
					null,
					"_id desc");
			if(cs!=null){
				while(cs.moveToNext()){
					ScanInfo info=new ScanInfo();
					info._id=cs.getInt(cs.getColumnIndex(NULLCOLUMNHACK));
					info.pro_id=cs.getInt(cs.getColumnIndex(SCAN_PRO_ID));
					info.pro_description=cs.getString(cs.getColumnIndex(SCAN_PRO_DESCRIPTION));
					info.pro_images=cs.getString(cs.getColumnIndex(CART_PRO_IMAGES));
					info.pro_price=cs.getShort(cs.getColumnIndex(SCAN_PRO_PRICE));
					info.status=cs.getString(cs.getColumnIndex(SCAN_STATUS));
					lists.add(info);
					if(lists.size()>=10){
						return lists;
					}
				}
			}
		}
		return lists;
	}
}
