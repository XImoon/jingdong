package com.example.jky_34_jingdong.service;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;

import com.example.jky_34_jingdong.db.DBHelper;
import com.example.jky_34_jingdong.entity.SearchInfo;
public class SerchDao {
	private DBHelper dbHelper;
	private String TABLE_NAME="searchinfo";
	//连接数据库
	public SerchDao(Context context) {
		dbHelper=DBHelper.getDBHelperInstance(context);
	}
	//添加的方法
	public void addContext(SearchInfo info){
		//增删改用write
		SQLiteDatabase sdb = dbHelper.getWritableDatabase();
		if(sdb.isOpen()){
			String sql="insert into searchinfo(search_xontent,count) values(?,?) ";
			sdb.execSQL(sql,new Object[]{info.context,info.count});
		}
	}
	//根据id修改次数
	public void update(int _id,int count){
		SQLiteDatabase sdb = dbHelper.getWritableDatabase();
		
		if(sdb.isOpen()){
			String sql="update searchinfo set count=? where _id=?";
			sdb.execSQL(sql, new String[]{count+1+"",_id+""});
		}
	}
	//根据查找次数倒序
	public Cursor findByCount(){
		SQLiteDatabase sdb = dbHelper.getReadableDatabase();
		Cursor cs=null;
		if(sdb.isOpen()){
			String sql="select * from searchinfo order by count desc";
			
			cs=sdb.rawQuery(sql, null);
		}
		return cs;
	}
	//查询是不是有这个商品
	public SearchInfo queryByContent(String content){
		SQLiteDatabase sdb = dbHelper.getReadableDatabase();
		SearchInfo info=null;
		Cursor cs=null;
		if(sdb.isOpen()){
			String sql="select * from searchinfo where search_xontent=?";
			cs=sdb.rawQuery(sql, new String[]{content});
			while(cs.moveToNext()){
					int _id=cs.getInt(0);
					String search_xontent=cs.getString(1);
					int count=cs.getInt(2);
					 info=new SearchInfo(_id, search_xontent, count);
			}
		}
		return info;
	}
}
