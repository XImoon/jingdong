package com.example.jky_34_jingdong.service;

import android.R.bool;
import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;

import com.example.jky_34_jingdong.db.DBHelper;
import com.example.jky_34_jingdong.entity.UserInfo;

public class LoginService {
	private DBHelper dbHelper;
	private Context context;
	private final String TABLE_NAME="users";
	private final String USER_ID="_id";
	private final String USER_NAME="username";
	private final String USER_PASS="userpass";
	private final String USER_PIC="user_pic";
	private final String USER_BALANCE="balance";
	public LoginService(Context context){
		this.context=context;
		dbHelper=DBHelper.getDBHelperInstance(context);
	}
	//将用户信息存入表格
	public boolean addUser(UserInfo info){
		SQLiteDatabase sdb=dbHelper.getWritableDatabase();
		if(sdb.isOpen()){
			ContentValues values=new ContentValues();
			values.put(USER_ID,info._id);
			values.put(USER_NAME,info.username);
			values.put(USER_PASS,info.userpass);
			values.put(USER_PIC,info.user_pic);
			values.put(USER_BALANCE,info.balance);
			long id=sdb.insert(TABLE_NAME, null, values);
			return id>0?true:false;
		}
		return false;
	}
	//修改用户信息
	public boolean update(UserInfo info){
		SQLiteDatabase sdb=dbHelper.getWritableDatabase();
		if(sdb.isOpen()){
			ContentValues values=new ContentValues();
			values.put(USER_ID,info._id);
			values.put(USER_NAME,info.username);
			values.put(USER_PASS,info.userpass);
			values.put(USER_PIC,info.user_pic);
			values.put(USER_BALANCE,info.balance);
			int id=sdb.update(TABLE_NAME,values,null,null);
			return id>0?true:false;
		}
		return false;
	}
	//删除用户
	public boolean delete(){
		SQLiteDatabase sdb=dbHelper.getWritableDatabase();
		if(sdb.isOpen()){
			int id=sdb.delete(TABLE_NAME, null, null);
			return id>0?true:false;
		}
		return false;
	}
	//查询用户信息
	public UserInfo query(){
		UserInfo info=null;
		SQLiteDatabase sdb=dbHelper.getReadableDatabase();
		if(sdb.isOpen()){
			Cursor cs=sdb.query(TABLE_NAME, null, null, null, null, null, null);
			if(cs!=null){
				while(cs.moveToNext()){
					info=new UserInfo();
					info._id=cs.getInt(cs.getColumnIndex(USER_ID));
					info.username=cs.getString(cs.getColumnIndex(USER_NAME));
					info.userpass=cs.getString(cs.getColumnIndex(USER_PASS));
					info.user_pic=cs.getString(cs.getColumnIndex(USER_PIC));
					info.balance=cs.getString(cs.getColumnIndex(USER_BALANCE));
				}
			}
		}
		return info;
	}
}
