package com.example.jky_34_jingdong.service;
import java.io.BufferedReader;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.util.List;
import java.util.Map;
import java.util.Map.Entry;

import org.apache.http.HttpResponse;
import org.apache.http.client.HttpClient;
import org.apache.http.client.methods.HttpGet;
import org.apache.http.client.methods.HttpPost;
import org.apache.http.impl.client.DefaultHttpClient;
import org.apache.http.params.CoreConnectionPNames;

import com.example.jky_34_jingdong.entity.CategoryInfo;
import com.google.gson.Gson;
import com.google.gson.reflect.TypeToken;
public class CategoryJsonService {
	//解析json
	public List<String> getProductToJson(String path) throws Exception{
		List<String> lists=null;
		//连网
		HttpClient client=new DefaultHttpClient();
		//输入网址
		HttpPost request=new HttpPost(path);
		//设置超时
		request.getParams().setIntParameter(CoreConnectionPNames.CONNECTION_TIMEOUT, 5000);
		//回车
		HttpResponse response = client.execute(request);
		//得到响应码
		int statusCode = response.getStatusLine().getStatusCode();
		if(statusCode==200){
			//得到输入流
			InputStream is = response.getEntity().getContent();
			//将流解析成json字符串形式
			String json=parserIsToJson(is);
			//将json字符串解析成List《bean》
			lists=parserJsonToString(json);
		}
		return lists;
	}
	private List<String> parserJsonToString(String json) {
		Gson gson=new Gson();
		TypeToken<List<String>> token=new TypeToken<List<String>>(){};
		
		return gson.fromJson(json, token.getType());
	}

	private String parserIsToJson(InputStream is) {
		String line=null;
		String gson="";
		InputStreamReader isr=new InputStreamReader(is);
		BufferedReader br=new BufferedReader(isr);
		StringBuilder sb=new StringBuilder();
		try {
			while((line=br.readLine())!=null){
				sb.append(line);
			}
			gson=sb.toString();
			br.close();
			isr.close();
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return gson;
	}
}
