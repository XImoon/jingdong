package com.example.jky_34_jingdong.service;

import java.io.BufferedReader;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.util.Map;
import java.util.Map.Entry;
import org.apache.http.HttpResponse;
import org.apache.http.client.HttpClient;
import org.apache.http.client.methods.HttpGet;
import org.apache.http.impl.client.DefaultHttpClient;
import org.apache.http.params.CoreConnectionPNames;

import com.example.jky_34_jingdong.entity.UserInfo;
import com.google.gson.Gson;
import com.google.gson.reflect.TypeToken;

public class PurseService {
	public UserInfo getUserInfosByUserName(String path,Map<String, String> map) throws Exception{
		UserInfo list=null;
		//拼路径
		StringBuilder sb=new StringBuilder();
		sb.append(path).append("?");
		for (Entry<String, String> temp : map.entrySet()) {
			sb.append(temp.getKey());
			sb.append("=");
			sb.append(temp.getValue());
			sb.append("&");
		}
		sb.deleteCharAt(sb.length()-1);
		//连网
		HttpClient client=new DefaultHttpClient();
		HttpGet request=new HttpGet(sb.toString());
		request.getParams().setIntParameter(CoreConnectionPNames.CONNECTION_TIMEOUT, 5000);
		HttpResponse response = client.execute(request);
		if(response.getStatusLine().getStatusCode()==200){
			InputStream is = response.getEntity().getContent();
			//将流解析成Json
			String msg=ParserISToJson(is);
			//将json解析成List
			list=parserJsonToList(msg);
		}
		return list;
	}

	private UserInfo parserJsonToList(String msg) {
		Gson gson=new Gson();
		TypeToken<UserInfo> token=new TypeToken<UserInfo>(){};
		return gson.fromJson(msg, token.getType());
	}

	private String ParserISToJson(InputStream is) {
		String len=null;
		InputStreamReader isr=new InputStreamReader(is);
		BufferedReader br=new BufferedReader(isr);
		StringBuilder sb=new StringBuilder();
		String msg="";
		try {
			while((len=br.readLine())!=null){
				sb.append(len);
			}
			msg=sb.toString();
			br.close();
			isr.close();
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return msg;
	}
}
