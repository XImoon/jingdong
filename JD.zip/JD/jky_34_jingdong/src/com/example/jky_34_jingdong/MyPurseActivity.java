package com.example.jky_34_jingdong;
import java.util.HashMap;
import java.util.Map;
import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.os.Handler;
import android.os.Message;
import android.widget.TextView;
import com.example.jky_34_jingdong.entity.UserInfo;
import com.example.jky_34_jingdong.service.PurseService;
import com.example.jky_34_jingdong.util.ConstantUtil;
public class MyPurseActivity extends Activity {
	private Map<String, String> map=new HashMap<String, String>();
	private TextView tv_myPurseName,tv_myPurseDalance;
	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.activity_my_purse);
		init();
		Intent intent=getIntent();
		String username=intent.getStringExtra("username");
		map.put("username", username);
		final PurseService service=new PurseService();
		new Thread(){
			public void run() {
				try {
					UserInfo info = service.getUserInfosByUserName(ConstantUtil.MY_PURSE_PATH,map);
					if(info!=null){
						Message message = mHandler.obtainMessage();
						message.what=ConstantUtil.NET_SUCCESS;
						message.obj=info;
						mHandler.sendMessage(message);
					}else {
						mHandler.sendEmptyMessage(ConstantUtil.NET_NOT_DATA);
					}
				} catch (Exception e) {
					mHandler.sendEmptyMessage(ConstantUtil.NET_FAIL);
					e.printStackTrace();
				}
			};
		}.start();
	}
	private Handler mHandler=new Handler(){
		public void handleMessage(android.os.Message msg) {
			switch (msg.what) {
			case ConstantUtil.NET_SUCCESS:
				UserInfo info=(UserInfo) msg.obj;
				//ConstantUtil.MyToast(info.username,MyPurseActivity.this);
				tv_myPurseName.setText(info.username);
				tv_myPurseDalance.setText(info.balance);	
				break;

			default:
				break;
			}
			
		};
	};
	private void init() {
		tv_myPurseName=(TextView) findViewById(R.id.tv_myPurseName);
		tv_myPurseDalance=(TextView) findViewById(R.id.tv_myPurseDalance);
	}
}
