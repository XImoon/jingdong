package com.example.jky_34_jingdong;
import android.os.Bundle;
import android.app.Activity;
import android.content.Intent;
import android.view.Menu;
import android.view.View;
public class FindActivity extends Activity {
	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.activity_find);
	}
	public void activity(View view){
		Intent intent=new Intent(this,ActivityInfosActivity.class);
		startActivity(intent);
	}
	public void story(View view){
		Intent intent=new Intent(this,StoryActivity.class);
		startActivity(intent);
	}
}
