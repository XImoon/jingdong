package com.example.jky_34_jingdong;
import java.util.HashMap;
import java.util.Map;

import com.example.jky_34_jingdong.adapter.Myadapter;
import com.example.jky_34_jingdong.entity.UserInfo;
import com.example.jky_34_jingdong.service.AwardService;
import com.example.jky_34_jingdong.service.PurseService;
import com.example.jky_34_jingdong.util.ConstantUtil;

import android.app.Activity;
import android.app.AlertDialog;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.DialogInterface.OnClickListener;
import android.graphics.Color;
import android.os.Bundle;
import android.os.Handler;
import android.os.Message;
import android.view.View;
import android.widget.AdapterView;
import android.widget.AdapterView.OnItemClickListener;
import android.widget.GridView;
import android.widget.TextView;
public class AwardActivity extends Activity {
	private GridView gv_award;
	private TextView tv_award;
	private Myadapter Adapter;
	private int[] ids;
	private Map<String, String> map=new HashMap<String, String>();
	//定义金币数的累加
	int sum=0;
	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.activity_award);
		init();
		Intent intent=getIntent();
		String username=intent.getStringExtra("username");
		map.put("username", username);
		//创建适配器
		ids= AwardService.getaward();
		Adapter=new Myadapter(this,ids);
		//绑定适配器到控件上面
		gv_award.setAdapter(Adapter);
		gv_award.setOnItemClickListener(new OnItemClickListener() {
			@Override
			public void onItemClick(AdapterView<?> parent, View view,
					int position, long id) {
				int in=ids[position];
				tv_award=(TextView) view.findViewById(R.id.tv_award);
				tv_award.setBackgroundColor(Color.WHITE);
				//点击事件弹出对话框
				AlertDialog.Builder builder=new AlertDialog.Builder(AwardActivity.this);
				//自定义对话框
				View v= getLayoutInflater().inflate(R.layout.gold_item, null);
				//初始化控件
				TextView gold=(TextView) v.findViewById(R.id.tv_gold);
				builder.setView(v);
				builder.setTitle("恭喜您获得:");
				gold.setText(in+"");
				sum=(sum+in);
				//确定
				builder.setPositiveButton("确定", new OnClickListener() {
					@Override
					public void onClick(DialogInterface dialog, int which) {
						
					}
				});
				//取消
				builder.setNegativeButton("取消", new OnClickListener() {
					@Override
					public void onClick(DialogInterface dialog, int which) {
						
					}
				});
				builder.show();
			}
		});
	}
	
	private void init() {
		gv_award=(GridView) findViewById(R.id.gv_award);
	}
	public void stop(View view){
		map.put("count", sum+"");
		final PurseService service=new PurseService();
		new Thread(){
			public void run() {
				try {
					UserInfo info = service.getUserInfosByUserName(ConstantUtil.GAME_COUNT_PATH, map);
					if(info!=null){
						Message message = mHandler.obtainMessage();
						message.what=ConstantUtil.NET_SUCCESS;
						message.obj=info;
						mHandler.sendMessage(message);
					}else {
						mHandler.sendEmptyMessage(ConstantUtil.NET_NOT_DATA);
					}
				} catch (Exception e) {
					mHandler.sendEmptyMessage(ConstantUtil.NET_FAIL);
					e.printStackTrace();
				}
			}
		}.start();
	}
	private Handler mHandler=new Handler(){
		public void handleMessage(android.os.Message msg) {
			switch (msg.what) {
			case ConstantUtil.NET_SUCCESS:
				UserInfo info=(UserInfo) msg.obj;
				//Toast.makeText(CountActivity.this, info.balance, Toast.LENGTH_LONG).show();
				ConstantUtil.MyToast("卡上余额:"+info.balance,AwardActivity.this);
				Intent intent=new Intent(AwardActivity.this,MainActivity.class);
				startActivity(intent);
				break;
			default:
				break;
			}
			
		};
	};
}
