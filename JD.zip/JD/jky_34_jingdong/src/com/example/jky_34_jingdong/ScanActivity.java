package com.example.jky_34_jingdong;

import java.util.List;

import com.example.jky_34_jingdong.adapter.ScanAdapter;
import com.example.jky_34_jingdong.entity.ProductInfo;
import com.example.jky_34_jingdong.entity.ScanInfo;
import com.example.jky_34_jingdong.service.ScanService;
import com.example.jky_34_jingdong.util.ConstantUtil;

import android.os.Bundle;
import android.os.Handler;
import android.os.Message;
import android.app.Activity;
import android.content.Intent;
import android.view.Menu;
import android.view.View;
import android.widget.AdapterView;
import android.widget.AdapterView.OnItemClickListener;
import android.widget.GridView;

public class ScanActivity extends Activity {
	private GridView gv_scan;
	private ScanAdapter scanAdapter;
	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.activity_scan);
		init();
		scanAdapter=new ScanAdapter(this);
		ScanService service=new ScanService(this);
		List<ScanInfo> lists=service.queryAll("最近浏览");
		scanAdapter.setLists(lists);
		gv_scan.setAdapter(scanAdapter);
		gv_scan.setOnItemClickListener(new MyListener());
	}
	private class MyListener implements OnItemClickListener{
		@Override
		public void onItemClick(AdapterView<?> parent, View view, int position,
				long id) {
			ScanInfo info=(ScanInfo) scanAdapter.getItem(position);
			ProductInfo pinfo=new ProductInfo();
			pinfo.pro_id=info.pro_id;
			pinfo.pro_description=info.pro_description;
			pinfo.pro_price=info.pro_price+"";
			pinfo.pro_images=info.pro_images;
			Intent intent=new Intent(ScanActivity.this,ProductDetailActivity.class);
			intent.putExtra("product",pinfo);
			startActivity(intent);
		}
		
	};
	private void init() {
		gv_scan=(GridView) findViewById(R.id.gv_scan);
	}
	public void back(View view){
		Intent intent=new Intent(this,MainActivity.class);
		startActivity(intent);
	}
}
