package com.example.jky_34_jingdong;
import java.util.ArrayList;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.support.v4.view.ViewPager;
import android.support.v4.view.ViewPager.OnPageChangeListener;
import android.view.LayoutInflater;
import android.view.View;
import android.view.View.OnClickListener;
import android.view.Window;
import android.widget.Button;
import android.widget.ImageView;

import com.example.jky_34_jingdong.db.DBHelper;
public class WelcomeActivity extends Activity {
	// 翻页控件
	private ViewPager mViewPager;
	// 这5个是底部显示当前状态点imageView
	private ImageView mPage0;
	private ImageView mPage1;
	private ImageView mPage2;
	private ImageView mPage3;
	@Override
	protected void onCreate(Bundle savedInstanceState) {
		requestWindowFeature(Window.FEATURE_NO_TITLE);
		super.onCreate(savedInstanceState);
		setContentView(R.layout.activity_welcome);
		DBHelper dbHelper=DBHelper.getDBHelperInstance(this);
		dbHelper.getReadableDatabase();
		mViewPager=(ViewPager) findViewById(R.id.whatsnew_viewpager);
		mViewPager.setOnPageChangeListener(new MyOnPageChangeListener());
		mPage0=(ImageView) findViewById(R.id.page0);
		mPage1=(ImageView) findViewById(R.id.page1);
		mPage2=(ImageView) findViewById(R.id.page2);
		mPage3=(ImageView) findViewById(R.id.page3);
		/*
		 * 这里是每一页要显示的布局，根据应用需要和特点自由设计显示的内容 以及需要显示多少页等
		 */
		LayoutInflater mInflater=LayoutInflater.from(this);
		View view1=mInflater.inflate(R.layout.whats_news_gallery_one,null);
		View view2=mInflater.inflate(R.layout.whats_news_gallery_two,null);
		View view3=mInflater.inflate(R.layout.whats_news_gallery_three,null);
		View view4=mInflater.inflate(R.layout.whats_news_gallery_four,null);
		Button v=(Button) view4.findViewById(R.id.b_submit);
		v.setOnClickListener(new OnClickListener() {
			@Override
			public void onClick(View v) {
				Intent intent = new Intent(WelcomeActivity.this,
						MainActivity.class);
				startActivity(intent);
				finish();
			}
		});
		/*
		 * 这里将每一页显示的view存放到ArrayList集合中 可以在ViewPager适配器中顺序调用展示
		 */
		final ArrayList<View> views=new ArrayList<View>();
		views.add(view1);
		views.add(view2);
		views.add(view3);
		views.add(view4);
		/*
		 * 每个页面的Title数据存放到ArrayList集合中 可以在ViewPager适配器中调用展示
		 */
		final ArrayList<String> titles=new ArrayList<String>();
		titles.add("tab1");
		titles.add("tab2");
		titles.add("tab3");
		titles.add("tab4");
		// 填充ViewPager的数据适配器
		com.example.jky_34_jingdong.adapter.MyPagerAdapter mPagerAdapter = new com.example.jky_34_jingdong.adapter.MyPagerAdapter(views, titles);
		mViewPager.setAdapter(mPagerAdapter);
	}
	public class MyOnPageChangeListener implements OnPageChangeListener{
		@Override
		public void onPageScrollStateChanged(int arg0) {
			// TODO Auto-generated method stub
			
		}
		@Override
		public void onPageScrolled(int arg0, float arg1, int arg2) {
			// TODO Auto-generated method stub
			
		}
		@Override
		public void onPageSelected(int page) {
			// 翻页时当前page,改变当前状态园点图片
			switch (page) {
			case 0:
				mPage0.setImageDrawable(getResources().getDrawable(
						R.drawable.red));
				mPage1.setImageDrawable(getResources().getDrawable(
						R.drawable.white));
				break;
			case 1:
				mPage1.setImageDrawable(getResources().getDrawable(
						R.drawable.red));
				mPage0.setImageDrawable(getResources().getDrawable(
						R.drawable.white));
				mPage2.setImageDrawable(getResources().getDrawable(
						R.drawable.white));
				break;
			case 2:
				mPage2.setImageDrawable(getResources().getDrawable(
						R.drawable.red));
				mPage1.setImageDrawable(getResources().getDrawable(
						R.drawable.white));
				mPage3.setImageDrawable(getResources().getDrawable(
						R.drawable.white));
				break;
			case 3:
				mPage3.setImageDrawable(getResources().getDrawable(
						R.drawable.red));
				mPage2.setImageDrawable(getResources().getDrawable(
						R.drawable.white));

				break;
			}
		}
	}
}
