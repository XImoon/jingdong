package com.example.jky_34_jingdong;
import java.util.HashMap;
import java.util.Map;
import java.util.Random;

import android.R.integer;
import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.os.Handler;
import android.os.Message;
import android.view.View;
import android.widget.TextView;

import com.example.jky_34_jingdong.entity.UserInfo;
import com.example.jky_34_jingdong.service.PurseService;
import com.example.jky_34_jingdong.util.ConstantUtil;
public class CountActivity extends Activity {
	private Map<String, String> map=new HashMap<String, String>();
	private TextView et_count_game;
	//剩余猜数字的次数
	private int count=5;
	//电脑随机产生的数字
	private int a;
	private int small_count=0;
	private int big_count=100;
	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.activity_count);
		init();
		Intent intent=getIntent();
		String username=intent.getStringExtra("username");
		map.put("username", username);
	}
	private void init() {
		et_count_game=(TextView) findViewById(R.id.et_count_game);
	}
	public void guess(View view){
		if(count<=0){
			ConstantUtil.MyToast("本次机会已用完！请重新来过！",this);
			int sum=-100;
			getCount(sum);
			return;
		}
		String b=et_count_game.getText()+"";
		try {
			int guess_count=Integer.parseInt(b);
			if(guess_count<=small_count||guess_count>=big_count){
				ConstantUtil.MyToast("请在规定的范围内猜数字!",this);
			}
			if(guess_count<a){
				small_count=guess_count;
			}else if(guess_count>a){
				big_count=guess_count;
			}else{
				ConstantUtil.MyToast("恭喜你！正确！获得"+count*100+"元奖励！",this);
				int sum=(count-1)*100;
				getCount(sum);
				return;
			}
			count--;
			ConstantUtil.MyToast("请在"+small_count+"---"+big_count+"之间猜数!",this);
		} catch (NumberFormatException e) {
			ConstantUtil.MyToast("请输入数字！",this);
			e.printStackTrace();
		}
	}
	public void start(View view){
		Random rd=new Random();
		a=rd.nextInt(99)+1;
		count=5;
		ConstantUtil.MyToast("请开始猜数!",this);
	}
	private void getCount(int sum) {
		map.put("count", sum+"");
		final PurseService service=new PurseService();
		new Thread(){
			public void run() {
				try {
					UserInfo info = service.getUserInfosByUserName(ConstantUtil.GAME_COUNT_PATH, map);
					if(info!=null){
						Message message = mHandler.obtainMessage();
						message.what=ConstantUtil.NET_SUCCESS;
						message.obj=info;
						mHandler.sendMessage(message);
					}else {
						mHandler.sendEmptyMessage(ConstantUtil.NET_NOT_DATA);
					}
				} catch (Exception e) {
					mHandler.sendEmptyMessage(ConstantUtil.NET_FAIL);
					e.printStackTrace();
				}
			}
		}.start();
	}
	private Handler mHandler=new Handler(){
		public void handleMessage(android.os.Message msg) {
			switch (msg.what) {
			case ConstantUtil.NET_SUCCESS:
				UserInfo info=(UserInfo) msg.obj;
				//Toast.makeText(CountActivity.this, info.balance, Toast.LENGTH_LONG).show();
				ConstantUtil.MyToast("卡上余额:"+info.balance,CountActivity.this);
				break;
			default:
				break;
			}
			
		};
	};
}
