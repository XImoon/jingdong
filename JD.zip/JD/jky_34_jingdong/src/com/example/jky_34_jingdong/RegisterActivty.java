package com.example.jky_34_jingdong;
import java.util.HashMap;
import java.util.Map;

import android.app.Activity;
import android.app.AlertDialog;
import android.content.Intent;
import android.graphics.drawable.Drawable;
import android.os.Bundle;
import android.os.Handler;
import android.os.Message;
import android.text.TextUtils;
import android.view.View;
import android.widget.AdapterView;
import android.widget.AdapterView.OnItemClickListener;
import android.widget.EditText;
import android.widget.GridView;
import android.widget.ImageView;
import android.widget.SimpleAdapter;
import android.widget.Toast;

import com.example.jky_34_jingdong.service.UserService;
import com.example.jky_34_jingdong.service.headService;
import com.example.jky_34_jingdong.util.ConstantUtil;
public class RegisterActivty extends Activity {
	private EditText et_name, et_pass01, et_pass02;
	private GridView gv_head;
	private ImageView iv_image;
	// 定义全局变量适配器
	private SimpleAdapter adapter;
	private int img_id;
	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.activity_register_activty);
		init();
	}
	private void init() {
		et_name = (EditText) findViewById(R.id.et_name);
		et_pass01 = (EditText) findViewById(R.id.et_pass01);
		et_pass02 = (EditText) findViewById(R.id.et_pass02);
		gv_head = (GridView) findViewById(R.id.gv_head);
		iv_image=(ImageView) findViewById(R.id.iv_image);
	}
	// 自定义对话框点击图片事件
	public void image(View view) {
		AlertDialog.Builder builder = new AlertDialog.Builder(this);
		builder.setTitle("请选择头像");
		View vi = getLayoutInflater().inflate(R.layout.register_item, null);
		gv_head = (GridView) vi.findViewById(R.id.gv_head);
		builder.setView(vi);
		final AlertDialog dialog=builder.show();
		// 创建适配器
		adapter = new SimpleAdapter(
				this, 
				headService.getimage(),
				R.layout.head_main,
				new String[] { "head" },
				new int[] { R.id.iv_head});
		// 绑定适配器
		gv_head.setAdapter(adapter);
		gv_head.setOnItemClickListener(new OnItemClickListener() {
			@Override
			public void onItemClick(AdapterView<?> parent, View view,
					int position, long id) {
				Map<String, Object> map=(Map<String, Object>) adapter.getItem(position);
				//得到map中的数据
				img_id=(Integer) map.get("head");	
				//ConstantUtil.MyToast(img_id+"", RegisterActivty.this);
				//将int转换成drawable类型
				Drawable drawable=getResources().getDrawable(img_id);
				//将图片设置到imageview中去
				iv_image.setImageDrawable(drawable);
				dialog.dismiss();
			}
		});
	}
	// 点击注册事件
		// http://192.168.191.1:8080/jingdong/RegisterServlet
		// ?username=aaa&password=123
		// 得到编辑框中的值
	public void register(View view) {
		final String name = et_name.getText() + "";
		final String pass01 = et_pass01.getText() + "";
		final String pass02 = et_pass02.getText() + "";
		if (TextUtils.isEmpty(name)) {
			ConstantUtil.MyToast("用户名不能为空", this);
			return;
		} else if (TextUtils.isEmpty(pass01)) {
			ConstantUtil.MyToast("密码不能为空", this);
			return;
		} else if (!pass01.equals(pass02)) {
			ConstantUtil.MyToast("两次输入密码不匹配", this);
		}
		new Thread() {
			public void run() {
				try {
					String path = "http://192.168.191.1:8080/jd/RegisterServlet";
					Map<String, String> map = new HashMap<String, String>();
					map.put("username",name);
					map.put("password", pass01);
					map.put("user_pic",img_id+"");
					map.put("balance",ConstantUtil.send_money);
					String str = UserService.register(path, map);
					if (str != null) {
						Message message = mHandler.obtainMessage();
						message.what =ConstantUtil.NET_SUCCESS;
						message.obj = str;
						mHandler.sendMessage(message);
					} else {
						mHandler.sendEmptyMessage(ConstantUtil.NET_NOT_DATA);
					}
				} catch (Exception e) {
					mHandler.sendEmptyMessage(ConstantUtil.NET_FAIL);
					e.printStackTrace();
				}

			};
		}.start();
	}
	// 开启主线程
		private Handler mHandler = new Handler() {
			public void handleMessage(android.os.Message msg) {
				String str = (String) msg.obj;
				if (msg.what == ConstantUtil.NET_SUCCESS) {
					ConstantUtil.MyToast(str,RegisterActivty.this);
					Intent intent=new Intent(RegisterActivty.this,LoginActivity.class);
					startActivity(intent);
				} else if (msg.what == ConstantUtil.NET_NOT_DATA) {
					ConstantUtil.MyToast("服务器繁忙！请稍后再试！",RegisterActivty.this);
				} else if (msg.what ==ConstantUtil.NET_FAIL) {
					ConstantUtil.MyToast("网络异常",RegisterActivty.this);
				}

			};
		};
}
