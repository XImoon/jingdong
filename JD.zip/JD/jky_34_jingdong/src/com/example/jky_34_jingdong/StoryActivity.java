package com.example.jky_34_jingdong;
import java.util.List;

import com.example.jky_34_jingdong.adapter.StoryBaseAdapter;
import com.example.jky_34_jingdong.entity.StoryInfo;
import com.example.jky_34_jingdong.service.StorySevice;
import com.example.jky_34_jingdong.util.ConstantUtil;

import android.app.Activity;
import android.os.Bundle;
import android.os.Handler;
import android.os.Message;
import android.widget.ImageView;
import android.widget.ListView;
public class StoryActivity extends Activity {
	private ListView lv_story;
	private StoryBaseAdapter adapter;
	private ImageView iv_story_h;
	private int i = 0;
	private int[] image_head = new int[]{
			R.drawable.show1,
			R.drawable.show2,
			R.drawable.show3,
			R.drawable.show4,
			R.drawable.show5,
			R.drawable.show6,
			R.drawable.show7,
			R.drawable.show8};
	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.activity_story);
		init();
		new TimeThread().start();
		adapter = new StoryBaseAdapter(this);
		final StorySevice sevice = new StorySevice();
		new Thread() {
			public void run() {
				List<StoryInfo> persons;
				try {
					persons = sevice.getPersonsFromGson(ConstantUtil.STORY_PATH);
					if (persons != null) {
						// NET_SUCCESS
						Message message = sHandler.obtainMessage();

						message.what =ConstantUtil.NET_SUCCESS;
						message.obj = persons;
						sHandler.sendMessage(message);
					} else {
						sHandler.sendEmptyMessage(ConstantUtil.NET_NOT_DATA);
					}
				} catch (Exception e) {
					sHandler.sendEmptyMessage(ConstantUtil.NET_FAIL);
					e.printStackTrace();
				}

			};
		}.start();
		lv_story.setAdapter(adapter);
	}
	private Handler sHandler = new Handler() {
		@Override
		public void handleMessage(Message msg) {
			switch (msg.what) {
			case ConstantUtil.NET_SUCCESS:
				List<StoryInfo> persons=(List<StoryInfo>) msg.obj;
				 adapter.setList(persons);
				 //刷新
				 adapter.notifyDataSetChanged();
				break;
			case ConstantUtil.NET_NOT_DATA:
				
				break;
			case ConstantUtil.NET_FAIL:

				break;

			default:
				break;
			}
			super.handleMessage(msg);
		}
	};
	private void init() {
		iv_story_h= (ImageView) findViewById(R.id.iv_story_h);
		lv_story = (ListView) findViewById(R.id.lv_story);
	}
	public class TimeThread extends Thread{
		public void run(){
			while(true){
				i++;
				if(i>=8){
					i=0;
				}
				Message msg=mHandler.obtainMessage();
				mHandler.sendMessage(msg);
				try {
					Thread.sleep(1000);
				} catch (InterruptedException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
			}
			
		}
		
	}
	private Handler mHandler = new Handler(){
		public void handleMessage(android.os.Message msg) {
			iv_story_h.setImageResource(image_head[i]);
		};
	};
}
