package com.example.jky_34_jingdong;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import android.annotation.SuppressLint;
import android.app.Activity;
import android.os.Bundle;
import android.os.Handler;
import android.os.Message;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.AdapterView;
import android.widget.AdapterView.OnItemClickListener;
import android.widget.ImageView;
import android.widget.ListView;
import android.widget.TextView;

import com.example.jky_34_jingdong.adapter.ActivityInfosAdadpter;
import com.example.jky_34_jingdong.entity.ActivityInfos;
import com.example.jky_34_jingdong.service.ActivityJsonService;
import com.example.jky_34_jingdong.service.ActivityVoidService;
import com.example.jky_34_jingdong.util.ConstantUtil;

public class ActivityInfosActivity extends Activity {
	private ListView lv_item_activity;
	private ImageView tv_activity_hot,tv_activity_no_hot;
	private List<ActivityInfos> lists;
	private ActivityInfosAdadpter adapter;
	private Map<String, String>map=new HashMap<String, String>(); 
	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.activity_activity_infos);
		init();
		adapter=new ActivityInfosAdadpter(this);
		lv_item_activity.setAdapter(adapter);
		lv_item_activity.setOnItemClickListener(new OnItemClickListener() {
			@Override
			public void onItemClick(AdapterView<?> parent, View view,
					int position, long id) {
				ActivityInfos info=(ActivityInfos) adapter.getItem(position);
				final int _id=info._id;
				ImageView ib_activity_button=(ImageView) view.findViewById(R.id.ib_activity_button);
				final TextView iv_activity_count=(TextView) view.findViewById(R.id.iv_activity_count);
				ib_activity_button.setOnClickListener(new OnClickListener() {
					public void onClick(View v) {
						iv_activity_count.setText(Integer.parseInt(iv_activity_count.getText()+"")+1+"");
						CharSequence count=iv_activity_count.getText();
						final Map<String, String> map1=new HashMap<String, String>();
						map1.put("_id", _id+"");
						map1.put("count", count+"");
						final ActivityVoidService service =new ActivityVoidService();
						new Thread(){
							public void run() {
								try {
									service.sendStringToService(ConstantUtil.ACTIVITY_PATH_2, map1);
								} catch (Exception e) {
									// TODO Auto-generated catch block
									e.printStackTrace();
								}
							};
						}.start();
					}
				});
			}
		});
		String hot="热门";
		getThread(hot);
	}
	//热门
		@SuppressLint("NewApi")
		public void hotClick(View view){
			String hot="热门";
			tv_activity_hot.setBackground(getResources().getDrawable(R.drawable.hot_1));
			tv_activity_no_hot.setBackground(getResources().getDrawable(R.drawable.recently_1));
			getThread(hot);
		}
		//最新
		@SuppressLint("NewApi")
		public void newClick(View view){
			String newStr="最近";
			tv_activity_hot.setBackground(getResources().getDrawable(R.drawable.hot_2));
			tv_activity_no_hot.setBackground(getResources().getDrawable(R.drawable.recently_2));
//			Toast.makeText(ActivityInfosActivity.this, newStr, Toast.LENGTH_LONG).show();
			getThread(newStr);
		}
	private void getThread(String hot) {
		final ActivityJsonService service=new ActivityJsonService();
		map.put("hot", hot);
		new Thread(){
			public void run() {
				try {
					List<ActivityInfos> list = service.getActivityInfoJson(ConstantUtil.ACTIVITY_PATH, map);
					if(list!=null){
						Message message = mHandler.obtainMessage();
						message.what=ConstantUtil.NET_SUCCESS;
						message.obj=list;
						mHandler.sendMessage(message);
					}else {
						mHandler.sendEmptyMessage(ConstantUtil.NET_NOT_DATA);
					}
				} catch (Exception e) {
					mHandler.sendEmptyMessage(ConstantUtil.NET_FAIL);
					e.printStackTrace();
				}
			};
		}.start();
	}
	private Handler mHandler=new Handler(){
		public void handleMessage(android.os.Message msg) {
			switch (msg.what) {
			case ConstantUtil.NET_SUCCESS:
				 lists=(List<ActivityInfos>) msg.obj;
				adapter.setList(lists);
				adapter.notifyDataSetChanged();
				break;
			case ConstantUtil.NET_NOT_DATA:
				break;
			case ConstantUtil.NET_FAIL:
				break;
			default:
				break;
			}
			
		};
	};
	private void init() {
		tv_activity_hot=(ImageView) findViewById(R.id.tv_activity_hot);
		tv_activity_no_hot=(ImageView) findViewById(R.id.tv_activity_no_hot);
		lv_item_activity=(ListView) findViewById(R.id.lv_item_activity);
	}
}
