package com.example.jky_34_jingdong;

import java.util.HashMap;
import java.util.Map;

import com.example.jky_34_jingdong.service.CartService;
import com.example.jky_34_jingdong.service.OrderService;
import com.example.jky_34_jingdong.util.ConstantUtil;

import android.os.Bundle;
import android.os.Handler;
import android.os.Message;
import android.app.Activity;
import android.content.Intent;
import android.text.TextUtils;
import android.view.Menu;
import android.view.View;
import android.widget.EditText;

public class OrderActivity extends Activity {
	private EditText order_name,order_address,order_tel;
	private Map<String, String> map=new HashMap<String, String>();
	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.activity_order);
		init();
		Intent intent=getIntent();
		String count=intent.getStringExtra("count");
		String username=intent.getStringExtra("username");
		map.put("count",count);
		map.put("name",username);
	}
	private void init() {
		order_name=(EditText) findViewById(R.id.order_name);
		order_address=(EditText) findViewById(R.id.order_address);
		order_tel=(EditText) findViewById(R.id.order_tel);
		
	}
	public void submit(View view){
		String name=order_name.getText()+"";
		String address=order_address.getText()+"";
		String tel=order_tel.getText()+"";
		if(TextUtils.isEmpty(name)){
			ConstantUtil.MyToast("请填写收货人！", this);
			return;
		}
		if(TextUtils.isEmpty(address)){
			ConstantUtil.MyToast("请填写收货地址！", this);
			return;
		}
		if(TextUtils.isEmpty(tel)){
			ConstantUtil.MyToast("请填写联系电话！", this);
			return;
		}
		map.put("address", address);
		map.put("tel", tel);
		final OrderService service=new OrderService();
		new Thread(){
			public void run() {
				try {
					String m=service.addOrder(ConstantUtil.ORDER_PATH, map);
					if(m!=null){
						Message msg=mHandler.obtainMessage();
						msg.what=ConstantUtil.NET_SUCCESS;
						msg.obj=m;
						mHandler.sendMessage(msg);
					}else{
						mHandler.sendEmptyMessage(ConstantUtil.NET_NOT_DATA);
					}
				} catch (Exception e) {
					mHandler.sendEmptyMessage(ConstantUtil.NET_FAIL);
					e.printStackTrace();
				}
			};
		}.start();
	}
	private Handler mHandler=new Handler(){
		public void handleMessage(android.os.Message msg) {
			switch (msg.what) {
			case ConstantUtil.NET_SUCCESS:
				String str=(String) msg.obj;
				if(str.equals("true")){
					ConstantUtil.MyToast("订单提交完成！",OrderActivity.this);
					CartService cartService=new CartService(OrderActivity.this);
					cartService.deleteCart();
					Intent intent=new Intent(OrderActivity.this,MainActivity.class);
					startActivity(intent);
				}
				break;
			case ConstantUtil.NET_NOT_DATA:
				
				break;
			case ConstantUtil.NET_FAIL:
				
				break;
			default:
				break;
			}
		};
	};
}
