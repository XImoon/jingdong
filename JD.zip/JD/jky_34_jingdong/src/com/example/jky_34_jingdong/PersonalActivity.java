package com.example.jky_34_jingdong;
import java.io.File;

import net.tsz.afinal.FinalHttp;
import net.tsz.afinal.http.AjaxCallBack;

import com.example.jky_34_jingdong.entity.UserInfo;
import com.example.jky_34_jingdong.entity.VersionInfo;
import com.example.jky_34_jingdong.service.LoginService;
import com.example.jky_34_jingdong.service.VersionService;
import com.example.jky_34_jingdong.util.ConstantUtil;

import android.net.Uri;
import android.os.Bundle;
import android.os.Environment;
import android.os.Handler;
import android.os.Message;
import android.app.Activity;
import android.app.AlertDialog;
import android.app.ProgressDialog;
import android.content.DialogInterface;
import android.content.DialogInterface.OnClickListener;
import android.content.Intent;
import android.content.pm.PackageInfo;
import android.content.pm.PackageManager;
import android.content.pm.PackageManager.NameNotFoundException;
import android.view.Menu;
import android.view.View;
import android.widget.Button;
import android.widget.ImageButton;
import android.widget.ImageView;
import android.widget.TextView;
public class PersonalActivity extends Activity {
	private ImageView user_iv_img;
	private TextView user_welcome;
	private Button personal_login_button;
	private VersionInfo versionInfo;
	private String currentVersion;
	private String newVersion;
	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.activity_personal);
		init();
		initView();
		currentVersion=getCurrentVersion();
	}
	private void initView() {
		LoginService service=new LoginService(this);
		UserInfo info=service.query();
		if(info!=null){
			int img_id=Integer.parseInt(info.user_pic);
			//ConstantUtil.MyToast(img_id+"", PersonalActivity.this);
			user_iv_img.setImageDrawable(getResources().getDrawable(img_id));
			user_welcome.setText(info.username+"欢迎您！");
			personal_login_button.setVisibility(View.GONE);
		}else{
			user_iv_img.setImageResource(R.drawable.android_user_no_image);
			user_welcome.setText("欢迎来到京东!");
			personal_login_button.setVisibility(View.VISIBLE);
		}
	}
	private void init() {
		user_iv_img=(ImageView) findViewById(R.id.user_iv_img);
		user_welcome=(TextView) findViewById(R.id.user_welcome);
		personal_login_button=(Button) findViewById(R.id.personal_login_button);
	}
	public void login(View view){
		Intent intent=new Intent(this,LoginActivity.class);
		startActivity(intent);
	}
	public void changeUser(View view){
		Intent intent=new Intent(this,LoginActivity.class);
		startActivity(intent);
	}
	public void attention(View view){
		Intent intent=new Intent(this,AttentionActivity.class);
		startActivity(intent);
	}
	public void purse(View view){
		LoginService service=new LoginService(this);
		UserInfo info = service.query();
		if(info!=null){
			Intent intent=new Intent(this, MyPurseActivity.class);
			intent.putExtra("username", info.username);
			startActivity(intent);
		}else{
			Intent intent=new Intent(this, LoginActivity.class);
			startActivity(intent);
		}
	}
	public void update(View view){
		final VersionService service=new VersionService();
		new Thread(){
			public void run() {
				try {
					VersionInfo info=service.getVersionInfo(ConstantUtil.VERSION_PATH,"utf-8");
					if(info!=null){
						Message msg=mHandler.obtainMessage();
						msg.what=ConstantUtil.NET_SUCCESS;
						msg.obj=info;
						mHandler.sendMessage(msg);
					}
				} catch (Exception e) {
					mHandler.sendEmptyMessage(ConstantUtil.NET_FAIL);
					e.printStackTrace();
				}
			};
		}.start();
	}
	private Handler mHandler=new Handler(){
		public void handleMessage(android.os.Message msg) {
			switch (msg.what) {
			case ConstantUtil.NET_SUCCESS:
				versionInfo=(VersionInfo) msg.obj;
				newVersion=versionInfo.versionid;
				if(newVersion.equals(currentVersion)){
					ConstantUtil.MyToast("当前版本已是最新版本！",PersonalActivity.this);
				}else{
					AlertDialog.Builder dialog=new AlertDialog.Builder(PersonalActivity.this);
					dialog.setTitle("更新");
					dialog.setMessage(versionInfo.versionmsg);
					dialog.setNegativeButton("稍后再说",new OnClickListener() {	
						@Override
						public void onClick(DialogInterface dialog, int which) {
							dialog.dismiss();
						}
					});
					dialog.setPositiveButton("马上更新",new OnClickListener() {
						@Override
						public void onClick(DialogInterface dialog, int which) {
							download();
						}
					});
					dialog.show();
				}
				break;
			case ConstantUtil.NET_NOT_DATA:
				
				break;
			case ConstantUtil.NET_FAIL:
					
				break;
			default:
				break;
			}
		};
	};
	private void download() {
		final ProgressDialog pd=new ProgressDialog(this);
		pd.setTitle("正在下载...");
		pd.setProgressStyle(ProgressDialog.STYLE_HORIZONTAL);
		
		pd.show();
		//创建下载对象
		FinalHttp fh=new FinalHttp();
		//从哪里下载
		//下到sd卡
		if(Environment.getExternalStorageState().equals(Environment.MEDIA_MOUNTED)){
			File sd_card=Environment.getExternalStorageDirectory();
			File target=new File(sd_card,"jingdong.apk");
			fh.download(versionInfo.versionurl, target.getAbsolutePath(), new AjaxCallBack<File>() {
				@Override
				public void onLoading(long count, long current) {
					pd.setMax((int) count);
					pd.setProgress((int) current);
					super.onLoading(count, current);
				}
				@Override
				public void onSuccess(File t) {
					pd.dismiss();
					install(t);
					super.onSuccess(t);
				}
			});
		}
	}
	private void install(File t) {
		Intent intent = new Intent();
		intent.setAction(Intent.ACTION_VIEW);
		intent.setDataAndType(Uri.fromFile(t),
				"application/vnd.android.package-archive");
		startActivity(intent);
	}
	private void unInstall(File t) {
		Intent intent = new Intent();
		intent.setAction(Intent.ACTION_DELETE);// 指定动作
		// 指定数据
		intent.setData(Uri.parse("package:" + this.getPackageName()));
		startActivity(intent);
	}
	private String getCurrentVersion() {
		PackageManager manager=getPackageManager();
		try {
			PackageInfo packageInfo=manager.getPackageInfo(getPackageName(),0);
			currentVersion=packageInfo.versionName;
		} catch (NameNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return currentVersion;
	}
	public void zhuxiao(View view){
		LoginService loginService=new LoginService(this);
		boolean flag=loginService.delete();
		if(flag){
			ConstantUtil.MyToast("账号已注销",this);
			Intent intent=new Intent(this,MainActivity.class);
			startActivity(intent);
		}
	}
}
