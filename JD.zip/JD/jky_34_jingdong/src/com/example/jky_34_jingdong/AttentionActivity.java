package com.example.jky_34_jingdong;

import java.util.List;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.AdapterView.OnItemClickListener;
import android.widget.GridView;

import com.example.jky_34_jingdong.adapter.ScanAdapter;
import com.example.jky_34_jingdong.entity.ProductInfo;
import com.example.jky_34_jingdong.entity.ScanInfo;
import com.example.jky_34_jingdong.service.ScanService;

public class AttentionActivity extends Activity {
	private GridView gv_attention;
	private ScanAdapter adapter;
	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.activity_attention);
		init();
		adapter=new ScanAdapter(this);
		ScanService service=new ScanService(this);
		List<ScanInfo> lists=service.queryAll("我的关注");
		adapter.setLists(lists);
		gv_attention.setAdapter(adapter);
		gv_attention.setOnItemClickListener(new MyListener());
	}
	private class MyListener implements OnItemClickListener{
		@Override
		public void onItemClick(AdapterView<?> parent, View view, int position,
				long id) {
			ScanInfo info=(ScanInfo) adapter.getItem(position);
			ProductInfo pinfo=new ProductInfo();
			pinfo.pro_id=info.pro_id;
			pinfo.pro_description=info.pro_description;
			pinfo.pro_price=info.pro_price+"";
			pinfo.pro_images=info.pro_images;
			Intent intent=new Intent(AttentionActivity.this,ProductDetailActivity.class);
			intent.putExtra("product",pinfo);
			startActivity(intent);
		}
		
	};
	private void init() {
		gv_attention=(GridView) findViewById(R.id.gv_attention);
	}
	public void back(View view){
		Intent intent=new Intent(this,MainActivity.class);
		startActivity(intent);
	}
}
