package com.example.jky_34_jingdong;

import com.example.jky_34_jingdong.adapter.SearchCursorAdapter;
import com.example.jky_34_jingdong.entity.SearchInfo;
import com.example.jky_34_jingdong.service.SerchDao;
import com.example.jky_34_jingdong.util.ConstantUtil;

import android.os.Bundle;
import android.app.Activity;
import android.content.Intent;
import android.database.Cursor;
import android.view.Menu;
import android.view.View;
import android.widget.AdapterView;
import android.widget.AdapterView.OnItemClickListener;
import android.widget.AutoCompleteTextView;
import android.widget.GridView;

public class SearchActivity extends Activity {
	private AutoCompleteTextView auto_search;
	private GridView search_gv_item;
	private SearchCursorAdapter adapter;
	private SerchDao dao;
	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.activity_search);
		init();
		dao=new SerchDao(this);
		Cursor cs=dao.findByCount();
		adapter=new SearchCursorAdapter(this, cs);
		search_gv_item.setAdapter(adapter);
		search_gv_item.setOnItemClickListener(new MyListener());
	}
	private void init() {
		auto_search=(AutoCompleteTextView) findViewById(R.id.auto_search);
		search_gv_item=(GridView) findViewById(R.id.search_gv_item);
	}
	public class MyListener implements OnItemClickListener{
		@Override
		public void onItemClick(AdapterView<?> parent, View view, int position,
				long id) {
			//SearchInfo info=(SearchInfo) adapter.getItem(position);
			//Toast.makeText(SearchActivity.this, info.context, Toast.LENGTH_LONG).show();
			//ConstantUtil.MyToast(info.context,SearchActivity.this);
			Cursor cs=(Cursor) adapter.getItem(position);
			//ConstantUtil.MyToast(cs.getString(cs.getColumnIndex("search_xontent")),SearchActivity.this);
			Intent intent=new Intent(SearchActivity.this,CategoryListActivity.class);
			intent.putExtra("category", cs.getString(cs.getColumnIndex("search_xontent")));
			startActivity(intent);
		}
	}
	public void search(View view){
		String content=auto_search.getText()+"";
		Intent intent=new Intent(this, CategoryListActivity.class);
		String search=auto_search.getText()+"";
		SearchInfo infos=new SearchInfo(search,1);
		SearchInfo info = dao.queryByContent(search);
		//如果开始查了这个商品，就将次数加1
		if(info!=null){
			int _id=info._id;
			int count=info.count;
			count++;
			dao.update(_id, count);
		}else{
			dao.addContext(infos);
		}
		intent.putExtra("category", content);
		startActivity(intent);
	}
}
