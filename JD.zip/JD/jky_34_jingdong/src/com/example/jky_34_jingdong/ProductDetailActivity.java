package com.example.jky_34_jingdong;
import java.util.ArrayList;
import java.util.List;
import android.app.Activity;
import android.content.Intent;
import android.graphics.Bitmap;
import android.os.Bundle;
import android.os.Handler;
import android.os.Message;
import android.view.GestureDetector;
import android.view.MotionEvent;
import android.view.View;
import android.widget.ImageView;
import android.widget.TextView;
import com.example.jky_34_jingdong.entity.CartInfo;
import com.example.jky_34_jingdong.entity.ProductInfo;
import com.example.jky_34_jingdong.entity.ScanInfo;
import com.example.jky_34_jingdong.service.CartService;
import com.example.jky_34_jingdong.service.ProductService;
import com.example.jky_34_jingdong.service.ScanService;
import com.example.jky_34_jingdong.util.ConstantUtil;
public class ProductDetailActivity extends Activity {
	private TextView pro_detail_description,pro_detail_price;
	private ProductInfo info;
	private ImageView pro_detail_img;
	private List<Bitmap> lists=null;
	private Bitmap b=null;
	//定义手势检测对象
	private GestureDetector gestureDetector;
	//定义当前图片的下标
	private int count=0;
	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.activity_product_detail);
		Intent intent=getIntent();
		info=(ProductInfo) intent.getSerializableExtra("product");
		init();
		initView();
		//将商品添加至最近浏览
		addToScan();
		new Thread(){
			public void run() {
				List<Bitmap> list=new ArrayList<Bitmap>();
				for(int i=1;i<=5;i++){
					String path=ConstantUtil.WEB_PATH+i+"_"+info.pro_images;
					Bitmap bitmap;
					try {
						bitmap = ProductService.getBitmapFromPath(path);
						bitmap=ConstantUtil.zoomBitmap(bitmap,320,320);
						list.add(bitmap);
						bitmap=null;
					} catch (Exception e) {
						// TODO Auto-generated catch block
						e.printStackTrace();
					}
				}
				Bitmap bt=null;
				try {
					bt=ProductService.getBitmapFromPath(ConstantUtil.WEB_PATH+info.pro_images);
					bt=ConstantUtil.zoomBitmap(bt,320,320);
				} catch (Exception e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
				if(list.size()!=0){
					Message msg=mHandler.obtainMessage();
					msg.obj=list;
					msg.what=1;
					mHandler.sendMessage(msg);
				}else{
					Message msg=mHandler.obtainMessage();
					msg.obj=bt;
					msg.what=2;
					mHandler.sendMessage(msg);
				}
			};
		}.start();
		setListener();
	}
	private void setListener() {
		gestureDetector=new GestureDetector(ProductDetailActivity.this,onGestureListener);
	}
	@Override
	public boolean onTouchEvent(MotionEvent event) {
		// TODO Auto-generated method stub
		return gestureDetector.onTouchEvent(event);
	}
	private GestureDetector.OnGestureListener onGestureListener=
			new GestureDetector.SimpleOnGestureListener(){
			public boolean onFling(MotionEvent e1, MotionEvent e2, float velocityX, float velocityY) {
				float x=e2.getX()-e1.getX();
				if(x>0){
					count++;
					if(count>4){
						count=4;
					}
				}else{
					count--;
					if(count<0){
						count=0;
					}
				}
				//System.out.println(lists.size()+"===============");
				if(lists!=null&&lists.size()>0){
					changeImg();
				}
				return true;
			};
	};
	public void changeImg(){
		pro_detail_img.setImageBitmap(lists.get(count));
	}
	private Handler mHandler=new Handler(){
		public void handleMessage(Message msg) {
			switch (msg.what) {
			case 1:
				lists=(List<Bitmap>) msg.obj;
				pro_detail_img.setImageBitmap(lists.get(0));
				break;
			case 2:
				b=(Bitmap) msg.obj;
				pro_detail_img.setImageBitmap(b);
				break;
			default:
				break;
			}
		};
	};
	private void initView() {
		pro_detail_description.setText(info.pro_description);
		pro_detail_price.setText("￥"+info.pro_price);
	}
	private void init() {
		pro_detail_description=(TextView) findViewById(R.id.pro_detail_description);
		pro_detail_price=(TextView) findViewById(R.id.pro_detail_price);
		pro_detail_img=(ImageView) findViewById(R.id.pro_detail_img);
	}
	public void addCart(View view){
		boolean flag=false;
		//Toast.makeText(this,info.pro_description, Toast.LENGTH_LONG).show();
		CartService service=new CartService(this);
		CartInfo cartInfo=service.findById(info.pro_id);
		if(cartInfo==null){
			cartInfo=new CartInfo();
			cartInfo.pro_id=info.pro_id;
			cartInfo.pro_description=info.pro_description;
			cartInfo.pro_price=Double.parseDouble(info.pro_price);
			cartInfo.pro_count=1;
			cartInfo.pro_images=info.pro_images;
			flag=service.addProduct(cartInfo);
		}else{
			cartInfo.pro_count+=1;
			flag=service.updateCart(cartInfo);
		}
		if(flag){
			ConstantUtil.MyToast("恭喜您！已成功添加至购物车！",this);
		}
	}
	public void back(View view){
		Intent intent=new Intent(this,MainActivity.class);
		startActivity(intent);
	}
	//添加最近浏览
	public void addToScan(){
		ScanService service=new ScanService(this);
		boolean flag=service.query(info.pro_id,"最近浏览");
		if(flag){
			service.deleteScan(info.pro_id);
		}
		ScanInfo sInfo=new ScanInfo();
		sInfo.pro_id=info.pro_id;
		sInfo.pro_description=info.pro_description;
		sInfo.pro_price=Double.parseDouble(info.pro_price);
		sInfo.pro_images=info.pro_images;
		sInfo.status="最近浏览";
		service.addScan(sInfo);
	}
	public void addToGuan(View view){
		ScanService service=new ScanService(this);
		boolean flag=service.query(info.pro_id,"我的关注");
		if(flag){
			service.deleteScan(info.pro_id);
		}
		ScanInfo sInfo=new ScanInfo();
		sInfo.pro_id=info.pro_id;
		sInfo.pro_description=info.pro_description;
		sInfo.pro_price=Double.parseDouble(info.pro_price);
		sInfo.pro_images=info.pro_images;
		sInfo.status="我的关注";
		boolean f=service.addScan(sInfo);
		if(f){
			ConstantUtil.MyToast("谢谢您的关注!",this);
		}
	}
}
