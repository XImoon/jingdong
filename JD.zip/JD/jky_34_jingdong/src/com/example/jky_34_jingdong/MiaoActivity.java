package com.example.jky_34_jingdong;

import java.util.List;

import com.example.jky_34_jingdong.adapter.MiaoAdapter;
import com.example.jky_34_jingdong.entity.ProductInfo;
import com.example.jky_34_jingdong.service.ProductService;
import com.example.jky_34_jingdong.util.ConstantUtil;

import android.os.Bundle;
import android.os.Handler;
import android.os.Message;
import android.app.Activity;
import android.content.Intent;
import android.view.Menu;
import android.view.View;
import android.widget.AdapterView;
import android.widget.AdapterView.OnItemClickListener;
import android.widget.ListView;
import android.widget.TextView;
import android.widget.Toast;

public class MiaoActivity extends Activity {
	private ListView lv_miao_products;
	private MiaoAdapter miaoAdapter;
	private ProductService service;
	private TextView tv_miao_txt;
	private String path;
	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.activity_miao);
		init();
		Intent intent=getIntent();
		String status=intent.getStringExtra("status");
		if(status.equals("掌上秒杀")){
			path=ConstantUtil.MIAO_PATH;
		}else{
			path=ConstantUtil.XIAO_PATH;
			tv_miao_txt.setText("促销卖场");
		}
		miaoAdapter=new MiaoAdapter(this);
		lv_miao_products.setAdapter(miaoAdapter);
		service=new ProductService();
		new Thread(){
			public void run() {
				try {
					List<ProductInfo> lists=service.getProductsFromGson(path);
					if(lists!=null){
						Message msg=mHandler.obtainMessage();
						msg.what=0;
						msg.obj=lists;
						mHandler.sendMessage(msg);
					}else{
						mHandler.sendEmptyMessage(1);
					}
				} catch (Exception e) {
					mHandler.sendEmptyMessage(2);
					e.printStackTrace();
				}
			};
		}.start();
		lv_miao_products.setOnItemClickListener(new MiaoListener());
	}
	public class MiaoListener implements OnItemClickListener{
		@Override
		public void onItemClick(AdapterView<?> parent, View view, int position,
				long id) {
			ProductInfo info=(ProductInfo) miaoAdapter.getItem(position);
			//Toast.makeText(MiaoActivity.this,info.pro_description,Toast.LENGTH_LONG).show();
			Intent intent=new Intent(MiaoActivity.this,ProductDetailActivity.class);
			intent.putExtra("product",info);
			startActivity(intent);
		}
	}
	private Handler mHandler=new Handler(){
		public void handleMessage(Message msg) {
			switch (msg.what) {
			case 0:
				List<ProductInfo> lists=(List<ProductInfo>) msg.obj;
				miaoAdapter.setLists(lists);
				miaoAdapter.notifyDataSetChanged();
				break;
			case 1:
				
				break;
			case 2:
			
			break;
			default:
				break;
			}
		};
	};
	private void init() {
		tv_miao_txt=(TextView) findViewById(R.id.tv_miao_txt);
		lv_miao_products=(ListView) findViewById(R.id.lv_miao_products);
	}
	public void back(View view){
		Intent intent=new Intent(this,MainActivity.class);
		startActivity(intent);
	}
}
