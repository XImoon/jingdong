package com.example.jky_34_jingdong.entity;

public class SearchInfo {
	public int _id;
	public String context;
	public int count;
	public SearchInfo(int _id, String context, int count) {
		super();
		this._id = _id;
		this.context = context;
		this.count = count;
	}
	public SearchInfo() {
		super();
		// TODO Auto-generated constructor stub
	}
	
	public SearchInfo(String context, int count) {
		super();
		this.context = context;
		this.count = count;
	}
	@Override
	public String toString() {
		return "SearchInfo [_id=" + _id + ", context=" + context + ", count="
				+ count + "]";
	}
	public SearchInfo(String context) {
		super();
		this.context = context;
	}
	
}
