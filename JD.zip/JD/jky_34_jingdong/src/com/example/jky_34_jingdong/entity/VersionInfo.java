package com.example.jky_34_jingdong.entity;
public class VersionInfo {
	public String versionid;
	public String versionmsg;
	public String versionurl;
	public VersionInfo() {
		super();
		// TODO Auto-generated constructor stub
	}
	public VersionInfo(String versionid, String versionmsg, String versionurl) {
		super();
		this.versionid = versionid;
		this.versionmsg = versionmsg;
		this.versionurl = versionurl;
	}
	public VersionInfo(String versionmsg, String versionurl) {
		super();
		this.versionmsg = versionmsg;
		this.versionurl = versionurl;
	}
	@Override
	public String toString() {
		return "VersionInfo [versionid=" + versionid + ", versionmsg="
				+ versionmsg + ", versionurl=" + versionurl + "]";
	}
	
}
