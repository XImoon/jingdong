package com.example.jky_34_jingdong.entity;

public class ActivityInfos {
	public  int _id;
	public String activity_image;
	public String activity_title;
	public String activity_content;
	public int activity_count;
	public String activity_type;
	public ActivityInfos() {
		super();
		// TODO Auto-generated constructor stub
	}
	@Override
	public String toString() {
		return "ActivityInfos [_id=" + _id + ", activity_image="
				+ activity_image + ", activity_title=" + activity_title
				+ ", activity_content=" + activity_content
				+ ", activity_count=" + activity_count + ", activity_type="
				+ activity_type + "]";
	}
	public ActivityInfos(String activity_image, String activity_title,
			String activity_content, int activity_count, String activity_type) {
		super();
		this.activity_image = activity_image;
		this.activity_title = activity_title;
		this.activity_content = activity_content;
		this.activity_count = activity_count;
		this.activity_type = activity_type;
	}
	public ActivityInfos(int _id, String activity_image, String activity_title,
			String activity_content, int activity_count, String activity_type) {
		super();
		this._id = _id;
		this.activity_image = activity_image;
		this.activity_title = activity_title;
		this.activity_content = activity_content;
		this.activity_count = activity_count;
		this.activity_type = activity_type;
	}
}
