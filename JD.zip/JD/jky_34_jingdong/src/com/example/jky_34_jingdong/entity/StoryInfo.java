package com.example.jky_34_jingdong.entity;

public class StoryInfo {
	public int _id;
	public String name;
	public String image;
	public String story;
	public String image2;
	public StoryInfo() {
		// TODO Auto-generated constructor stub
	}
	public StoryInfo(int _id, String name, String image, String story , String image2) {
		super();
		this._id = _id;
		this.name = name;
		this.image = image;
		this.story = story;
		this.image2 = image2;
	}
	@Override
	public String toString() {
		return "StoryInfo [_id=" + _id + ", name=" + name + ", image=" + image
				+ ", story=" + story + ", image2=" + image2 + "]";
	}
}
