package com.example.jky_34_jingdong.entity;
public class ScanInfo extends CartInfo{
	public String status;
}
