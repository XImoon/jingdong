package com.example.jky_34_jingdong.entity;
public class CategoryInfo {
	public int _id;
	public String images;
	public String pro_category;
	public String father_category;
	@Override
	public String toString() {
		return "CategoryInfo [_id=" + _id + ", images=" + images + ", p_name="
				+ father_category + ", son_name=" + pro_category + "]";
	}
	public CategoryInfo(int id, String images, String sonName, String pName) {
		super();
		_id = id;
		this.images = images;
		pro_category = sonName;
		father_category = pName;
	}
	public CategoryInfo() {
		super();
		// TODO Auto-generated constructor stub
	}
}
