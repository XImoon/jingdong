package com.example.jky_34_jingdong.entity;
public class OrderInfo {
	public int _id;
	public String name;
	public String address;
	public String tel;
	public String status;
	public String count;
	public String date;
	public OrderInfo() {
		super();
		// TODO Auto-generated constructor stub
	}
	
	public OrderInfo(String name, String address, String tel, String status,
			String count, String date) {
		super();
		this.name = name;
		this.address = address;
		this.tel = tel;
		this.status = status;
		this.count = count;
		this.date = date;
	}

	public OrderInfo(int _id, String name, String address, String tel,
			String status, String count, String date) {
		super();
		this._id = _id;
		this.name = name;
		this.address = address;
		this.tel = tel;
		this.status = status;
		this.count = count;
		this.date = date;
	}

	@Override
	public String toString() {
		
		return name+address+tel+status+count+date;
	}
}
