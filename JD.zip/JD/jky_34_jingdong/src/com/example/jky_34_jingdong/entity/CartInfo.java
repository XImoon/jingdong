package com.example.jky_34_jingdong.entity;
import java.io.Serializable;
public class CartInfo implements Serializable{
	public int _id;
	public int pro_id;
	public String pro_description;
	public double pro_price;
	public int pro_count;
	public String pro_images;
	public CartInfo(int _id, int pro_id, String pro_description,
			double pro_price, int pro_count, String pro_images) {
		super();
		this._id = _id;
		this.pro_id = pro_id;
		this.pro_description = pro_description;
		this.pro_price = pro_price;
		this.pro_count = pro_count;
		this.pro_images = pro_images;
	}
	public CartInfo(int pro_id, String pro_description, double pro_price,
			int pro_count, String pro_images) {
		super();
		this.pro_id = pro_id;
		this.pro_description = pro_description;
		this.pro_price = pro_price;
		this.pro_count = pro_count;
		this.pro_images = pro_images;
	}
	public CartInfo() {
		super();
		// TODO Auto-generated constructor stub
	}
	@Override
	public String toString() {
		return "CartInfo [_id=" + _id + ", pro_id=" + pro_id
				+ ", pro_description=" + pro_description + ", pro_price="
				+ pro_price + ", pro_count=" + pro_count + ", pro_images="
				+ pro_images + "]";
	}
}
