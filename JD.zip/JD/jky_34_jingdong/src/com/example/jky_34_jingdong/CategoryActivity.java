package com.example.jky_34_jingdong;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import com.example.jky_34_jingdong.adapter.CategoryGRAdapter;
import com.example.jky_34_jingdong.adapter.CategoryListAdapter;
import com.example.jky_34_jingdong.entity.CartInfo;
import com.example.jky_34_jingdong.entity.CategoryInfo;
import com.example.jky_34_jingdong.service.CategoryJsonService;
import com.example.jky_34_jingdong.service.CategoryToService;
import com.example.jky_34_jingdong.util.ConstantUtil;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.os.Handler;
import android.os.Message;
import android.view.View;
import android.widget.AdapterView;
import android.widget.AdapterView.OnItemClickListener;
import android.widget.GridView;
import android.widget.ListView;
public class CategoryActivity extends Activity {
	private ListView lv_category;
	private GridView gv_category;
	private CategoryListAdapter adapter;
	private CategoryGRAdapter adapterGr;
	private List<String> list;
	private Map<String, String> map = new HashMap<String, String>();
	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.activity_category);
		init();
		String msg="手机配件";
		getGrideView(msg);
		adapter = new CategoryListAdapter(this);
		final CategoryJsonService service = new CategoryJsonService();
		new Thread() {
			public void run() {
				try {
					list = service.getProductToJson(ConstantUtil.CATEGORY_PATH);
					if (list != null) {
						Message message = mHandler.obtainMessage();
						message.what =ConstantUtil.NET_SUCCESS;
						message.obj = list;
						mHandler.sendMessage(message);
					} else {
						mHandler.sendEmptyMessage(ConstantUtil.NET_NOT_DATA);
					}

				} catch (Exception e) {
					mHandler.sendEmptyMessage(ConstantUtil.NET_FAIL);
					e.printStackTrace();
				}
			}
		}.start();
		// 绑定
		lv_category.setAdapter(adapter);
		//监听listView
		lv_category.setOnItemClickListener(new MyListener());
		//监听每个子类下面的gradeView
		gv_category.setOnItemClickListener(new MyGRListener());
	}
	//子类的事件监听
		public class MyListener implements OnItemClickListener {
			@Override
			public void onItemClick(AdapterView<?> parent, View view,
					int position, long id) {
				// TODO Auto-generated method stub
				String msg = (String) adapter.getItem(position);
				getGrideView(msg);
			}
		}
	private Handler mHandler=new Handler(){
		public void handleMessage(android.os.Message msg) {
			switch (msg.what) {
			case ConstantUtil.NET_SUCCESS:
				List<String> list = (List<String>) msg.obj;
				adapter.setList(list);
				// 刷新
				adapter.notifyDataSetChanged();
				break;
			case ConstantUtil.NET_NOT_DATA:
				
				break;
			case ConstantUtil.NET_FAIL:
				
				break;
			case 4:
				List<CategoryInfo> infos = (List<CategoryInfo>) msg.obj;
				adapterGr.setLists(infos);
				// 刷新
				adapterGr.notifyDataSetChanged();
				break;
			default:
				break;
			}
		};
	};
	private void init() {
		lv_category = (ListView) findViewById(R.id.lv_category);
		gv_category = (GridView) findViewById(R.id.gv_category);
	}
	//显示gridView 里面的图片
	private void getGrideView(final String msg) {
		final CategoryToService ctService = new CategoryToService();
		// 子类图片
		adapterGr = new CategoryGRAdapter(CategoryActivity.this);
		new Thread() {
			public void run() {
				map.put("father_category", msg);
				try {
					@SuppressWarnings("static-access")
					List<CategoryInfo> list =ctService.getListGetCategory(
							ConstantUtil.CATEGORY_PATH_2, map);
					if (list != null) {
						Message message = mHandler.obtainMessage();
						message.what = 4;
						message.obj = list;
						mHandler.sendMessage(message);
					} else {
						mHandler.sendEmptyMessage(5);
					}
				} catch (Exception e) {
					mHandler.sendEmptyMessage(6);
					e.printStackTrace();
				}
			};
		}.start();
		gv_category.setAdapter(adapterGr);
	}
	//每个小类的事件监听
		public class MyGRListener implements OnItemClickListener{
			@Override
			public void onItemClick(AdapterView<?> parent, View view, int position,
					long id) {
			CategoryInfo info= (CategoryInfo)adapterGr.getItem(position);
			//ConstantUtil.MyToast(info.images,CategoryActivity.this);
			Intent intent=new Intent(CategoryActivity.this, CategoryListActivity.class);
			intent.putExtra("category", info.pro_category);
			startActivity(intent);	
			}	
	}
	
	
}
