/** Automatically generated file. DO NOT MODIFY */
package com.example.jky_34_jingdong;

public final class BuildConfig {
    public final static boolean DEBUG = true;
}