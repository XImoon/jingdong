/*
Navicat MySQL Data Transfer

Source Server         : my34
Source Server Version : 50170
Source Host           : localhost:3306
Source Database       : jd

Target Server Type    : MYSQL
Target Server Version : 50170
File Encoding         : 65001

Date: 2015-01-12 09:20:20
*/

SET FOREIGN_KEY_CHECKS=0;

-- ----------------------------
-- Table structure for `storyinfo`
-- ----------------------------
DROP TABLE IF EXISTS `storyinfo`;
CREATE TABLE `storyinfo` (
  `_id` int(20) NOT NULL AUTO_INCREMENT,
  `name` varchar(50) NOT NULL,
  `image` varchar(30) NOT NULL,
  `story` varchar(500) NOT NULL,
  `image2` varchar(30) NOT NULL,
  PRIMARY KEY (`_id`)
) ENGINE=MyISAM AUTO_INCREMENT=6 DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of storyinfo
-- ----------------------------
INSERT INTO `storyinfo` VALUES ('1', '大傻黄', 'dsh.jpg', '一只病得快要死的鸢对他妈妈说：“妈妈，请您不要悲伤！还是赶快祈求神明，让他们保佑我的性命吧。”妈妈回答说：“唉！我的孩儿，你想有哪位神会可怜你？几乎每一位神明都被你惹怒了，你总是从他们的祭坛上把人们献给神的祭品偷走。                             这故事是说，若要在患难中得到朋友的帮助，就必须在平时缔结友谊。', 'tu1.jpg');
INSERT INTO `storyinfo` VALUES ('2', '大傻周', 'dsz.png', '有只鹿为逃避猎人的追捕，躲藏在葡萄藤底下。猎人刚刚从旁边走过去不远，鹿就以为躲过了危险，便毫无顾及地开始吃那茂盛的葡萄叶子。叶子沙沙地抖动着，猎人们马上掉回头来，觉得叶子底下一定躲着什么动物，一箭就把鹿射中了。鹿在临死前说：“我真是该死，因为我不应该去伤害救我的葡萄藤。                                  这故事说明，那些恩将仇报的人将会被神惩罚。', 'tu2.jpg');
INSERT INTO `storyinfo` VALUES ('3', '大傻刘', 'dsl.png', '有个人生了病，医生问他怎么样，他说出汗过多。医生说：“这很好。”第二次又问他怎么样，他说畏寒怕冷，抖得十分厉害。医生说：“这也很好。”第三次医生再来问他的病情时，他说现在泻肚子。医生说：“这仍很好。”病人有一个亲戚来看他，问他怎么样，他说：“我就因这些很好而快丧命了。”                 这故事是说，只讲好话的人会给人们带来危险。', 'tu3.jpg');
INSERT INTO `storyinfo` VALUES ('4', '大傻易', 'dsy.png', '蛇和黄鼠狼在一所房子里打架。同住在房里的老鼠常常被他们吃掉，现在一见他们在打架，便纷纷跑出来。然而，他们双方一见到老鼠，便立刻停止了互相的厮杀，一齐朝老鼠扑过去。                               这是说，那些自行卷入政客们互相争权夺利的人，不知不觉地成了政客们的牺牲品。', 'tu4.jpg');
INSERT INTO `storyinfo` VALUES ('5', '大傻B肖', 'dsx.png', '有个富人养着家鹅和天鹅，他们的用处却不一样：养天鹅完全是因为他善于唱歌，养家鹅仅为吃肉。有一次，主人准备将家鹅派上用场，时值夜晚，辨别不出哪是家鹅哪是天鹅，天鹅被作为家鹅抓了出去。这时，他唱起歌来，以表他的悲哀。歌声道明了天鹅的本性，使他幸免于死难。                                      这故事说明，音乐常常使生命延续。', 'tu5.jpg');
