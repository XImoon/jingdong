package com.jky.dao;
import java.util.ArrayList;
import java.util.List;

import com.jky.db.DBHelper;
import com.jky.entity.CategoryInfo;
import com.jky.entity.ProductInfo;
public class ProductDao extends DBHelper {
	public List<ProductInfo> queryAllProducts(){
		List<ProductInfo> lists=null;
		String sql="select * from productinfo";
		try {
			rs=super.query(sql,null);
			if(rs!=null){
				lists=new ArrayList<ProductInfo>();
				while(rs.next()){
					ProductInfo info=new ProductInfo();
					info.pro_id=rs.getInt("pro_id");
					info.pro_name=rs.getString("pro_name");
					info.pro_price=rs.getString("pro_price");
					info.pro_description=rs.getString("pro_description");
					info.pro_images=rs.getString("pro_images");
					info.pro_status=rs.getString("pro_status");
					info.pro_category=rs.getString("pro_category");
					lists.add(info);
				}
			}
		} catch (Exception e) {
			// TODO: handle exception
		}finally{
			closeAll();
		}
		return lists;
	}
	//掌上秒杀
	public List<ProductInfo> queryMiao(){
		List<ProductInfo> lists=null;
		String sql="select * from productinfo where pro_status='掌上秒杀' order by pro_id desc ";
		try {
			rs=super.query(sql,null);
			if(rs!=null){
				lists=new ArrayList<ProductInfo>();
				while(rs.next()){
					ProductInfo info=new ProductInfo();
					info.pro_id=rs.getInt("pro_id");
					info.pro_name=rs.getString("pro_name");
					info.pro_price=rs.getString("pro_price");
					info.pro_description=rs.getString("pro_description");
					info.pro_images=rs.getString("pro_images");
					info.pro_status=rs.getString("pro_status");
					info.pro_category=rs.getString("pro_category");
					lists.add(info);
					if(lists.size()>=3){
						return lists;
					}
				}
			}
		} catch (Exception e) {
			// TODO: handle exception
		}finally{
			closeAll();
		}
		return lists;
	}
	//根据状态查询
	public List<ProductInfo> queryByStatus(String status){
		List<ProductInfo> lists=null;
		String sql="select * from productinfo where pro_status=? order by pro_id desc ";
		List<String> list=new ArrayList<String>();
		list.add(status);
		try {
			rs=super.query(sql,list);
			if(rs!=null){
				lists=new ArrayList<ProductInfo>();
				while(rs.next()){
					ProductInfo info=new ProductInfo();
					info.pro_id=rs.getInt("pro_id");
					info.pro_name=rs.getString("pro_name");
					info.pro_price=rs.getString("pro_price");
					info.pro_description=rs.getString("pro_description");
					info.pro_images=rs.getString("pro_images");
					info.pro_status=rs.getString("pro_status");
					info.pro_category=rs.getString("pro_category");
					lists.add(info);
				}
			}
		} catch (Exception e) {
			// TODO: handle exception
		}finally{
			closeAll();
		}
		return lists;
	}
	//查找分类数据
	public List<String> queryFromStatus(){
		List<String> lists=null;
		String sql="select distinct father_category from pro_category";
		rs=super.query(sql, null);
		try {
			if(rs!=null){
				lists=new ArrayList<String>();
				while(rs.next()){
						String pro=rs.getString("father_category");
						lists.add(pro);
					}
				}
		} catch (Exception e) {
			// TODO: handle exception
		}
		return lists;
	}
	//通过父类查找子类
	public List<CategoryInfo> querySonFromStatus(String pro_p_category){
		List<CategoryInfo> lists=null;
		String sql="select * from pro_category where father_category=?";
		List<String> list=new ArrayList<String>();
		list.add(pro_p_category);
		rs=super.query(sql, list);
		try {
		if(rs!=null){
			lists=new ArrayList<CategoryInfo>();
			while(rs.next()){
				CategoryInfo info=new CategoryInfo();
				info._id=rs.getInt("_id");
				info.pro_category=rs.getString("pro_category");
				info.images=rs.getString("images");
				info.father_category=rs.getString("father_category");
				lists.add(info);
				}
			}
		}catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return lists;
	}
	//通过父类查找子类
	public List<ProductInfo> queryParFromStatus(String p_name){
		List<ProductInfo> lists=null;
		String sql="select * from productinfo where pro_category=?";
		List<String> list=new ArrayList<String>();
		list.add(p_name);
		rs=super.query(sql, list);
		try {
			if(rs!=null){
				lists=new ArrayList<ProductInfo>();
				while(rs.next()){
					ProductInfo info=new ProductInfo();
					info.pro_id=rs.getInt("pro_id");
					info.pro_name=rs.getString("pro_name");
					info.pro_price=rs.getString("pro_price");
					info.pro_description=rs.getString("pro_description");
					info.pro_images=rs.getString("pro_images");
					info.pro_status=rs.getString("pro_status");
					info.pro_category=rs.getString("pro_category");
					lists.add(info);
					}
				}
			}catch (Exception e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			return lists;
	}
	public static void main(String[] args) {
		ProductDao dao=new ProductDao();
		List<ProductInfo> lists=dao.queryAllProducts();
		for (ProductInfo info : lists) {
			System.out.println(info);
		}
	}
}
