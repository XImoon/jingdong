package com.jky.dao;

import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import javax.naming.ldap.Rdn;
import javax.swing.text.SimpleAttributeSet;

import com.jky.db.DBHelper;
import com.jky.entity.OrderInfo;
import com.jky.entity.ProductInfo;
import com.jky.entity.UserInfo;

public class OrderDao extends DBHelper{
	//添加
	public boolean insert(OrderInfo info){
		String sql="insert into orderinfo(name, address,tel,status,count,date)values(?,?,?,?,?,?)";			
		List<String> lists=new ArrayList<String>();
		lists.add(info.name);
		lists.add(info.address);
		lists.add(info.tel);
		lists.add(info.status);
		lists.add(info.count);
		lists.add(info.date);
		try {
			return super.update(sql,lists);
		} catch (Exception e) {		
			e.printStackTrace();
		}
		return false;
	}
	//根据用户名查询
	public List<OrderInfo> queryByName(String name){
		List<OrderInfo> lists=null;
	
		String sql="select * from orderinfo where name=?";		
		List<String> list=new ArrayList<String>();
		list.add(name);
		try {
			rs=super.query(sql,list);
			if(rs!=null){
				lists=new ArrayList<OrderInfo>();
				while(rs.next()){
					OrderInfo info=new OrderInfo();	
					info._id=rs.getInt("_id");
					info.name=rs.getString("name");
					info.address=rs.getString("address");
					info.tel=rs.getString("tel");
					info.status=rs.getString("status");
					info.count=rs.getString("count");
					info.date=rs.getString("date");
					lists.add(info);
				}
			}
		} catch (Exception e) {
			// TODO: handle exception
		}finally{
			closeAll();
		}
		return lists;
	}
	public static void main(String[] args) {		
		
		
		//
		OrderDao dao=new OrderDao();
		//添加
//		boolean falg=dao.insert(new OrderInfo(
//				"yihuang",
//				"jky",
//				"1234",
//				"待处理",
//				"123",				
//				new SimpleDateFormat("yyyy-MM-dd hh:mm:ss").format(new Date())));				
//		System.out.println(falg);
//		
		
		//根据name查询信息
		List<OrderInfo> lists=dao.queryByName("admin"); 
		System.out.println(lists.toString());
	}
}
