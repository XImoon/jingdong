package com.jky.dao;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;
import com.jky.db.DBHelper;
import com.jky.entity.ActivityInfos;
public class ActivityDao extends DBHelper{

	private ResultSet rs=null;
	//根据类型查找
	public List<ActivityInfos> findByType(String type){
		List<ActivityInfos> lists=new ArrayList<ActivityInfos>();
		String sql="select * from activity where activity_type=? order by activity_count desc";
		List<String> strs=new ArrayList<String>();
		strs.add(type);
		rs=super.query(sql, strs);
		if(rs!=null){
			try {
				while(rs.next()){
					int _id=rs.getInt("_id");
					String images=rs.getString("activity_images");
					String title=rs.getString("activity_title");
					String content=rs.getString("activity_content");
					int count=rs.getInt("activity_count");
					String activity_type=rs.getString("activity_type");
					ActivityInfos info=new ActivityInfos(_id, images, title, content, count, activity_type);
					lists.add(info);
					
				}
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
		return lists;
	}
	//添加数据
	public boolean addActivity(ActivityInfos info){
		String sql="insert into activity(activity_images,activity_title,activity_content,activity_count,activity_type) values(?,?,?,?,?)";
		List<String> list=new ArrayList<String>();
		list.add(info.activity_image);
		list.add(info.activity_title);
		list.add(info.activity_content);
		list.add(info.activity_count+"");
		list.add(info.activity_type);
		boolean flag=false;
		flag=super.update(sql, list);
		return flag;
	}
	//修改次数
	public boolean updateCount(int _id,int count){
		boolean flag=false;
		String sql="update activity set activity_count=? where _id=?";
		List<String > list=new ArrayList<String>();
		list.add(count+"");
		list.add(_id+"");
		flag=super.update(sql, list);
		return flag;
	}
	public static void main(String[] args) {
		ActivityDao dao=new ActivityDao();
//		ActivityInfo info=new ActivityInfo("1.jpg", "测试", "sadasdasd", 1, "热门");
//		System.out.println(dao.addActivity(info));
//		List<ActivityInfos> lists = dao.findByType("热门");
//		System.out.println(lists);
		System.out.println(dao.updateCount(1, 2));
	}
	
	
}
