package com.jky.dao;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import com.jky.db.DBHelper;
import com.jky.entity.UserInfo;

public class UserDao extends DBHelper{
	//添加
	public boolean insert(UserInfo info){
		String sql="insert into userinfo(username, userpass,user_pic,balance)values(?,?,?,?)";	
		List<String> lists=new ArrayList<String>();
		lists.add(info.username);
		lists.add(info.userpass);
		lists.add(info.user_pic);
		lists.add(info.balance);
		try {
			return super.update(sql,lists);
		} catch (Exception e) {		
			e.printStackTrace();
		}
		return false;
	}
	//查询指定部分(根据条件查询)
	public UserInfo select(String username ,String userpass){
		String sql="select * from userinfo where username=? and userpass=? ";
		List<String> lists=new ArrayList<String>();
		lists.add(username);
		lists.add(userpass);
		UserInfo info=null;
		try {
			ResultSet rs=super.query(sql, lists);
			if(rs!=null){
				while(rs.next()){
					info=new UserInfo();
					info._id=rs.getInt("_id");
					info.username=rs.getString("username");
					info.userpass=rs.getString("userpass");
					info.user_pic=rs.getString("user_pic");
					info.balance=rs.getString("balance");
				}
			}
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return info;
	}
	//查找指定部分
	public boolean find(String username){
		String sql="select * from userinfo where username=?";
		List<String> lists=new ArrayList<String>();
		lists.add(username);
		try {
			ResultSet rs=super.query(sql, lists);
			if(rs!=null){
				while(rs.next()){
					return true;
				}
			}
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return false;
	}
	public static void main(String[] args) {
		UserDao dao=new UserDao();
//		UserInfo info=new UserInfo();
//		info.username="admin";
//		info.userpass="123";
//		info.user_pic="111";
//		info.balance="100";
		System.out.println(dao.find("adin"));
	}
	//通过名字查找
	public UserInfo findByName(String username){
		UserInfo info=null;
		String sql="select * from userinfo where username=?";
		List<String> lists=new ArrayList<String>();
		lists.add(username);
		ResultSet rs=super.query(sql, lists);
		try {
			while(rs.next()){
				info=new UserInfo();
				info._id=rs.getInt("_id");
				info.username=rs.getString("username");
				info.userpass=rs.getString("userpass");
				info.user_pic=rs.getString("user_pic");
				info.balance=rs.getString("balance");
			}
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return info;
	}
	public boolean updateByCount(int s, String name) {
		String sql="update userinfo set balance=? where username=?";
		List<String> lists=new ArrayList<String>();
		lists.add(s+"");
		lists.add(name);
		boolean flag=super.update(sql, lists);
		return flag;
	}
}
