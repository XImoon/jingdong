package com.jky.dao;

import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import com.jky.db.DBHelper;
import com.jky.entity.StoryInfo;

public class StoryDao extends DBHelper{
	public List<StoryInfo> queryAllusers(){
		List<StoryInfo> lists = null;
		String sql = "SELECT _id,name,image,story,image2 from storyinfo";
		try {
			rs = super.query(sql, null);
			if (rs!=null) {
				lists = new ArrayList<StoryInfo>();
				while(rs.next()){
					int _id = rs.getInt(1);
					String name = rs.getString(2);
					String image = rs.getString(3);
					String story = rs.getString(4);
					String image2 = rs.getString(5);
					StoryInfo info = new StoryInfo(_id, name, image, story , image2);
					lists.add(info);
				}
			}
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return lists;
		
	}
}
