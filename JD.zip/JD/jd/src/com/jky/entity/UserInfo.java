package com.jky.entity;
public class UserInfo {
	public int _id;
	public String username;
	public String userpass;
	public String user_pic;
	public String balance;
	
	public UserInfo() {
		super();
		// TODO Auto-generated constructor stub
	}

	public UserInfo(int _id, String username, String userpass, String user_pic,
			String balance) {
		super();
		this._id = _id;
		this.username = username;
		this.userpass = userpass;
		this.user_pic = user_pic;
		this.balance = balance;
	}
	public UserInfo(String username, String userpass, String user_pic,
			String balance) {
		super();
		this.username = username;
		this.userpass = userpass;
		this.user_pic = user_pic;
		this.balance = balance;
	}

	public String toString() {
		return "姓名是"+username+"密码为"+userpass;
	}
	
}
