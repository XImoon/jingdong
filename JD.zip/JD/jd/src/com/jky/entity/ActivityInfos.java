package com.jky.entity;

public class ActivityInfos {
	public  int _id;
	public String activity_image;
	public String activity_title;
	public String activity_content;
	public int activity_count;
	public String activity_type;
	public ActivityInfos(int id, String activityImage, String activityTitle,
			String activityContent, int activityCount,String activity_Type) {
		super();
		_id = id;
		activity_image = activityImage;
		activity_title = activityTitle;
		activity_content = activityContent;
		activity_count = activityCount;
		activity_type=activity_Type;
	}
	public ActivityInfos() {
		super();
		// TODO Auto-generated constructor stub
	}
	public ActivityInfos(String activityImage, String activityTitle,
			String activityContent, int activityCount, String activityType) {
		super();
		activity_image = activityImage;
		activity_title = activityTitle;
		activity_content = activityContent;
		activity_count = activityCount;
		activity_type = activityType;
	}
	@Override
	public String toString() {
		return "ActivityInfo [_id=" + _id + ", activity_content="
				+ activity_content + ", activity_count=" + activity_count
				+ ", activity_image=" + activity_image + ", activity_title="
				+ activity_title + ", activity_type=" + activity_type + "]";
	}

	
}
