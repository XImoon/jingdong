package com.jky.entity;
public class ProductInfo {
	public int pro_id;
	public String pro_name;
	public String pro_description;
	public String pro_price;
	public String pro_images;
	public String pro_status;
	public String pro_category;
	public ProductInfo(int pro_id, String pro_name, String pro_description,
			String pro_price, String pro_images, String pro_status,
			String pro_category) {
		super();
		this.pro_id = pro_id;
		this.pro_name = pro_name;
		this.pro_description = pro_description;
		this.pro_price = pro_price;
		this.pro_images = pro_images;
		this.pro_status = pro_status;
		this.pro_category = pro_category;
	}
	public ProductInfo(String pro_name, String pro_description,
			String pro_price, String pro_images, String pro_status,
			String pro_category) {
		super();
		this.pro_name = pro_name;
		this.pro_description = pro_description;
		this.pro_price = pro_price;
		this.pro_images = pro_images;
		this.pro_status = pro_status;
		this.pro_category = pro_category;
	}
	public ProductInfo() {
		super();
		// TODO Auto-generated constructor stub
	}
	@Override
	public String toString() {
		// TODO Auto-generated method stub
		return pro_id+"=="+pro_name+"=="+pro_description+"=="+
		pro_price+"=="+pro_images+"=="+pro_status+"=="+pro_category;
	}
}
