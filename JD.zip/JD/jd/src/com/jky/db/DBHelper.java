package com.jky.db;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.List;
public class DBHelper {
	protected static Connection conn=null;
	protected static PreparedStatement pstm=null;
	protected static ResultSet rs=null;
	private static final String DRIVER="com.mysql.jdbc.Driver";
	private static final String USER_NAME="root";
	private static final String PASSWORD="";
	private static final String URI="jdbc:mysql://localhost:3306/jd?useUnicode=true&characterEncoding=UTF-8";
	
	public static Connection getConnection(){
		try {
			Class.forName(DRIVER);
			conn=DriverManager.getConnection(URI, USER_NAME,PASSWORD);
			//System.out.println("连接成功");
		} catch (Exception e) {
			//System.out.println("连接失败");
			e.printStackTrace();
		}
		return conn;
	}
	//数据库增删改公共方法
	public boolean update(String sql,List<String> temp){
		getConnection();
		try {
			pstm=conn.prepareStatement(sql);
			if(temp!=null&&temp.size()>0){
				for (int i = 0; i < temp.size(); i++) {					
					pstm.setObject(i+1,temp.get(i));
				}
			}
			return pstm.executeUpdate()>0;
		} catch (Exception e) {
			// TODO: handle exception
		}
		return false;
	}
	//数据库查询公共方法
	public ResultSet query(String sql,List<String> temp){
		getConnection();
		try {
			pstm=conn.prepareStatement(sql);
			if(temp!=null&&temp.size()>0){
				for (int i = 0; i < temp.size(); i++) {
					pstm.setObject(i+1,temp.get(i));
				}
			}
			rs=pstm.executeQuery();
		} catch (Exception e) {
			// TODO: handle exception
		}
		return rs;
	} 
	//数据库关闭公共方法
	public void closeAll(){
		try {
			if(conn!=null){
				conn.close();
			}
			if(rs!=null){
				rs.close();
			}
			if(pstm!=null){
				pstm.close();
			}
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
}
