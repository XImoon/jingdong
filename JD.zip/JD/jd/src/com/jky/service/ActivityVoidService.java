package com.jky.service;

import com.google.gson.Gson;

public class ActivityVoidService {
	public String getJson(boolean flag){
		Gson gson=new Gson();
		return gson.toJson(flag);
	}
}
