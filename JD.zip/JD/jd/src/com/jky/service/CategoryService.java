package com.jky.service;

import java.util.List;

import com.google.gson.Gson;

public class CategoryService {
	//将list转为json
	public String parserToJson(List<String> lists){
		Gson gson=new Gson();
		return gson.toJson(lists);
	}
}
