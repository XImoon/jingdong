package com.jky.service;

import java.util.List;

import com.google.gson.Gson;
import com.jky.entity.OrderInfo;
import com.jky.entity.ProductInfo;
import com.jky.entity.UserInfo;

public class ProductService {
	//将list<bean>转为json
	public String parseListBeanToJson(List<ProductInfo> lists)throws Exception{
		Gson gson=new Gson();
		return gson.toJson(lists);
	}
	public String parseListOrderToJson(List<OrderInfo> lists)throws Exception{
		Gson gson=new Gson();
		return gson.toJson(lists);
	}
	//将bean转化为json
	public String parseBeanToJson(UserInfo info)throws Exception{
		Gson gson=new Gson();
		return gson.toJson(info);
	}
}
