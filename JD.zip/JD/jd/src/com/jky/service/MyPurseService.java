package com.jky.service;

import com.google.gson.Gson;
import com.jky.entity.UserInfo;

public class MyPurseService {
	public String getGson(UserInfo infos){
		Gson gson=new Gson();
		return gson.toJson(infos);
	}
}
