package com.jky.service;

import java.util.List;

import com.google.gson.Gson;
import com.jky.entity.ActivityInfos;

public class ActivityService {
	public String parserToJson(List<ActivityInfos> lists) throws Exception{
		Gson gson=new Gson();
		return gson.toJson(lists);
	}
}
