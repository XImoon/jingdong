package com.jky.service;

import java.util.List;

import com.google.gson.Gson;
import com.jky.entity.CategoryInfo;

public class CategoryForBeanService {
	//将list转为json
	public String parserToJson(List<CategoryInfo> lists){
		Gson gson=new Gson();
		return gson.toJson(lists);
	}
}
