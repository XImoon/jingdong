package com.jky.service;

import java.util.List;
import com.google.gson.Gson;
import com.jky.entity.StoryInfo;

public class StoryService {
	public String parseListPersonToJSON(List<StoryInfo> list) throws Exception{
		Gson gson = new Gson();
		return gson.toJson(list);
	}
}
