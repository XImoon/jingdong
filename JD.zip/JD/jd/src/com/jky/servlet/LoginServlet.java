package com.jky.servlet;
import java.io.IOException;
import java.io.PrintWriter;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.jky.dao.UserDao;
import com.jky.entity.UserInfo;
import com.jky.service.ProductService;
public class LoginServlet extends HttpServlet {
	public void doGet(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		doPost(request, response);
	}
	public void doPost(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {

		response.setContentType("text/html;charset=utf-8");
		PrintWriter out = response.getWriter();
		//接收客服端的请求参数
		String name=request.getParameter("username");
		String password=request.getParameter("userpass");
		//调用数据库
		boolean flag;
		UserDao dao=new UserDao();
		UserInfo info=dao.select(name,password);
		ProductService service=new ProductService();
		if(info!=null){
			String json;
			try {
				json = service.parseBeanToJson(info);
				out.println(json);
			} catch (Exception e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}else {
			out.println("登陆失败！");
		}
		out.flush();
		out.close();
	}

}
