package com.jky.servlet;
import java.io.IOException;
import java.io.PrintWriter;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.jky.dao.UserDao;
import com.jky.entity.UserInfo;
public class RegisterServlet extends HttpServlet {
	public void doGet(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		doPost(request, response);
	}
	public void doPost(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		request.setCharacterEncoding("utf-8");
		response.setContentType("text/html;charset=utf-8");
		PrintWriter out = response.getWriter();
		//得到客服端的请求参数
		String name=request.getParameter("username");
		String pass=request.getParameter("password");
		String pic=request.getParameter("user_pic");
		String balance=request.getParameter("balance");
		//访问数据库
		boolean falg01;
		UserDao dao=new UserDao();
		falg01=dao.find(name);
		if(falg01==true){
			out.println("该用户已存在");
		}else{
			boolean falg02=	dao.insert(new UserInfo(name, pass,pic,balance));
			if(falg02==true){
				out.println("ok");
			}else{
				out.println("no");
			}
		}
		out.flush();
		out.close();
	}

}
