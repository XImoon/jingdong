package com.jky.servlet;
import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Date;
import java.text.SimpleDateFormat;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.jky.dao.OrderDao;
import com.jky.entity.OrderInfo;
public class OrderServlet extends HttpServlet {
	public void doGet(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		doPost(request, response);
	}

	public void doPost(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {

		response.setContentType("text/html;charset=utf-8");
		PrintWriter out = response.getWriter();
		String name=request.getParameter("name");
		String address=request.getParameter("address");
		String tel=request.getParameter("tel");
		String count=request.getParameter("count");
		name=new String(name.getBytes("iso-8859-1"),"utf-8");
		address=new String(address.getBytes("iso-8859-1"),"utf-8");
		tel=new String(tel.getBytes("iso-8859-1"),"utf-8");
		count=new String(count.getBytes("iso-8859-1"),"utf-8");
		java.util.Date dt=new java.util.Date();
		SimpleDateFormat sdf=new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
		String str=sdf.format(dt);
		OrderInfo info=new OrderInfo(name,address,tel,"待处理",count,str);
		OrderDao dao=new OrderDao();
		boolean flag=dao.insert(info);
		out.println(flag);
		out.flush();
		out.close();
	}

}
