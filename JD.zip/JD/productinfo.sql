/*
Navicat MySQL Data Transfer

Source Server         : my34
Source Server Version : 50170
Source Host           : localhost:3306
Source Database       : jd

Target Server Type    : MYSQL
Target Server Version : 50170
File Encoding         : 65001

Date: 2015-01-12 09:20:15
*/

SET FOREIGN_KEY_CHECKS=0;

-- ----------------------------
-- Table structure for `productinfo`
-- ----------------------------
DROP TABLE IF EXISTS `productinfo`;
CREATE TABLE `productinfo` (
  `pro_id` int(100) NOT NULL AUTO_INCREMENT,
  `pro_name` varchar(100) NOT NULL,
  `pro_description` varchar(300) NOT NULL,
  `pro_price` varchar(100) NOT NULL,
  `pro_images` varchar(300) NOT NULL,
  `pro_status` varchar(100) DEFAULT NULL,
  `pro_category` varchar(100) DEFAULT NULL,
  PRIMARY KEY (`pro_id`)
) ENGINE=MyISAM AUTO_INCREMENT=68 DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of productinfo
-- ----------------------------
INSERT INTO `productinfo` VALUES ('4', '苹果5S', '苹果(Apple)iPone 5S(A1518) 16G 金色 移动4G 手机', '4259.00', 'p_3.jpg', '促销卖场', '手机');
INSERT INTO `productinfo` VALUES ('19', '艾美', '艾美 可调仰角/通用液晶电视架', '89.00', 'pei_2.jpg', '掌上秒杀', '家用配件');
INSERT INTO `productinfo` VALUES ('18', '乐歌', '乐歌PSW842M2(32-60寸) 旋转拉伸电视架', '199.00', 'pei_1.jpg', '掌上秒杀', '家用配件');
INSERT INTO `productinfo` VALUES ('5', '魅族', '【套装版】 魅族MX4 16GB 灰色 移动4G 手机', '1899.00', 'p_1.jpg', '掌上秒杀', '手机');
INSERT INTO `productinfo` VALUES ('6', '酷派', '酷派 大神F2 (8675-HD) 智尚日 移动版4G 手机 双卡双待', '999.00', 'p_2.jpg', '促销卖场', '手机');
INSERT INTO `productinfo` VALUES ('7', '苹果4S', '苹果(Apple)iPone 4S) 8G 白色 联通3G手机', '1999.00', 'p_5.jpg', '掌上秒杀', '手机');
INSERT INTO `productinfo` VALUES ('8', '苹果6', '苹果(Apple) iPhone6 金色 移动 联通 电信4G 手机', '5288.00', 'p_6.jpg', '掌上秒杀', '手机');
INSERT INTO `productinfo` VALUES ('9', '努比亚', '努比亚(nubia) 小牛 移动 联通 4G 电信3G 手机 双卡双待', '1499.00', 'p_7.jpg', '掌上秒杀', '手机');
INSERT INTO `productinfo` VALUES ('10', '华为', '华为 荣耀 低配版 白色 移动4G 手机 双卡双待', '799.00', 'p_8.jpg', '促销卖场', '手机');
INSERT INTO `productinfo` VALUES ('11', '联想', '联想 乐檬 k3(k30-T) 16G 典雅黄 移动4G 手机 双卡双待', '599.00', 'p_9.jpg', '掌上秒杀', '手机');
INSERT INTO `productinfo` VALUES ('12', '三星', '三星（SAMSUNG） Note4手机 智能保护套 雅墨黑', '299.00', 'tao_1.jpg', '掌上秒杀', '手机外壳');
INSERT INTO `productinfo` VALUES ('13', '魅士', '魅士 保护套/手机壳 适用于苹果 ipone6 Plus 5.5 英寸', '34.00', 'tao_2.jpg', '促销卖场', '手机外壳');
INSERT INTO `productinfo` VALUES ('14', '华为', '华为 原装线控带麦耳塞式耳机(白色)', '88.00', 'er_1.jpg', '掌上秒杀', '耳机');
INSERT INTO `productinfo` VALUES ('15', 'BYZ', 'BYZ S800 重低音音乐耳机 带线控可调音手机耳机', '89.00', 'er_2.jpg', '掌上秒杀', '耳机');
INSERT INTO `productinfo` VALUES ('16', '金士顿', '金士顿 (Kingston) 32G Class10-45MB/STF 存储卡', '74.90', 'ka_3.jpg', '掌上秒杀', '内存卡');
INSERT INTO `productinfo` VALUES ('17', '三星', '三星(Samsung)32G Class-48MB 存储卡', '79.90', 'ka_4.jpg', '促销卖场', '内存卡');
INSERT INTO `productinfo` VALUES ('20', '索尼', '索尼 （SONY）家庭影院 无线低音炮 回音壁音响系统', '3198.00', 'yin_1.jpg', '掌上秒杀', '家庭影院');
INSERT INTO `productinfo` VALUES ('21', '飞利浦', '飞利浦 （PHILIPS）HTL1100 193 家庭影院 超薄回音壁', '1999.00', 'yin_2.jpg', '掌上秒杀', '家庭影院');
INSERT INTO `productinfo` VALUES ('22', '乐视', '乐视 TV  全配版50英寸 4k 超高清 3D LED 液晶 超级电视', '4469.00', 'dian_1.jpg', '掌上秒杀', '电视');
INSERT INTO `productinfo` VALUES ('23', '康佳', '康佳(KONKA)LED42 E330CE 42 英寸 窄边全高清液晶电视', '1999.00', 'dian_2.jpg', '掌上秒杀', '电视');
INSERT INTO `productinfo` VALUES ('24', '美的', '美的 （Midea） 挂式家用冷暖变频空调', '2499.00', 'kong_1.jpg', '掌上秒杀', '空调');
INSERT INTO `productinfo` VALUES ('25', '奥克斯', '奥克斯 （ALIX）KFR-35GW 正1.5匹 挂式家用冷暖空调', '1999.00', 'kong_2.jpg', '掌上秒杀', '空调');
INSERT INTO `productinfo` VALUES ('26', '雅马哈', '雅马哈（Yamaha）迷你音响 蓝牙 音响 CD机 FM收音机', '999.00', 'y_1.jpg', '掌上秒杀', '音响');
INSERT INTO `productinfo` VALUES ('27', '创维', '创维 （Skyworth）i71C 网络电视音响', '599.00', 'y_2.jpg', '促销卖场', '音响');
INSERT INTO `productinfo` VALUES ('28', '漫步者', '漫步者 （EDIFIER) R101V 2.1 声道多媒体音响', '1780.00', 'ge_1.jpg', '掌上秒杀', '个性音响');
INSERT INTO `productinfo` VALUES ('29', 'Base', 'Base SoundLink Mine 蓝牙扬声器 蓝牙音响', '1888.00', 'ge_2.jpg', '掌上秒杀', '个性音响');
INSERT INTO `productinfo` VALUES ('30', '联想', '联想（Lenovo）英寸 一体电脑（i3 -4160T 2G 独显）', '4299.00', 't_1.jpg', '掌上秒杀', '台式电脑');
INSERT INTO `productinfo` VALUES ('31', 'Apple', 'Apple iMac MF883CH /A 21.5英寸一体电脑', '7588.00', 't_2.jpg', '促销卖场', '台式电脑');
INSERT INTO `productinfo` VALUES ('32', 'Apple', 'Apple MacBank Air  13.3英寸 宽屏笔记本电脑', '6588.00', 'bi_1.jpg', '掌上秒杀', '笔记本');
INSERT INTO `productinfo` VALUES ('33', 'ThinkPad', 'ThinkPad E431  14英寸 笔记本电脑(i5  4G 500G 2G 独显)', '3859.00', 'bi_2.jpg', '掌上秒杀', '笔记本');
INSERT INTO `productinfo` VALUES ('34', '崇尚', '崇尚 2014韩版 修身 上衣长袖 t 桖 女 588 酒红色 M码', '79.00', 'a_1.jpg', '掌上秒杀', '衬衫');
INSERT INTO `productinfo` VALUES ('35', '艺潮', '艺潮威舍 2014 女 装中长款 加绒加厚打底 衫长袖 女', '99.00', 'a_2.jpg', '掌上秒杀', '衬衫');
INSERT INTO `productinfo` VALUES ('36', '崇尚', '崇尚 2014 秋冬 女  上衣 小衫 修身 大码 显瘦 打底衫', '70.00', 'a_3.jpg', '促销卖场', '衬衫');
INSERT INTO `productinfo` VALUES ('37', '崇尚', '崇尚 2014 秋冬装  打底衫 长袖 女 V 领 韩版显瘦 衬衫 ', '69.00', 'a_4.jpg', '掌上秒杀', '衬衫');
INSERT INTO `productinfo` VALUES ('38', '韵妮', '韵妮亚 2014 秋冬装 新款 加厚 衬衫', '59.00', 'a_5.jpg', '掌上秒杀', '衬衫');
INSERT INTO `productinfo` VALUES ('39', 'JIe', 'Jie-neng 女裤加绒加厚休闲裤 女 韩版 大码小脚 哈伦 裤 显瘦', '159.00', 'b_1.jpg', '促销卖场', '休闲裤');
INSERT INTO `productinfo` VALUES ('40', '惑恋', ' 惑恋 加绒裤 休闲裤 女 长裤 水洗PU 加绒加厚 休闲 修身款', '179.00', 'b_2.jpg', '促销卖场', '休闲裤');
INSERT INTO `productinfo` VALUES ('41', '艾诺利亚', '艾诺利亚  女裤 加绒加厚打底裤 女 韩版 大码小脚 哈伦 显瘦', '89.00', 'b_3.jpg', '掌上秒杀', '休闲裤');
INSERT INTO `productinfo` VALUES ('42', '伊斯曼尔', '伊斯曼尔  哈伦 休闲裤 女  猫呢 加绒加厚 显瘦 小脚裤 ', '129.00', 'b_4.jpg', '掌上秒杀', '休闲裤');
INSERT INTO `productinfo` VALUES ('43', '来又来', '来又来 2014 冬款 女式 保暖 加绒加厚 休闲打底裤 1688 L', '99.00', 'b_5.jpg', '掌上秒杀', '休闲裤');
INSERT INTO `productinfo` VALUES ('44', 'S', '2014 秋冬 女装 韩版 高领  套头 针织衫 侧开叉 毛衣女 ', '198.00', 'd_5.jpg', '促销卖场', '针织衫');
INSERT INTO `productinfo` VALUES ('45', '惑恋', '惑恋 针织衫 女 秋冬新品  套头时尚 百搭 瘦身 女款 ', '79.00', 'c_4.jpg', '掌上秒杀', '针织衫');
INSERT INTO `productinfo` VALUES ('46', '麦帆', '麦帆 2014 秋冬 韩版  长袖 打底毛衣 女 8259 黑 均码', '89.00', 'c_5.jpg', '促销卖场', '针织衫');
INSERT INTO `productinfo` VALUES ('47', '麦帆', '麦帆 2014 秋冬 新款 韩版毛衣  V领 打底衫 针织衫', '109.00', 'c_2.jpg', '掌上秒杀', '针织衫');
INSERT INTO `productinfo` VALUES ('48', '妮黛', '妮黛 2014 冬装 上新  女 秋冬 毛衣 设置 SZ1007', '118.00', 'c_3.jpg', '掌上秒杀', '针织衫');
INSERT INTO `productinfo` VALUES ('49', '饰黛欧', '饰黛欧 马甲 修身 连帽时尚 简约 撞色 秒马甲 967 黑色 L', '98.00', 'd_4.jpg', '促销卖场', '马甲');
INSERT INTO `productinfo` VALUES ('50', '饰黛欧', '饰黛欧 棉马甲 女款  短款 背心马甲  女 965 蓝色 L', '99.00', 'd_1.jpg', '掌上秒杀', '马甲');
INSERT INTO `productinfo` VALUES ('51', 'DKCHENPiN', '马甲 女款 中长款 大码 女 棉背心 马甲带帽 外套', '249.00', 'c_1.jpg', '掌上秒杀', '马甲');
INSERT INTO `productinfo` VALUES ('52', '天乐斯微', '天乐斯微 2014 秋冬装  背心 马甲休闲连帽羽绒棉马甲', '149.00', 'd_2.jpg', '掌上秒杀', '马甲');
INSERT INTO `productinfo` VALUES ('53', '伶婉', '伶婉 2014 冬装新款 韩版 休闲 保暖 女 外套 8828 L', '150.00', 'd_3.jpg', '掌上秒杀', '马甲');
INSERT INTO `productinfo` VALUES ('54', '翰衣丽舍', '翰衣丽舍 CY 2014 冬季 毛衣 新款 女装 短款 长袖 雪纺衫', '139.00', 'e_1.jpg', '促销卖场', '雪纺衫');
INSERT INTO `productinfo` VALUES ('55', '优穆', '优穆 LIEOM 2014 韩版职业长袖衬衫 女 68810 白色 M', '108.00', 'e_2.jpg', '掌上秒杀', '雪纺衫');
INSERT INTO `productinfo` VALUES ('56', '韵妮亚', '韵妮亚 2014 秋冬装 新款 加厚 衬衫', '88.00', 'e_3.jpg', '掌上秒杀', '雪纺衫');
INSERT INTO `productinfo` VALUES ('57', '丽尚 栢莲', '丽尚 栢莲 2014 新款 职业女装 纯色 V 领 韩版 保暖 衬衫', '98.00', 'e_4.jpg', '促销卖场', '雪纺衫');
INSERT INTO `productinfo` VALUES ('58', '宜普', '宜普 2014 冬装 新款  长袖 衬衫 女装 圆领修身 加绒', '99.00', 'e_5.jpg', '掌上秒杀', '雪纺衫');
INSERT INTO `productinfo` VALUES ('59', '韵妮亚', ' 韵妮亚 2014 秋冬装 韩版 潮 修身 长袖 加厚加绒  打底衫', '88.00', 'f_1.jpg', '掌上秒杀', '羊毛衫');
INSERT INTO `productinfo` VALUES ('60', '哈夏', '哈夏 2014 新款 韩版 大码女修身 高领 羊毛衫', '99.00', 'f_2.jpg', '掌上秒杀', '羊毛衫');
INSERT INTO `productinfo` VALUES ('61', '合花灵', '合花灵 2014秋装 新款   蕾丝 修身 打底 上衣小衫9905', '88.00', 'f_5.jpg', '掌上秒杀', '羊毛衫');
INSERT INTO `productinfo` VALUES ('62', '奥芬玉', '奥芬玉 2014 秋冬 新款韩版 女装 修身 长袖 T 桖  打底', '99.00', 'f_3.jpg', '掌上秒杀', '羊毛衫');
INSERT INTO `productinfo` VALUES ('63', '翰衣丽舍', '翰衣丽舍 CY 2014 新款 女装 短款 长袖 羊毛衫', '105.00', 'f_4.jpg', '掌上秒杀', '羊毛衫');
INSERT INTO `productinfo` VALUES ('64', '苹果5s', 'iPhone 5s 移动联通4G手机', '4199.00', 'tel_1.jpg', '促销卖场', '手机');
INSERT INTO `productinfo` VALUES ('65', '魅族', '魅蓝 白色移动4G 双卡双待', '999.00', 'tel_2.jpg', '促销卖场', '手机');
INSERT INTO `productinfo` VALUES ('66', '苹果6', 'iPhone 6s 16G 金色 移动联通电信', '6088.00', 'tel_3.jpg', '促销卖场', '手机');
INSERT INTO `productinfo` VALUES ('67', '荣耀6', '荣耀 低配版 白色 移动4G手机', '1999.00', 'tel_4.jpg', '促销卖场', '手机');
